/******************************************************************************
*
* project name:    TI-Chess / Chess Puzzle Compiler
* file name:       cpc.c
* initial date:    04/10/2002
* author:          thomas.nussbaumer@gmx.net
* description:     chess puzzle compiler main file
*
* $Id: cpc.c,v 1.8 2002/10/23 21:06:56 tnussb Exp $
*
******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>


//-----------------------------------------------------------------------------
// just used internally
//-----------------------------------------------------------------------------
#define CVS_TRUNC_PREFIX    ((strlen((CVS_FILE_REVISION))<=11) ? 0 : (CVS_FILE_REVISION+11))
#define CVS_FIND_COMMA      (strchr(CVS_TRUNC_PREFIX,'.'))
#define CVSREV_MAIN         (int)(!(CVS_TRUNC_PREFIX) ? 0 : atoi(CVS_TRUNC_PREFIX))
#define CVSREV_SUB          (int)(!(CVS_TRUNC_PREFIX) ? 0 : (!(CVS_FIND_COMMA) ? 0 : atoi(CVS_FIND_COMMA+1)))

//-----------------------------------------------------------------------------
// NOTE: THE FOLLOWING MACRO WILL ONLY HANDLE MAIN VERSION < 10 AT CONSTANT
//       LENGTH !!!
//       (subversions from 1 .. 99 are mapped to 01 .. 99)
//
// the following macro may be used to setup a printf(),sprintf() or fprintf()
// call
//-----------------------------------------------------------------------------
#define CVSREV_PRINTPARAMS  "v%d.%02d",CVSREV_MAIN,CVSREV_SUB


#define PRINT_ID(x,name)  {fprintf(x,"\n");fprintf(x, name" ");\
                           fprintf(x,CVSREV_PRINTPARAMS);\
                           fprintf(x," (TI-Chess/Supplemental Tools)\n(c) thomas.nussbaumer@gmx.net "__DATE__" "__TIME__"\n\n");}


#ifdef CVS_FILE_REVISION
#undef CVS_FILE_REVISION
#endif
//-----------------------------------------------------------------------------
// DON'T EDIT THE NEXT DEFINE BY HAND! THIS IS DONE AUTOMATICALLY BY THE
// CVS SYSTEM !!!
//-----------------------------------------------------------------------------
#define CVS_FILE_REVISION "$Revision: 1.8 $"

#include "cpc.h"
#include "fen.c"
#include "bin2oth.c"


#define MAXSIZE_LIMIT TT_MAX_OTHDATA


#define SIZE_TEXTS       32
#define MAX_PUZZLES   65000
#define MAX_STRINGS   65000
#define NOT_IN_LIST    (-1)


typedef struct {
    int          texts[7];              // indices into string table
    char         board[64];
    char         side_to_move;
    char         white_castling_long;
    char         white_castling_short;
    char         black_castling_long;
    char         black_castling_short;
    char         ep_field;
    unsigned int ply50_count;
    unsigned int fullmove_count;
} puzzle_t;

// the size of the puzzle's binary representation
// = size of compressed pos (22 + 7 textoffsets a 2 bytes)
#define SIZE_OF_PUZZLE (22+7*2)


puzzle_t* puzzles;
char**    strings;
int       nr_puzzles;
int       nr_strings;
int       sum_of_strings;
int*      real_offsets;

#define DEFAULT_PREFIX "ticpuz"

int   param_size   = MAXSIZE_LIMIT;
int   param_offset = 0;
char* param_folder = DEFAULT_FOLDER;
char* param_prefix = DEFAULT_PREFIX;


//=============================================================================
// outputs usage text
//=============================================================================
void OutputUsage(char* filename) {
    PRINT_ID(stderr,"Chess Puzzle Compiler");

    fprintf(stderr,"usage: %s [flags] inputfile\n\n" \
                   "-offset digit  ... postfix of first generated outputfile (0..9)\n"\
                   "-size number   ... maximum oncalc size of each book (<= %d)\n"\
                   "-folder name   ... oncalc folder name (default: %s)\n"\
                   "-prefix name   ... oncalc file name prefix (default: %s)\n\n"\
                   "Converts a textfile into a TI-Chess puzzle file. If the inputfile is\n"
                   "too large to fit into a single file more than one outputfile is\n"\
                   "generated.\n\n"\
                   "By default the TI89 outputfiles are named %s0.89y up to\n"\
                   "%s9.89y and the TI92p/V200 files are named %s0.9xy up to\n"\
                   "%s9.9xy and will be stored in the oncalc folder %s. Note that\n"\
                   "if you specify an own filename with option -prefix the program will\n"\
                   "automatically append a number to it.\n",
                   filename,MAXSIZE_LIMIT,DEFAULT_FOLDER,DEFAULT_PREFIX,
                   DEFAULT_PREFIX,DEFAULT_PREFIX,DEFAULT_PREFIX,DEFAULT_PREFIX,DEFAULT_FOLDER);
}


//-----------------------------------------------------------------------------
// huffman encoded chess pieces (C==0 -> white / C==1 -> black)
//
// Empty:  0
// Pawn:   10C
// Bishop: 1100C
// Knight: 1101C
// Rook:   1110C
// Queen:  11110C
// King:   11111C
//-----------------------------------------------------------------------------
#define AddBit(_x_) { if (_x_) *output |= bitmask;  \
                      else     *output &= ~bitmask; \
                      bitmask>>=1;                  \
                      if (!bitmask) {               \
                          bitmask=0x80;             \
                          output++;                 \
                      }                             \
                      retval++;                     \
                      if (retval>164) {             \
                          fprintf(stderr,"FATAL: too much bits in compressed position\n");\
                          exit(1);\
                      }}

//=============================================================================
// compresses a chess position (huffman encoding)
//
// input is a 64-byte long buffer holding a chess position
// output is a 21-byte buffer for compressed chess position
//=============================================================================
void EncodeBoard(char* input, unsigned char* output) {
    short i;
    short retval  = 0; // used to check number of bits generated
    short bitmask = 0x80;


    for (i=0;i<64;i++,input++) {
        char tmpstr[255];
        switch(*input) {
            case EMPTY_FIELD:  AddBit(0); break;
            case WHITE_PAWN:   AddBit(1); AddBit(0); AddBit(0); break;
            case BLACK_PAWN:   AddBit(1); AddBit(0); AddBit(1); break;
            case WHITE_BISHOP: AddBit(1); AddBit(1); AddBit(0); AddBit(0); AddBit(0); break;
            case BLACK_BISHOP: AddBit(1); AddBit(1); AddBit(0); AddBit(0); AddBit(1); break;
            case WHITE_KNIGHT: AddBit(1); AddBit(1); AddBit(0); AddBit(1); AddBit(0); break;
            case BLACK_KNIGHT: AddBit(1); AddBit(1); AddBit(0); AddBit(1); AddBit(1); break;
            case WHITE_ROOK:   AddBit(1); AddBit(1); AddBit(1); AddBit(0); AddBit(0); break;
            case BLACK_ROOK:   AddBit(1); AddBit(1); AddBit(1); AddBit(0); AddBit(1); break;
            case WHITE_QUEEN:  AddBit(1); AddBit(1); AddBit(1); AddBit(1);AddBit(0); AddBit(0); break;
            case BLACK_QUEEN:  AddBit(1); AddBit(1); AddBit(1); AddBit(1);AddBit(0); AddBit(1); break;
            case WHITE_KING:   AddBit(1); AddBit(1); AddBit(1); AddBit(1);AddBit(1); AddBit(0); break;
            case BLACK_KING:   AddBit(1); AddBit(1); AddBit(1); AddBit(1);AddBit(1); AddBit(1); break;
            default:
                fprintf(stderr,"FATAL: unknown piece (%d) on field %d\n",*input,i);
                exit(1);
        }
    }
}


//=============================================================================
// converts puzzle into (22+14) binary representation
//=============================================================================
void Puzzle2Binary(puzzle_t* puz,unsigned char *output) {
    short      ret;
    char       tmpstr[255];
    int        i;

    for (i=0;i<7;i++) {
        // write string offsets
        *output++ = (puz->texts[i] >> 8) & 0xff;
        *output++ = (puz->texts[i])      & 0xff;
    }

    //-------------------------------------------------------------------------
    // compress position ...
    //-------------------------------------------------------------------------
    EncodeBoard(puz->board,output);

    //-------------------------------------------------------------------------
    // fill the other flags ...
    //-------------------------------------------------------------------------
    if (puz->side_to_move == WHITE) output[21] &= 0xfe;
    else                            output[21] |= 0x01;

    if (puz->ep_field >= 0) {
        output[20] |= 0x08; // epfield is used
        output[20] |= (puz->ep_field % 8) & 0x07;
    }

    if (puz->white_castling_long)  output[21] |= 0x2;
    else                           output[21] &= 0xfd;
    if (puz->white_castling_short) output[21] |= 0x4;
    else                           output[21] &= 0xfb;
    if (puz->black_castling_long)  output[21] |= 0x8;
    else                           output[21] &= 0xf7;
    if (puz->black_castling_short) output[21] |= 0x10;
    else                           output[21] &= 0xef;
}


//=============================================================================
// initializes memory for puzzle list and string list
//=============================================================================
int InitMemory() {
    strings      = 0;
    puzzles      = 0;
    real_offsets = 0;

    if (!(strings = (char**)malloc(sizeof(char*)*MAX_STRINGS))) return 0;
    memset(strings,0,sizeof(char*)*MAX_STRINGS);

    if (!(real_offsets = (int*)malloc(sizeof(int)*MAX_STRINGS))) return 0;

    if (!(strings[0] = (char*)malloc(1))) return 0;
    *(strings[0]) = 0;  // the empty string!!

    if (!(puzzles = (puzzle_t*)malloc(sizeof(puzzle_t)*MAX_PUZZLES))) return 0;
    memset(puzzles,0,sizeof(puzzle_t)*MAX_PUZZLES);

    nr_puzzles     = 0;
    nr_strings     = 1;  // index 0 is the EMPTY_STRING
    sum_of_strings = 1;  // size of EMPTY_STRING is 1

    return 1;
}


//=============================================================================
// free's memory of puzzle list and string list
//=============================================================================
void FreeMemory() {
    if (strings) {
        for (int i=0;i<nr_strings;i++) if (strings[i]) free(strings[i]);
        free(strings);
    }
    if (puzzles) free(puzzles);
    if (real_offsets) free(real_offsets);
}


//=============================================================================
// try to find a string in the string list. returns index if found or
// NOT_IN_LIST if there is no replicate
//
// EMPTY STRINGS are always mapped to index 0!!
//=============================================================================
int FindReplicate(char* s) {
    if (!*s) return 0;

    // check if already in list -> return index
    for (int i=1;i<nr_strings;i++) {
        if (!strcmp(strings[i],s)) return i;
    }
    return NOT_IN_LIST;
}


//=============================================================================
// add string to string list and returns its index
// (returns -1 if malloc fails)
//=============================================================================
int AddString(char* s) {
    int replicate = FindReplicate(s);
    if (replicate != NOT_IN_LIST) return replicate;

    // else add it to the list
    if (!(strings[nr_strings] = (char*)malloc(strlen(s)+1))) {
        fprintf(stderr,"FATAL: out of memory!\n");
        exit(1); // we don't care about memory freeing in this case.
                 // on modern PCs we can count on the operating system to
                 // perform this task for us.
    }
    strcpy(strings[nr_strings],s);
    sum_of_strings += strlen(s)+1;
    nr_strings++;
    if (nr_strings >= MAX_STRINGS) {
        fprintf(stderr,"FATAL: too much strings found. cannot proceed!\n");
        exit(1); // we don't care about memory freeing in this case.
                 // on modern PCs we can count on the operating system to
                 // perform this task for us.
    }
    return nr_strings-1;
}


//=============================================================================
// checks if string is empty
//=============================================================================
int IsEmptyString(char* s) {
    while (*s != 0 && (*s == ' ' || *s == '\t')) s++;
    return (!*s || *s == '\n') ? 1 : 0;
}


//=============================================================================
// checks if string is empty
//=============================================================================
void TrimStringOnEnd(char* s) {
    int len;
    int i;
    if (!s) return;

    len = strlen(s);
    for (i=len-1;i>=0;i++) {
        if (s[i] == ' ' || s[i] == '\t' || s[i] == '\n') {
            s[i] = 0;
        }
        else {
            break;
        }
    }
}


//=============================================================================
// try to parse a FEN position description
//=============================================================================
int TryParseFEN(char* s,puzzle_t* p) {
    if (!ParseFEN(s,
                  p->board,
                  &(p->side_to_move),
                  &(p->white_castling_long),
                  &(p->white_castling_short),
                  &(p->black_castling_long),
                  &(p->black_castling_short),
                  &(p->ep_field),
                  &(p->ply50_count),
                  &(p->fullmove_count)))
    {
        return 0;
    }

    return 1;
}

char     inputline[1000];
char     texts[7][SIZE_TEXTS+1];
puzzle_t tmp_puzzle;


void AddTextAndTruncate(char* text,int index,int linenumber) {
    if (strlen(text) > SIZE_TEXTS) {
        strncpy(texts[index],text,SIZE_TEXTS);
        fprintf(stderr,"WARNING line %u: string gets truncated! (max.length=%d)\n",linenumber,SIZE_TEXTS);
    }
    else {
        strcpy(texts[index],text);
    }
}


//=============================================================================
// initializes temporary puzzle structure instance
//=============================================================================
void InitTempPuzzle() {
    int i;
    memset(&tmp_puzzle,0,sizeof(puzzle_t));
    for (i=0;i<7;i++) {
        memset(texts[i],0,SIZE_TEXTS+1);
    }
}


//=============================================================================
// get size of temporary puzzle structure instance
//=============================================================================
int SizeOfTempPuzzle() {
    int i;
    int total = SIZE_OF_PUZZLE;

    for (i=0;i<7;i++) {
        if (tmp_puzzle.texts[i] == NOT_IN_LIST) {
            if (texts[i][0]) {
                total += strlen(texts[i]);
            }
        }
    }

    return total;
}


//=============================================================================
// still fits?
//=============================================================================
int CheckSize() {
    int total = 2 + 4 + 2; // file length(2) + magic marker(4) + puzzle count(2)
    total += SIZE_OF_PUZZLE*nr_puzzles;
    total += sum_of_strings;
    total += 9;  // OTH bytes
    total += SizeOfTempPuzzle();

    return (total > param_size) ? 0 : 1;
}


//=============================================================================
// add temporary puzzle structure to global lists
//=============================================================================
void AddTempPuzzle() {
    int i;

    //printf("AddTempPuzzle()\n");
    memcpy(&(puzzles[nr_puzzles]),&tmp_puzzle,sizeof(puzzle_t));

    for (i=0;i<7;i++) {
        if (puzzles[nr_puzzles].texts[i] == NOT_IN_LIST) {
            puzzles[nr_puzzles].texts[i] = AddString(texts[i]);
        }
    }
}


//=============================================================================
// convert logical offsets into real file offsets
//=============================================================================
void ConvertOffsets() {
    int i,j;
    int act_offset = 2+4+2+SIZE_OF_PUZZLE*nr_puzzles;

    // fill the real_offset array
    for (i=0;i<nr_strings;i++) {
        real_offsets[i] = act_offset;
        act_offset += strlen(strings[i])+1;
    }

    // convert the offsets within the puzzles ..
    for (i=0;i<nr_puzzles;i++) {
        for (j=0;j<7;j++) {
            puzzles[i].texts[j] = real_offsets[puzzles[i].texts[j]];
        }
    }
}


//=============================================================================
// generates outputfile from actual list
//=============================================================================
int WriteOutputfile() {
    char filename[30];
    unsigned char* buffer;
    unsigned char* orig;
    unsigned char* othdata;
    unsigned int   othdata_len;
    int            bin_length;
    int            i;
    FILE*          fp;

    if (!nr_puzzles) return 1;

    if (param_offset >= 10) {
        fprintf(stderr,"ERROR: cannot produce more than 10 files\n");
        return 0;
    }

    bin_length = 4 + 2; // magic marker + number of puzzles
    bin_length += SIZE_OF_PUZZLE*nr_puzzles + sum_of_strings;

    if (!(buffer = (unsigned char*)malloc(bin_length))) {
        fprintf(stderr,"FATAL: out of memory");
        exit(1);
    }

    orig = buffer;

    // write magic
    *buffer++ = 'P';
    *buffer++ = 'U';
    *buffer++ = 'Z';
    *buffer++ = '1';

    // write puzzle counter
    *buffer++ = (nr_puzzles >> 8) & 0xff;
    *buffer++ = (nr_puzzles) & 0xff;

    // converts the offsets in the puzzle list to real file offsets
    ConvertOffsets();

    // write puzzles
    for (i=0;i<nr_puzzles;i++) {
        Puzzle2Binary(&puzzles[i],buffer);
        buffer+=SIZE_OF_PUZZLE;
    }

    //write strings
    *buffer++ = 0;  // the empty string
    for (i=1;i<nr_strings;i++) {
        strcpy(buffer,strings[i]);
        buffer+=strlen(strings[i]);
        *buffer++ = 0;
    }

    fprintf(stderr,"saving %d puzzles ...\n",nr_puzzles);

    sprintf(filename,"%s%d",param_prefix,param_offset);
    if (!(othdata = DataBuffer2OTHBuffer(CALC_TI89,
                                         param_folder,
                                         filename,
                                         "tict",
                                         bin_length,
                                         orig,
                                         &othdata_len)))
    {
        free(orig);
        fprintf(stderr,"ERROR: cannot generate OTH data\n");
        return 0;
    }

    sprintf(filename,"%s%d.89y",param_prefix,param_offset);
    if (!(fp = fopen(filename,"wb"))) {
        fprintf(stderr,"ERROR: cannot open TI89 file %s\n",filename);
        free(orig);
        free(othdata);
        return 0;
    }

    if (fwrite(othdata,othdata_len,1,fp)!=1) {
        fprintf(stderr,"ERROR: cannot write to TI89 file %s\n",filename);
        fclose(fp);
        free(othdata);
        free(orig);
        return 0;
    }

    fprintf(stderr,"puzzlefile %s for TI89 (oncalcsize=%d) generated\n",filename,bin_length+9);
    free(othdata);
    fclose(fp);


    sprintf(filename,"%s%d",param_prefix,param_offset);
    if (!(othdata = DataBuffer2OTHBuffer(CALC_TI92P,
                                         param_folder,
                                         filename,
                                         "tict",
                                         bin_length,
                                         orig,
                                         &othdata_len)))
    {
        free(orig);
        fprintf(stderr,"ERROR: cannot generate OTH data\n");
        return 0;
    }

    sprintf(filename,"%s%d.9xy",param_prefix,param_offset);
    if (!(fp = fopen(filename,"wb"))) {
        fprintf(stderr,"ERROR: cannot open TI92p/V200 file %s\n",filename);
        free(orig);
        free(othdata);
        return 0;
    }

    if (fwrite(othdata,othdata_len,1,fp)!=1) {
        fprintf(stderr,"ERROR: cannot write to TI92p/V200 file %s\n",filename);
        fclose(fp);
        free(othdata);
        free(orig);
        return 0;
    }

    fprintf(stderr,"puzzlefile %s for TI92p/V200 (oncalcsize=%d) generated\n",filename,bin_length+9);
    free(othdata);
    fclose(fp);

    free(orig);

    param_offset++;
    return 1;
}




//=============================================================================
// WriteAndReinitialize()
//=============================================================================
int WriteAndReinitialize() {
    int i;
    if (!WriteOutputfile()) return 0;

    memset(&(strings[1]),0,sizeof(char*)*(MAX_STRINGS-1));
    memset(puzzles,0,sizeof(puzzle_t)*MAX_PUZZLES);

    nr_puzzles     = 0;
    nr_strings     = 1;  // index 0 is the EMPTY_STRING
    sum_of_strings = 1;  // size of EMPTY_STRING is 1

    // we have to set the offsets of the text to NOT_IN_LIST
    // otherwise it will point to invalid offsets!!!
    for (i=0;i<7;i++) if (tmp_puzzle.texts[i]) tmp_puzzle.texts[i] = NOT_IN_LIST;
    return 1;
}


//=============================================================================
// parses complete file (returns 1 if success)
//=============================================================================
int ParseFile(char* filename) {
    FILE*        infile = fopen(filename,"r");
    char         tmpstr[255];
    unsigned int linenumber     = 0;
    int          desc_count     = 0;
    int          solution_count = 0;
    int          index;

    if (!infile) {
        fprintf(stderr,"ERROR: cannot open infile %s\n",filename);
        return 0;
    }

    InitTempPuzzle();

    while (fgets(inputline,999,infile)) {
        linenumber++;
        TrimStringOnEnd(inputline);
        if (inputline[0] == '#' || (inputline[0] == '/' && inputline[1] == '/')) continue;
        if (IsEmptyString(inputline)) continue;

        // is a description string
        if (!strncmp(inputline,"[D]",3)) {
            if (desc_count >= 3) {
                fprintf(stderr,"ERROR in line %u: too much description lines (max. 3)\n",linenumber);
                return 0;
            }
            AddTextAndTruncate(inputline+3,desc_count,linenumber);
            tmp_puzzle.texts[desc_count] = FindReplicate(texts[desc_count]);
            //printf("description added: %s\n",texts[desc_count]);
            desc_count++;
        }
        // is a solution string
        else if (!strncmp(inputline,"[S]",3)) {
            if (solution_count >= 4) {
                fprintf(stderr,"ERROR in line %u: too much solution lines (max. 3)\n",linenumber);
                return 0;
            }
            AddTextAndTruncate(inputline+3,3+solution_count,linenumber);
            tmp_puzzle.texts[3+solution_count] = FindReplicate(texts[3+solution_count]);
            //printf("solution added: %s\n",texts[3+solution_count]);
            solution_count++;
        }
        // is a FEN
        else {
            //printf("parsing fen\n");
            if (TryParseFEN(inputline,&tmp_puzzle)) {
                desc_count     = 0;
                solution_count = 0;

                //printf("checking size\n");
                if (!CheckSize()) {
                    if (!WriteAndReinitialize()) return 0;
                }
                //printf("adding temppuzzle\n");
                AddTempPuzzle();
                InitTempPuzzle();
                nr_puzzles++;
            }
            else {
                fprintf(stderr,"ERROR in line %u: expected a FEN\n",linenumber);
                return 0;
            }
        }
    }

    WriteOutputfile();
    return 1;
}






//=============================================================================
// outputs usage text
//=============================================================================
int main(int argc,char* argv[]) {
    int   len = 0;
    int   n;
    char* inputfile = 0;

    if (argc < 2) {
        OutputUsage(argv[0]);
        return 1;
    }

    // parse arguments
    for (n=1; n<argc; n++) {
        if (!strcmp(argv[n], "-offset")) {
            if (n == argc -1) {
                fprintf(stderr,"ERROR: missing digit for option '-offset'\n");
                return 1;
            }

            if (sscanf(argv[n+1],"%d",&param_offset) != 1) {
                fprintf(stderr,"ERROR: invalid parameter for option '-offset'\n");
                return 1;
            }

            if (param_offset < 0 || param_offset > 9) {
                fprintf(stderr,"ERROR: only digits (0..9) are valid for option '-offset'\n");
                return 1;
            }

            n++;
        }

        else if (!strcmp(argv[n], "-folder")) {
            if (n == argc -1) {
                fprintf(stderr,"ERROR: missing parameter for option '-folder'\n");
                return 1;
            }

            if (strlen(argv[n+1])>8) {
                fprintf(stderr,"ERROR: folder name too long (max. 8 characters)\n");
                return 1;
            }

            param_folder = argv[n+1];
            n++;
        }
        else if (!strcmp(argv[n], "-prefix")) {
            if (n == argc -1) {
                fprintf(stderr,"ERROR: missing parameter for option '-prefix'\n");
                return 1;
            }

            if (strlen(argv[n+1])>7) {
                fprintf(stderr,"ERROR: prefix too long (max. 7 characters)\n");
                return 1;
            }

            param_prefix = argv[n+1];
            n++;
        }

        else if (!strcmp(argv[n], "-size")) {
            if (n == argc -1) {
                fprintf(stderr,"ERROR: missing number for option '-size'\n");
                return 1;
            }

            if (sscanf(argv[n+1],"%u",&param_size) != 1) {
                fprintf(stderr,"ERROR: invalid parameter for option '-size'\n");
                return 1;
            }

            if (param_size > MAXSIZE_LIMIT) {
                fprintf(stderr,"ERROR: cannot generate books larger than %d\n",MAXSIZE_LIMIT);
                return 1;
            }

            n++;
        }
        else if (argv[n][0] == '-') {
            fprintf(stderr,"ERROR: invalid option %s\n",argv[n]);
            return 1;
        }
        else if (!inputfile) inputfile = argv[n];
        else {
            OutputUsage(argv[0]);
            return 1;
        }
    }

    if (!inputfile) {
        fprintf(stderr,"ERROR: no inputfile specified\n");
        return 1;
    }


    PRINT_ID(stderr,"Chess Puzzle Compiler");

    if (!InitMemory()) {
        FreeMemory();
        fprintf(stderr,"FATAL: out of memory\n");
        return 1;
    }

    if (!ParseFile(inputfile)) {
        FreeMemory();
        return 1;
    }

    fprintf(stderr,"\n");
    FreeMemory();
    return 0;
}

//#############################################################################
//###################### NO MORE FAKES BEYOND THIS LINE #######################
//#############################################################################
//
//=============================================================================
// Revision History
//=============================================================================
//
// $Log: cpc.c,v $
// Revision 1.8  2002/10/23 21:06:56  tnussb
// long longer sharing of bkc.h (uses own headerfile cpc.h now)
//
// Revision 1.7  2002/10/18 15:16:45  tnussb
// changes due to -name and -folder commandline parameters
//
// Revision 1.6  2002/10/16 17:02:50  tnussb
// completely rewritten:
// (1) generation of up to 10 outputfiles
// (2) support for solution text
// (3) compressed board position storing
// (4) store replicated strings only onces
//
// Revision 1.5  2002/10/10 13:09:29  tnussb
// completely rewritten. uses now FEN position description and the generated
// files are about 30% smaller.
//
//
