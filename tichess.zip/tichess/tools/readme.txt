===============================================================================
Chess Puzzle Compiler for TI-Chess                (c) thomas.nussbaumer@gmx.net
===============================================================================
$Id: readme.txt,v 1.10 2002/10/24 11:46:08 tnussb Exp $

The Chess Puzzle Compiler (cpc.exe) may be used to generate chess puzzle files
for TI-Chess.

Usage: Just start cpc.exe once without any parameter and you will get its help
page.


-------------------------------------------------------------------------------
format of inputfile for Chess Puzzle Compiler
-------------------------------------------------------------------------------
A single chess puzzle consists of up to 3 lines of description text, up
to 4 lines of solution text and of one line which holds a FEN position
description. A description text line have to start with the tag [D] and
solution text have to start with tag [S]. Textlines are limited to 32
characters (not counting the tag [D] and [S]!). Longer text lines will be
truncated to that limit.

It is a good practice to specify a copyright in the description lines of a
puzzle as well as the goal to reach. The side which is up to draw have not
to be specified separately in the description, because it will be automatically
extracted from the FEN position description.

The format specification of a FEN position description can be found at the
bottom of THIS file.

Comment lines have to start with '//' or with '#'.
Empty lines are allowed and gets skipped.

An example of a valid chess puzzle file is tools/puzzles.txt which is used
to generate the puzzles0.89y/puzzles0.9xy files which comes with TI-Chess.



===============================================================================
Opening Book Compiler for TI-Chess                (c) thomas.nussbaumer@gmx.net
===============================================================================

The Opening Book Compiler (bkc) may be used to generate opening books for
TI-Chess. During startup TI-Chess traverses the VAT to find all compatible
opening book files. Normally these files should be stored in folder TICT.

Usage: Just start bkc.exe once without any parameter and you will get its help
page.


-------------------------------------------------------------------------------
format of inputfile for Opening Book Compiler
-------------------------------------------------------------------------------
The inputfile format is standard PGN. Additionally '//' can be used for
comments.

(1) PGN move sequences have to start with move count "1.". and start by default
    from the standard initial chess position.
(2) If a FEN position tag is detected, the next move sequence will start from
    this position.
(3) A valid PGN FEN position notation looks like this:
    [FEN "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"]
    Note: Don't forget the brackets and the quotes!!
(4) Each detected move count "1." at the beginning of a line will start a new
    move sequence.
(5) PGN move sequences can be splitted into multiple lines.

For an example of a valid opening book input file, please examine file
tools/openings.txt, which is used to build the TI-Chess standard books.

-------------------------------------------------------------------------------
Format of FEN position description:
-------------------------------------------------------------------------------
[see end this file]


-------------------------------------------------------------------------------
Format of PGN move sequences:
-------------------------------------------------------------------------------

Example: 1. e4 Nf6 2. e5 Nd5 3. c4 Nb6 4. d4 d6 5. f4 dxe5 6. fxe5 Nc6

Each WHITE move has to be prefixed with a move number starting with "1.".

Beside pawn moves each move starts with a character describing the figure to
move ('K','Q','R','B','N').

If a figure moves to an empty field and there is no other figure of the
same type which may move to this field, than one the destination us appended
to the figure describing character (Nd5,e4,d6,Ke2 ...).

If more than one figure of the same type may move to this field you have
either specify the column or the row in front of the destination field depending
which will uniquely specify the move (Ncd4, N1d4, ...).

If the destination is NOT empty you have to insert an 'x' to mark the move like
this: ex4, Kxe2, Ncxd4, N1xd4, exf4, ...

If the move is a promotion move you have to append a character describing the
figure to promote (d8Q, d8R, d8N, d8B ...).

Castling will be noted as:

O-O-O  ... long castling
O-O    ... short castling

NOTE: The book compiler can also handle fully qualified moves which consists
of the figure symbol, the from field, either 'x' or '-' and the destination
field. If it is a promotion move the character to promote to have to be
appended (of course).

Examples of fully qualified moves: Qf2-f4, d7-d8Q, Ra1xa3



===============================================================================
FEN - standard for describing chess position
===============================================================================

FEN specifies the piece placement, the active color, the castling availability,
the en passant target square, the halfmove clock, and the fullmove number written
on a single line.

A FEN description has six fields.  Each field is composed only of non-blank
printing ASCII characters.  Adjacent fields are separated by a single ASCII
space character.

-------------------------------------------------------------------------------
Field 1: Piece placement data
-------------------------------------------------------------------------------
The first field represents the placement of the pieces on the board.  The board
contents are specified starting with the eighth rank and ending with the first
rank.  For each rank, the squares are specified from file a to file h.  White
pieces are identified by uppercase SAN piece letters ("PNBRQK") and black
pieces are identified by lowercase SAN piece letters ("pnbrqk").  Empty squares
are represented by the digits one through eight; the digit used represents the
count of contiguous empty squares along a rank.  A solidus character "/" is
used to separate data of adjacent ranks.

piece placement specification of the initial chess position:

rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR

-------------------------------------------------------------------------------
Field 2: Active color
-------------------------------------------------------------------------------
The second field represents the active color.  A lower case "w" is used if
White is to move; a lower case "b" is used if Black is the active player.

-------------------------------------------------------------------------------
Field 3: Castling availability
-------------------------------------------------------------------------------
The third field represents castling availability.  This indicates potential
future castling that may of may not be possible at the moment due to blocking
pieces or enemy attacks.  If there is no castling availability for either side,
the single character symbol "-" is used.  Otherwise, a combination of from one
to four characters are present.  If White has kingside castling availability,
the uppercase letter "K" appears.  If White has queenside castling
availability, the uppercase letter "Q" appears.  If Black has kingside castling
availability, the lowercase letter "k" appears.  If Black has queenside
castling availability, then the lowercase letter "q" appears.  Those letters
which appear will be ordered first uppercase before lowercase and second
kingside before queenside.  There is no white space between the letters.

-------------------------------------------------------------------------------
Field 4: En passant target square
-------------------------------------------------------------------------------
The fourth field is the en passant target square.  If there is no en passant
target square then the single character symbol "-" appears.  If there is an en
passant target square then is represented by a lowercase file character
immediately followed by a rank digit.  Obviously, the rank digit will be "3"
following a white pawn double advance (Black is the active color) or else be
the digit "6" after a black pawn double advance (White being the active color).

An en passant target square is given if and only if the last move was a pawn
advance of two squares.  Therefore, an en passant target square field may have
a square name even if there is no pawn of the opposing side that may
immediately execute the en passant capture.

-------------------------------------------------------------------------------
Field 5: Halfmove clock
-------------------------------------------------------------------------------
The fifth field is a nonnegative integer representing the halfmove clock.  This
number is the count of halfmoves (or ply) since the last pawn advance or
capturing move.  This value is used for the fifty move draw rule.


-------------------------------------------------------------------------------
Field 6: Fullmove number
-------------------------------------------------------------------------------

The sixth and last field is a positive integer that gives the fullmove number.
This will have the value "1" for the first move of a game for both White and
Black.  It is incremented by one immediately after each move by Black.


-------------------------------------------------------------------------------
Examples
-------------------------------------------------------------------------------
Here's the FEN for the starting position:

rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1

And after the move 1. e4:

rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq e3 0 1

And then after 1. ... c5:

rnbqkbnr/pp1ppppp/8/2p5/4P3/8/PPPP1PPP/RNBQKBNR w KQkq c6 0 2

And then after 2. Nf3:

rnbqkbnr/pp1ppppp/8/2p5/4P3/5N2/PPPP1PPP/RNBQKB1R b KQkq - 1 2

For two kings on their home squares and a white pawn on e2 (White to move) with
thirty eight full moves played with five halfmoves since the last pawn move or
capture:

4k3/8/8/8/8/8/4P3/4K3 w - - 5 39

-------------------------------------------------------------------------------
IMPORTANT NOTE:
-------------------------------------------------------------------------------
If you use FEN notations within the book compiler inputfile you have to
encapsulate the notation in brackets and quotes like this:

[FEN "4k3/8/8/8/8/8/4P3/4K3 w - - 5 39]

