/******************************************************************************
*
* project name:    TI-Chess / BookBuilder
* file name:       board.c
* initial date:    23/10/2002
* author:          thomas.nussbaumer@gmx.net
* description:     board handling / move execution / FEN & PGN parsing etc.
*
* $Id: board.c,v 1.5 2002/10/24 14:35:28 tnussb Exp $
*
******************************************************************************/

/*---------------------------------------------------------------------------*/
/* initial board setup                                                       */
/*---------------------------------------------------------------------------*/
const char board_setup[BOARD_SIZE] =  {
OUTSIDE,OUTSIDE,OUTSIDE, OUTSIDE, OUTSIDE,OUTSIDE,OUTSIDE, OUTSIDE, OUTSIDE,OUTSIDE,
OUTSIDE,OUTSIDE,OUTSIDE, OUTSIDE, OUTSIDE,OUTSIDE,OUTSIDE, OUTSIDE, OUTSIDE,OUTSIDE,
OUTSIDE,W_ROOK, W_KNIGHT,W_BISHOP,W_QUEEN,W_KING, W_BISHOP,W_KNIGHT,W_ROOK, OUTSIDE,
OUTSIDE,W_PAWN, W_PAWN,  W_PAWN,  W_PAWN, W_PAWN, W_PAWN,  W_PAWN,  W_PAWN, OUTSIDE,
OUTSIDE,EMPTY,  EMPTY,   EMPTY,   EMPTY,  EMPTY,  EMPTY,   EMPTY,   EMPTY,  OUTSIDE,
OUTSIDE,EMPTY,  EMPTY,   EMPTY,   EMPTY,  EMPTY,  EMPTY,   EMPTY,   EMPTY,  OUTSIDE,
OUTSIDE,EMPTY,  EMPTY,   EMPTY,   EMPTY,  EMPTY,  EMPTY,   EMPTY,   EMPTY,  OUTSIDE,
OUTSIDE,EMPTY,  EMPTY,   EMPTY,   EMPTY,  EMPTY,  EMPTY,   EMPTY,   EMPTY,  OUTSIDE,
OUTSIDE,B_PAWN, B_PAWN,  B_PAWN,  B_PAWN, B_PAWN, B_PAWN,  B_PAWN,  B_PAWN, OUTSIDE,
OUTSIDE,B_ROOK, B_KNIGHT,B_BISHOP,B_QUEEN,B_KING, B_BISHOP,B_KNIGHT,B_ROOK, OUTSIDE,
OUTSIDE,OUTSIDE,OUTSIDE, OUTSIDE, OUTSIDE,OUTSIDE,OUTSIDE, OUTSIDE, OUTSIDE,OUTSIDE,
OUTSIDE,OUTSIDE,OUTSIDE, OUTSIDE, OUTSIDE,OUTSIDE,OUTSIDE, OUTSIDE, OUTSIDE,OUTSIDE};


/*---------------------------------------------------------------------------*/
/* move generator tables                                                     */
/*---------------------------------------------------------------------------*/
const char offset_vals[NR_DIRS] = {
   -9,-11,9,11,                    /* bishop directions  */
   -1,10,1,-10,                    /* rook               */
   19,21,12,-8,-19,-21,-12,8};     /* knight             */

const figoffset_t figure_offsets[NR_FIGS] = {
   {0,0,FALSE},   /* empty field                         */
   {-1,-1,FALSE}, /* pawn moves are generated separately */
   {4,7,TRUE},    /* rook                                */
   {0,3,TRUE},    /* bishop                              */
   {8,15,FALSE},  /* knight                              */
   {0,7,TRUE},    /* queen                               */
   {0,7,FALSE}};  /* king                                */

const char fig_symbols[2][NR_FIGS*2-1] = {
   {'K','Q','N','B','R','P','.','P','R','B','N','Q','K'}, // uppercase symbols
   {'k','q','n','b','r','p','.','P','R','B','N','Q','K'}  // lowercase symbols
};

#define NR_SYMBOLS 6

const char input_symbols[2][NR_SYMBOLS] = {
{'K','Q','N','B','R','P'},  // english input
{'K','D','S','L','T','B'}   // german input
};


#define UPPERCASE 0
#define LOWERCASE 1
#define FIG2SYM(lo_up,f)  fig_symbols[lo_up][(f)+6]

int    debug_line;
char*  debug_token;

#define ISGAMELINE(_l_)           (_l_==debug_line)
#define ISGAMELINETOKEN(_l_,_t_)  ((_l_==debug_line) && !strcmp(_t_,debug_token))


int    ply_count;
char   board[BOARD_SIZE];
int    white_king_pos;
int    black_king_pos;
int    ep_field;
int    act_color;
int    white_castling_long;
int    white_castling_short;
int    black_castling_long;
int    black_castling_short;
int    ply50_count;
move_t valid_moves[MAX_STACK];
int    valid_moves_count;
char   move_text[256];

unsigned long long active_hashcode;

void   Field2Notation(int field, char* notation);
short  AttacksField(short field, short side);
void   InitBoard(void);


//=============================================================================
// add position to corresponding linked list
//=============================================================================
void AddActivePosition(MOVE_T* move) {
    POSITION_T*        tmp = (act_color == WHITE) ? root_white : root_black;
    MOVE_T*            tm;
    unsigned long long hashcode = CalcHashcode(board);

    if (param_noti89 && param_noti92p) return;

    while (tmp) {
       if (active_hashcode == tmp->hashcode) {
           if (act_color == tmp->side_to_move                    &&
               (!memcmp(board,tmp->board,BOARD_SIZE))            &&
               ep_field == tmp->epfield                          &&
               white_castling_long == tmp->castling_white_long   &&
               white_castling_short == tmp->castling_white_short &&
               black_castling_long == tmp->castling_black_long   &&
               black_castling_short == tmp->castling_black_short)
           {
               // ok - this position is already in the database ...
               // check if the move is also in the database
               MOVE_T* m = tmp->moves;
               while (m) {
                  if (m->from == move->from &&
                      m->to   == move->to   &&
                      m->promote == move->promote)
                  {
                      //printf("move already in list. skip ....\n");
                      return;
                  }
                  m = m->next;
               }
               // move not there ... add it to list ...
               m = tmp->moves;
               tmp->nr_moves++;

               if (act_color == WHITE) nr_moves_white++;
               else                    nr_moves_black++;

               while (m->next) m = m->next;
               tm = (MOVE_T*)malloc(sizeof(MOVE_T));
               memcpy(tm,move,sizeof(MOVE_T));
               m->next = tm;
               return;
           }
       }
       tmp = tmp->next;
    }

    if (!(tmp =(POSITION_T*)malloc(sizeof(POSITION_T)))) {
        EmergencyExit("ERROR: out of memory\n"); // exits program
    }
    memset(tmp,0,sizeof(POSITION_T));
    tmp->hashcode = active_hashcode;
    memcpy(tmp->board,board,BOARD_SIZE);
    tmp->epfield = ep_field;
    tmp->side_to_move = act_color;
    tmp->castling_white_long  = white_castling_long;
    tmp->castling_white_short = white_castling_short;
    tmp->castling_black_long  = black_castling_long;
    tmp->castling_black_short = black_castling_short;
    tmp->nr_moves = 1;

    if (act_color == WHITE) {
        nr_moves_white++;
        nr_positions_white++;
    }
    else {
        nr_moves_black++;
        nr_positions_black++;
    }

    if (!(tm = (MOVE_T*)malloc(sizeof(MOVE_T)))) {
        EmergencyExit("ERROR: out of memory\n"); // exits program
    }
    memcpy(tm,move,sizeof(MOVE_T));
    tmp->moves = tm;

    if (act_color == WHITE && !root_white) {
        root_white = tmp;
    }
    else if (act_color == BLACK && !root_black) {
        root_black = tmp;
    }
    else {
        POSITION_T* tmp2 = (act_color == WHITE) ? root_white : root_black;
        while (tmp2->next) tmp2 = tmp2->next;
        tmp2->next = tmp;
    }
}


//=============================================================================
// prints board and position parameters
//=============================================================================
void PrintBoard(FILE* fp) {
    int x,y;

    for (y=7;y>=0;y--) {
        for (x=0;x<8;x++) {
            fprintf(fp,"%c",FIG2SYM(LOWERCASE,board[21+x+y*10]));
        }
        fprintf(fp,"%c\n",'1'+y);
    }
    fprintf(fp,"abcdefgh\n");

    fprintf(fp,"hashcode=%s\n",Hashcode2String(active_hashcode));
    fprintf(fp,"ply=%d ply50=%d ep=%c%c castling=",ply_count,ply50_count,
    (ep_field != ILLEGAL)?((ep_field-21)%10)+'a':'-',
    (ep_field != ILLEGAL)?((ep_field-21)/10)+'1':'-');
    if (!white_castling_long && !white_castling_short &&
        !black_castling_long && !black_castling_short)
    {
        fprintf(fp,"-\n");
    }
    else {
        if (white_castling_long)  fprintf(fp,"Q");
        if (white_castling_short) fprintf(fp,"K");
        if (black_castling_long)  fprintf(fp,"q");
        if (black_castling_short) fprintf(fp,"k");
        fprintf(fp,"\n");
    }
}

//=============================================================================
// sets the board content taking the inverse FEN notation into account
//=============================================================================
int SetBoardField(int current_field,char figure,int repeat) {
    int actfield;

    for (actfield=current_field;actfield<current_field+repeat;actfield++) {
        int col = actfield % 8;
        int row = 7-actfield/8; // INVERTED!! That's FEN ;-)
        int idx = 21+row*10+col;

        if (idx >= BOARD_SIZE || board_setup[idx] == OUTSIDE) return 0;
        board[idx] = figure;

        if (figure == W_KING)      white_king_pos = idx;
        else if (figure == B_KING) black_king_pos = idx;


    }
    return 1;
}


//=============================================================================
// parses figure positions (field 1 of FEN description)
// returns 1 if position is okay
//=============================================================================
int ParseFigurePositions(char* position) {
    int current_field = 0;

    memset(board,OUTSIDE,BOARD_SIZE);

    do {
         switch(*position) {
             case 'p': if (!SetBoardField(current_field,B_PAWN,1))   return 0;current_field++;break;
             case 'r': if (!SetBoardField(current_field,B_ROOK,1))   return 0;current_field++;break;
             case 'n': if (!SetBoardField(current_field,B_KNIGHT,1)) return 0;current_field++;break;
             case 'b': if (!SetBoardField(current_field,B_BISHOP,1)) return 0;current_field++;break;
             case 'q': if (!SetBoardField(current_field,B_QUEEN,1))  return 0;current_field++;break;
             case 'k': if (!SetBoardField(current_field,B_KING,1))   return 0;current_field++;break;
             case 'P': if (!SetBoardField(current_field,W_PAWN,1))   return 0;current_field++;break;
             case 'R': if (!SetBoardField(current_field,W_ROOK,1))   return 0;current_field++;break;
             case 'N': if (!SetBoardField(current_field,W_KNIGHT,1)) return 0;current_field++;break;
             case 'B': if (!SetBoardField(current_field,W_BISHOP,1)) return 0;current_field++;break;
             case 'Q': if (!SetBoardField(current_field,W_QUEEN,1))  return 0;current_field++;break;
             case 'K': if (!SetBoardField(current_field,W_KING,1))   return 0;current_field++;break;
             case '1': if (!SetBoardField(current_field,EMPTY,1))    return 0;current_field++;break;
             case '2': if (!SetBoardField(current_field,EMPTY,2))    return 0;current_field+=2;break;
             case '3': if (!SetBoardField(current_field,EMPTY,3))    return 0;current_field+=3;break;
             case '4': if (!SetBoardField(current_field,EMPTY,4))    return 0;current_field+=4;break;
             case '5': if (!SetBoardField(current_field,EMPTY,5))    return 0;current_field+=5;break;
             case '6': if (!SetBoardField(current_field,EMPTY,6))    return 0;current_field+=6;break;
             case '7': if (!SetBoardField(current_field,EMPTY,7))    return 0;current_field+=7;break;
             case '8': if (!SetBoardField(current_field,EMPTY,8))    return 0;current_field+=8;break;
             case '/': break;
             default:  return 0;  // invalid character in input
         }
         position++;
    }
    while (current_field < 64);
    return 1;
}


//=============================================================================
// parses castling states (field 3 of FEN description)
// returns 1 castling states are okay
//=============================================================================
int ParseCastlingStates(char* input) {
    white_castling_long  = 0;
    white_castling_short = 0;
    black_castling_long  = 0;
    black_castling_short = 0;

    if (*input == 0)   return 0;  // not even a '-' .... invalid!
    if (*input == '-') return 1;

    //printf("castle states = [%s]\n",input);

    do {
        switch(*input) {
            case 'K': white_castling_short = TRUE; break;
            case 'Q': white_castling_long  = TRUE; break;
            case 'k': black_castling_short = TRUE; break;
            case 'q': black_castling_long  = TRUE; break;
            case 0:   //printf("%d %d %d %d\n",white_castling_short,white_castling_long,black_castling_short,black_castling_long);
                      return 1;
            default:  return 0;  // some unknown character found!
        }
        input++;
    }
    while (1);

    return 0; // just for the compiler ... we'll never come here ...
}


//=============================================================================
// parses a FEN position description
//=============================================================================
int ParseFEN(char* s) {
    char *token;
    int  count = 0;

    strtrim(s); // trim input

    token = strtok(s," ");

    do {
        if (!token && count < 6) return 0;

        //printf("parsing field %d (%s)\n",count+1,token);

        switch(count) {
            case 0: if (!ParseFigurePositions(token)) return 0; break;
            case 1: if (token[0] == 'w')      {act_color = WHITE; break;}
                    else if (token[0] == 'b') {act_color = BLACK; break;}
                    else return 0;
            case 2: if (!ParseCastlingStates(token)) return 0;break;
            case 3: if (token[0] == '-') {ep_field = ILLEGAL; break;}
                    if (token[0] == 0) return 0;
                    token[0]=tolower(token[0]);
                    if (token[0] < 'a' || token[0] > 'h') return 0;
                    if (token[1] == 0) return 0;
                    token[1]=tolower(token[1]);
                    if (token[1] < '1' || token[1] > '8') return 0;
                    ep_field = 21+token[0]-'a' + (token[1]-'1')*10;
                    break;
            case 4: if (sscanf(token,"%d",&ply50_count)!=1) return 0; break;
            case 5: if (sscanf(token,"%d",&ply_count)!=1) return 0;
                    ply_count = ply_count*2 - 1;
                    if (ply_count < 0) ply_count = 1;
                    if (act_color == BLACK) ply_count++;
                    break;
        }
        count++;
        if (count == 6) return 1;
        token = strtok(0," ");
    }
    while(1);
    return 0; // we'll never come here ...
}



//=============================================================================
//
//=============================================================================
int InitBoardWithFEN(char* fen,int line_number) {
    char tmpbuffer[200];
    //printf("[line: %04d] FEN=%s\n",line_number,fen);

    if (!ParseFEN(fen)) {
        sprintf(tmpbuffer,"ERROR: invalid FEN at line %d\n",line_number);
        WriteLog(tmpbuffer,MIRROR_TO_STDERR);
        if (!param_dontstop) exit(1);
        else return 0;
    }

    active_hashcode = CalcHashcode(board);
    //PrintBoard(stderr);
    return 1;
}

//=============================================================================
//
//=============================================================================
void InitBoard(void) {
    short i;

    for (i=0;i<BOARD_SIZE;i++) board[i] = board_setup[i];
    white_king_pos       = E1;
    black_king_pos       = E8;
    ep_field             = ILLEGAL;
    act_color            = WHITE;
    white_castling_long  = TRUE;
    white_castling_short = TRUE;
    black_castling_long  = TRUE;
    black_castling_short = TRUE;
    ply50_count          = 0;
    ply_count            = 1;

    active_hashcode = CalcHashcode(board);
    //PrintBoard(stderr);
}


//=============================================================================
//
//=============================================================================
void InitStack(void) {
    valid_moves_count = 0;
    memset(valid_moves,0,sizeof(move_t)*MAX_STACK);
}


//=============================================================================
//
//=============================================================================
void Field2Notation(int field, char* notation) {
    notation[1] = (field-21)/10+'1';
    notation[0] = (field-21)%10+'a';
    notation[2] = 0;
}


//=============================================================================
//
//=============================================================================
char* Move2String(move_t* m) {
    char kill_or_not = (m->killed_fig != EMPTY) ? 'x' : '-';
    char from_notation[3];
    char to_notation[3];
    char promote = (m->promoted_fig != EMPTY) ? FIG2SYM(UPPERCASE,m->promoted_fig) : ' ';
    char from    = FIG2SYM(UPPERCASE,m->fig);

    if (m->castling == CASTLING_LONG) {
        sprintf(move_text,"O-O-O  ");
        return move_text;
    }
    else if (m->castling == CASTLING_SHORT) {
        sprintf(move_text,"O-O    ");
        return move_text;
    }

    Field2Notation(m->from,from_notation);
    Field2Notation(m->to,to_notation);
    sprintf(move_text,"%c%s%c%s%c",from,from_notation,kill_or_not,to_notation,promote);
    return move_text;
}


//=============================================================================
//
//=============================================================================
void PrintMoveStack(FILE* fp) {
    int i;
    for (i=0;i<valid_moves_count;i++) {
        if (i && (i % 4)==0) fprintf(fp,"\n");
        fprintf(fp,"[%03d] %s ",i+1,Move2String(&valid_moves[i]));
    }
    fprintf(fp,"\n");
}


//=============================================================================
//
//=============================================================================
void PutMoveOnStack(int from, int to, int epfield, int killed_figure,int castling,char promote) {
    short   figure;
    move_t* tmpmove;

    figure = board[from];

    if (killed_figure == W_KING || killed_figure == B_KING) {
        return; // cannot kill a King!
    }

    tmpmove = &valid_moves[valid_moves_count];

    tmpmove->fig          = figure;
    tmpmove->from         = from;
    tmpmove->to           = to;
    tmpmove->killed_fig   = killed_figure;
    tmpmove->promoted_fig = promote;
    tmpmove->castling     = castling;
    tmpmove->ep_field     = epfield;

    if (figure == W_PAWN || figure == B_PAWN || killed_figure != EMPTY) {
        tmpmove->count = 0;
    }
    else {
       tmpmove->count = ply50_count+1;
    }

    if (tmpmove->castling != CASTLING_NONE) {
        // NOTE: we don't check castling moves further. They get already checked
        //       by the move generator
        valid_moves_count++;
    }
    else {
        // try to execute this move and see if the other side still attacks the king!
        char old_from    = board[tmpmove->from];
        char old_to      = board[tmpmove->to];
        int  ep_pawn_pos = -1;
        char ep_fig;
        int  king_pos;

        board[tmpmove->from] = EMPTY;
        board[tmpmove->to]   = (tmpmove->promoted_fig != EMPTY) ? tmpmove->promoted_fig : old_from;

        if (act_color == WHITE) {
            // there is an ep field active and a WHITE pawn moves to it ...
            if (ep_field != ILLEGAL     &&
                tmpmove->to == ep_field &&
                tmpmove->fig == W_PAWN)
            {
                ep_pawn_pos = tmpmove->to-10;
                board[ep_pawn_pos] = EMPTY;
            }

            king_pos = (tmpmove->fig == W_KING) ? tmpmove->to : white_king_pos;

            //if (ISGAMELINETOKEN(5355,"Nfd2")) {
            //    printf("valid move: %s kingpos = %c%c\n",Move2String(tmpmove),
            //    (king_pos-21)%10+'a',(king_pos-21)/10+'1');
            //}

            if (!AttacksField(king_pos,BLACK)) {
                valid_moves_count++; // just count if out of chess!
            }
        }
        else {
            if (ep_field != ILLEGAL &&
                tmpmove->to == ep_field &&
                tmpmove->fig == B_PAWN)
            {
                ep_pawn_pos = tmpmove->to+10;
                board[ep_pawn_pos] = EMPTY;
            }

            king_pos = (tmpmove->fig == B_KING) ? tmpmove->to : black_king_pos;

            if (!AttacksField(king_pos,WHITE)) {
                valid_moves_count++; // just count if out of chess!
            }
        }


        board[tmpmove->from] = old_from;
        board[tmpmove->to]   = old_to;
        if (ep_pawn_pos != -1) {
            board[ep_pawn_pos] = (act_color == WHITE) ? B_PAWN : W_PAWN;
        }
    }

    if (valid_moves_count == MAX_STACK) {
        EmergencyExit("FATAL: move stack overflow!!\n");
    }
}


//=============================================================================
// executes a move
//=============================================================================
void ExecuteMove(move_t* m) {
    MOVE_T tmpmove;

    tmpmove.from    = m->from;
    tmpmove.to      = m->to;
    switch(abs(m->promoted_fig)) {
        case W_QUEEN:  tmpmove.promote = 'q';break;
        case W_ROOK:   tmpmove.promote = 'r';break;
        case W_BISHOP: tmpmove.promote = 'b';break;
        case W_KNIGHT: tmpmove.promote = 'n';break;
        default:       tmpmove.promote = 0;break;
    }
    tmpmove.next = 0;

    //printf("adding pos ...\n");
    AddActivePosition(&tmpmove);


    if (m->castling != CASTLING_NONE) {
        switch(m->castling) {
            case CASTLING_LONG:
                if (act_color == WHITE) {
                    board[E1] = EMPTY;
                    board[A1] = EMPTY;
                    board[C1] = W_KING;
                    board[D1] = W_ROOK;
                    white_king_pos = C1;
                }
                else {
                    board[E8] = EMPTY;
                    board[A8] = EMPTY;
                    board[C8] = B_KING;
                    board[D8] = B_ROOK;
                    black_king_pos = C8;
                }
                break;
            case CASTLING_SHORT:
                if (act_color == WHITE) {
                    board[E1] = EMPTY;
                    board[H1] = EMPTY;
                    board[G1] = W_KING;
                    board[F1] = W_ROOK;
                    white_king_pos = G1;
                }
                else {
                    board[E8] = EMPTY;
                    board[H8] = EMPTY;
                    board[G8] = B_KING;
                    board[F8] = B_ROOK;
                    black_king_pos = G8;
                }
                break;
        }

        if (act_color == WHITE) {
            white_castling_long  = 0;
            white_castling_short = 0;
            act_color = BLACK;
        }
        else {
            black_castling_long  = 0;
            black_castling_short = 0;
            act_color = WHITE;
        }
        ep_field = ILLEGAL;
        ply_count++;
        ply50_count++;
        active_hashcode = CalcHashcode(board);
        return;
    }

    if (m->killed_fig != EMPTY && board[m->to] == EMPTY) {
        // ep kill!

        //printf("EPKILL! %s (%d)\n",debug_token,debug_line);
        if (act_color == WHITE) {
            //printf("content = %d\n",board[m->to-10]);
            board[m->to-10] = EMPTY;
        }
        else {
            //printf("content = %d\n",board[m->to+10]);
            board[m->to+10] = EMPTY;
        }
    }

    // move the piece with possible promotion treatment
    board[m->from] = EMPTY;
    board[m->to] = (m->promoted_fig != EMPTY) ? m->promoted_fig : m->fig;

    // handle castle rights
    if (m->fig == W_ROOK) {
        if (m->from == A1) white_castling_long  = 0;
        if (m->from == H1) white_castling_short = 0;
    }
    else if (m->fig == B_ROOK) {
        if (m->from == A8) black_castling_long  = 0;
        if (m->from == H8) black_castling_short = 0;
    }
    else {
        if (m->to == A1) white_castling_long  = 0;
        if (m->to == H1) white_castling_short = 0;
        if (m->to == A8) black_castling_long  = 0;
        if (m->to == H8) black_castling_short = 0;
    }

    if (m->fig == W_KING) {
        white_castling_long  = 0;
        white_castling_short = 0;
        white_king_pos       = m->to;
    }
    else if (m->fig == B_KING) {
        black_castling_long  = 0;
        black_castling_short = 0;
        black_king_pos       = m->to;
    }

    // update ep, ply count and ply50 count
    ep_field = m->ep_field;
    ply_count++;
    ply50_count = m->count;
    act_color = (act_color == WHITE) ? BLACK : WHITE;
    active_hashcode = CalcHashcode(board);
}




//=============================================================================
//
//=============================================================================
short AttacksField(short field, short side) {
    short i,direction,to,slide,figure;

    //-------------------
    // !!!! SPEED UP !!!!
    //-------------------
    if (side == WHITE) {
        // test for pawn attack ...
        if (board[field-9]==W_PAWN || board[field-11]==W_PAWN) return TRUE;
        // test for knight attack ...
        for (i=8;i<16;i++) {
            figure = board[field+offset_vals[i]];
            if (figure==W_KNIGHT) return TRUE;
        }
    }
    else {
        // test for pawn attack ...
        if (board[field+9]==B_PAWN || board[field+11]==B_PAWN) return TRUE;
        // test for knight attack ...
        for (i=8;i<16;i++) {
            figure = board[field+offset_vals[i]];
            if (figure==B_KNIGHT) {
                return TRUE;
            }
        }
    }

    //------------------------------------------------------
    // test for sliding figures and king in all 8 directions
    //------------------------------------------------------
    for (i=0;i<8;i++) {
        to        = field;
        direction = offset_vals[i];
        slide     = 0;
slideforward:
        slide++;
        to+=direction;

        figure = board[to];

        if (figure==EMPTY)   goto slideforward; // slide again
        if (figure==OUTSIDE) continue;          // oops, outside !

        if (side==WHITE) {
            if (figure>0) {
                if (figure==W_KING) {
                    if (slide<=1) return TRUE;
                }
                else {
                    if (figure_offsets[figure].start<=i &&
                        figure_offsets[figure].end>=i)
                    {
                        return TRUE;
                    }
                }
           }
        }
        else {  // for black
            if (figure<0) {
                if (figure==B_KING) {
                    if (slide<=1) {
                        return TRUE;
                    }
                }
                else {
                    if (figure_offsets[-figure].start<=i &&
                        figure_offsets[-figure].end>=i)
                    {
                        return TRUE;
                    }
                }
            }
        }
    }

    // everything checked. nothing found.
    return FALSE;
}


//=============================================================================
// returns number of generated moves
//=============================================================================
int GenerateMoves(void) {
    short from,to,figure;
    short i,longstep,direction;

    InitStack();

    for (from=A1;from<=H8;from++) {
        figure = board[from];
        if (figure==EMPTY || figure==OUTSIDE) continue;

        // figure have to be of right color
        if((act_color==WHITE && figure<0) ||
           (act_color==BLACK && figure>0))
        {
            continue;
        }

        figure=abs(figure);   // kind of figure only matters with pawns

        if (figure==W_PAWN) {
            //----------------------------------------
            // treatment of white pawn ...
            //----------------------------------------
            if (act_color==WHITE) {
                // single step forward
                if (board[from+10]==EMPTY) {
                    // promotion ...
                    if (from>=A7) {
                        PutMoveOnStack(from,from+10,ILLEGAL,EMPTY,CASTLING_NONE,W_QUEEN);
                        PutMoveOnStack(from,from+10,ILLEGAL,EMPTY,CASTLING_NONE,W_ROOK);
                        PutMoveOnStack(from,from+10,ILLEGAL,EMPTY,CASTLING_NONE,W_KNIGHT);
                        PutMoveOnStack(from,from+10,ILLEGAL,EMPTY,CASTLING_NONE,W_BISHOP);
                    }
                    // no promotion
                    else {
                        // single step
                        PutMoveOnStack(from,from+10,ILLEGAL,EMPTY,CASTLING_NONE,EMPTY);
                        // double step
                        if (from<=H2 && board[from+20]==EMPTY) {
                            PutMoveOnStack(from,from+20,from+10,EMPTY,CASTLING_NONE,EMPTY);
                        }
                    }
                }

                // kill "right"
                if (board[from+11]<0) { // pawn may kill black figure
                    // additional promotion
                    if (from>=A7) {
                        PutMoveOnStack(from,from+11,ILLEGAL,board[from+11],CASTLING_NONE,W_QUEEN);
                        PutMoveOnStack(from,from+11,ILLEGAL,board[from+11],CASTLING_NONE,W_ROOK);
                        PutMoveOnStack(from,from+11,ILLEGAL,board[from+11],CASTLING_NONE,W_KNIGHT);
                        PutMoveOnStack(from,from+11,ILLEGAL,board[from+11],CASTLING_NONE,W_BISHOP);
                    }
                    // no promotion
                    else {
                        PutMoveOnStack(from,from+11,ILLEGAL,board[from+11],CASTLING_NONE,EMPTY);
                    }
                }

                // kill "left"
                if (board[from+9]<0) {  // other direction, too
                    // additional promotion
                    if (from>=A7) {
                        PutMoveOnStack(from,from+9,ILLEGAL,board[from+9],CASTLING_NONE,W_QUEEN);
                        PutMoveOnStack(from,from+9,ILLEGAL,board[from+9],CASTLING_NONE,W_ROOK);
                        PutMoveOnStack(from,from+9,ILLEGAL,board[from+9],CASTLING_NONE,W_KNIGHT);
                        PutMoveOnStack(from,from+9,ILLEGAL,board[from+9],CASTLING_NONE,W_BISHOP);
                    }
                    // no promotion
                    else {
                        PutMoveOnStack(from,from+9,ILLEGAL,board[from+9],CASTLING_NONE,EMPTY);
                    }
                }

                // EPKILL "right"
                if ((from+11)==ep_field) { // pawn may kill ep
                    PutMoveOnStack(from,from+11,ILLEGAL,B_PAWN,CASTLING_NONE,EMPTY);
                }
                // EPKILL "left"
                if ((from+9)==ep_field) { // pawn may kill ep
                    PutMoveOnStack(from,from+9,ILLEGAL,B_PAWN,CASTLING_NONE,EMPTY);
                }

            }

            //----------------------------------------
            // treatment of black pawn ...
            //----------------------------------------
            else if (act_color==BLACK) {
                if (board[from-10]==EMPTY) {
                    if (from<=H2) {
                        PutMoveOnStack(from,from-10,ILLEGAL,EMPTY,CASTLING_NONE,B_QUEEN);
                        PutMoveOnStack(from,from-10,ILLEGAL,EMPTY,CASTLING_NONE,B_ROOK);
                        PutMoveOnStack(from,from-10,ILLEGAL,EMPTY,CASTLING_NONE,B_KNIGHT);
                        PutMoveOnStack(from,from-10,ILLEGAL,EMPTY,CASTLING_NONE,B_BISHOP);
                    }
                    else {
                        PutMoveOnStack(from,from-10,ILLEGAL,EMPTY,CASTLING_NONE,EMPTY);
                        // double step possible?
                        if ((from>=A7)&&(board[from-20]==EMPTY)) {
                            PutMoveOnStack(from,from-20,from-10,EMPTY,CASTLING_NONE,EMPTY);
                        }
                    }
                }
                // have to check for border just for black pawns
                if (board[from-11]>0 && board[from-11]!=OUTSIDE) {
                    if (from<=H2) {
                        PutMoveOnStack(from,from-11,ILLEGAL,from-11,CASTLING_NONE,B_QUEEN);
                        PutMoveOnStack(from,from-11,ILLEGAL,from-11,CASTLING_NONE,B_ROOK);
                        PutMoveOnStack(from,from-11,ILLEGAL,from-11,CASTLING_NONE,B_KNIGHT);
                        PutMoveOnStack(from,from-11,ILLEGAL,from-11,CASTLING_NONE,B_BISHOP);
                    }
                    else {
                        PutMoveOnStack(from,from-11,ILLEGAL,from-11,CASTLING_NONE,EMPTY);
                    }
                }
                if (board[from-9]>0 && board[from-9]!=OUTSIDE) {
                    if (from<=H2) {
                        PutMoveOnStack(from,from-9,ILLEGAL,from-9,CASTLING_NONE,B_QUEEN);
                        PutMoveOnStack(from,from-9,ILLEGAL,from-9,CASTLING_NONE,B_ROOK);
                        PutMoveOnStack(from,from-9,ILLEGAL,from-9,CASTLING_NONE,B_KNIGHT);
                        PutMoveOnStack(from,from-9,ILLEGAL,from-9,CASTLING_NONE,B_BISHOP);
                    }
                    else {
                        PutMoveOnStack(from,from-9,ILLEGAL,from-9,CASTLING_NONE,EMPTY);
                    }
                }

                if ((from-11)==ep_field) { // pawn may kill ep
                    PutMoveOnStack(from,from-11,ILLEGAL,W_PAWN,CASTLING_NONE,EMPTY);
                }
                if ((from-9)==ep_field) { // pawn may kill ep
                    PutMoveOnStack(from,from-9,ILLEGAL,W_PAWN,CASTLING_NONE,EMPTY);
                }

            }
            continue;   // continue with next field
        }

        //----------------------------------------------------------------------
        // all other figure moves are calculated using the move offset table
        //----------------------------------------------------------------------
        longstep=figure_offsets[figure].longmove;
        for (i=figure_offsets[figure].start;i<=figure_offsets[figure].end;i++) {
            direction = offset_vals[i];
            to        = from;
slideforward:
            to += direction;
            if (board[to]==EMPTY) {
                PutMoveOnStack(from,to,ILLEGAL,EMPTY,CASTLING_NONE,EMPTY);
                if (longstep) { // bishop/rook/queen
                    goto slideforward;
                }
                else {  // knight/king
                    continue;
                }
            }
            if (board[to]==OUTSIDE) {
                continue;
            }

            // there is a figure. check for right color ...
            if ((act_color==WHITE && board[to]<0) ||
                (act_color==BLACK && board[to]>0))
            {
                PutMoveOnStack(from,to,ILLEGAL,board[to],CASTLING_NONE,EMPTY);
            }
            continue;
        }
    }

    //-------------------------------------------------------------------------
    // castling
    //-------------------------------------------------------------------------
    if (act_color==WHITE) {
        if (white_castling_short     &&
            board[F1]==EMPTY         &&
            board[G1]==EMPTY         &&
            !AttacksField(E1,BLACK)  &&
            !AttacksField(F1,BLACK)  &&
            !AttacksField(G1,BLACK))
        {
            PutMoveOnStack(E1,G1,ILLEGAL,EMPTY,CASTLING_SHORT,EMPTY);
        }
        if (white_castling_long     &&
            board[D1]==EMPTY        &&
            board[C1]==EMPTY        &&
            board[B1]==EMPTY        &&
            !AttacksField(E1,BLACK) &&
            !AttacksField(D1,BLACK) &&
            !AttacksField(C1,BLACK))
        {
            PutMoveOnStack(E1,C1,ILLEGAL,EMPTY,CASTLING_LONG,EMPTY);
        }
    }
    else {
        if (black_castling_short        &&
            board[F8]==EMPTY            &&
            board[G8]==EMPTY            &&
            !AttacksField(E8,WHITE)     &&
            !AttacksField(F8,WHITE)     &&
            !AttacksField(G8,WHITE))
        {
            PutMoveOnStack(E8,G8,ILLEGAL,EMPTY,CASTLING_SHORT,EMPTY);
        }
        if (black_castling_long      &&
            board[D8]==EMPTY         &&
            board[C8]==EMPTY         &&
            board[B8]==EMPTY         &&
            !AttacksField(E8,WHITE)  &&
            !AttacksField(D8,WHITE)  &&
            !AttacksField(C8,WHITE))
        {
            PutMoveOnStack(E8,C8,ILLEGAL,EMPTY,CASTLING_LONG,EMPTY);
        }
    }
    return valid_moves_count;
}


//=============================================================================
// try to parse a single PGN token and execute it
//=============================================================================
int ExecuteToken(char* token,int line) {
    int   i;
    int   n;
    char  figure = EMPTY;
    char  promoted;
    char  killed;
    int   dest;
    int   len;
    int   fromline;
    int   fromcolumn;
    int   fromfield;
    int   matching;
    int   matching_idx;
    char* c;
    char  postfix[255];
    int   nr_moves;
    char  tmpbuffer[255];

    // if we have reached the max ply setting stop
    if (param_maxply) {
        if (ply_count > param_maxply) return 0;
    }

    debug_token = token;
    nr_moves = GenerateMoves();

    if (strlen(token) > 254) {
        sprintf(tmpbuffer,"ERROR near line %d: token too long (> 254)\n",line);
        if (!param_dontstop) EmergencyExit(tmpbuffer);
        WriteLog(tmpbuffer,MIRROR_TO_STDERR);
        return 0;
    }

    //-------------------------------------------------------------------------
    // figure moves ...
    //-------------------------------------------------------------------------
    for (i=0;i<NR_SYMBOLS;i++) {
        if (token[0] == input_symbols[param_inputlang][i]) { //fig_symbols[UPPERCASE][i]) {
            switch(i) {
                case 0:  figure = (act_color == WHITE) ? W_KING : B_KING;
                         strcpy(postfix,&token[1]);
                         //printf("processing token %s (king move)\n",token);
                         break;
                case 1:  figure = (act_color == WHITE) ? W_QUEEN : B_QUEEN;
                         strcpy(postfix,&token[1]);
                         //printf("processing token %s (queen move)\n",token);
                         break;
                case 2:  figure = (act_color == WHITE) ? W_KNIGHT : B_KNIGHT;
                         strcpy(postfix,&token[1]);
                         //printf("processing token %s (knight move)\n",token);
                         break;
                case 3:  figure = (act_color == WHITE) ? W_BISHOP : B_BISHOP;
                         strcpy(postfix,&token[1]);
                         //printf("processing token %s (bishop move)\n",token);
                         break;
                case 4:  figure = (act_color == WHITE) ? W_ROOK : B_ROOK;
                         strcpy(postfix,&token[1]);
                         //printf("processing token %s (rook move)\n",token);
                         break;
                case 5:  figure = (act_color == WHITE) ? W_PAWN : B_PAWN;
                         strcpy(postfix,&token[1]);
                         //printf("processing token %s (pawn move)\n",token);
                         break;
            }
        }
    }

    //-------------------------------------------------------------------------
    // special tokens ...
    //-------------------------------------------------------------------------
    if (figure == EMPTY) {
        if (!strncmp(token,"O-O-O",5)) {
            //printf("processing token %s (long castling)\n",token);
            for (n=0;n<nr_moves;n++) {
                 if (valid_moves[n].castling == CASTLING_LONG) {
                     ExecuteMove(&valid_moves[n]);
                     return 1;
                 }
            }
            sprintf(tmpbuffer,"ERROR near line %d: %s can't castle long\n",line,(act_color == WHITE)?"WHITE":"BLACK");
            if (!param_dontstop) EmergencyExit(tmpbuffer);
            WriteLog(tmpbuffer,MIRROR_TO_STDERR);
            return 0;
        }
        else if (!strncmp(token,"O-O",3)) {
            //printf("processing token %s (short castling)\n",token);
            for (n=0;n<nr_moves;n++) {
                 if (valid_moves[n].castling == CASTLING_SHORT) {
                     ExecuteMove(&valid_moves[n]);
                     return 1;
                 }
            }

            sprintf(tmpbuffer,"ERROR near line %d: %s can't castle short\n",line,(act_color == WHITE)?"WHITE":"BLACK");
            if (!param_dontstop) EmergencyExit(tmpbuffer);
            WriteLog(tmpbuffer,MIRROR_TO_STDERR);
            return 0;
        }
        else if (token[0] >= 'a' && token[0] <= 'h') {
            //printf("processing token %s (pawn move)\n",token);
            figure = (act_color == WHITE)? W_PAWN : B_PAWN;
            strcpy(postfix,token);
        }
        else if (token[0] == '*') {
            //printf("processing token %s [ENDTOKEN]\n",token);
            return 0;
        }
        else if (!strcmp(token,"1-0")) {
            //printf("processing token %s [WHITE WINS]\n",token);
            return 0;
        }
        else if (!strcmp(token,"0-1")) {
            //printf("processing token %s [BLACK WINS]\n",token);
            return 0;
        }
        else if (!strcmp(token,"1/2-1/2")) {
            //printf("processing token %s [DRAW GAME]\n",token);
            return 0;
        }
        else {
            sprintf(tmpbuffer,"ERROR: AMBIGUOUS TOKEN (%s) found near line %d\n",token,line);
            if (!param_dontstop) EmergencyExit(tmpbuffer);
            WriteLog(tmpbuffer,MIRROR_TO_STDERR);
            return 0;
        }
    }

    //-------------------------------------------------------------------------
    // figure contains now the figure to move and postfix contains the move
    //-------------------------------------------------------------------------

    // remove any unimportant trailing characters
    c = postfix + strlen(postfix) - 1;
    while ((*c < '1' || *c > '8') &&
           (*c < 'a' || *c > 'h') &&
           *c != input_symbols[param_inputlang][1] &&  // queen
           *c != input_symbols[param_inputlang][2] &&  // knight
           *c != input_symbols[param_inputlang][3] &&  // bishop
           *c != input_symbols[param_inputlang][4] &&  // rook
           c != postfix)
    {
        *c-- = 0;
    }

    // setup promoted figure if there is any
    c = postfix + strlen(postfix) - 1;
    if (*c == input_symbols[param_inputlang][1]) {
        promoted = act_color == WHITE ? W_QUEEN  : B_QUEEN;
        *c = 0;
    }
    else if (*c == input_symbols[param_inputlang][2]) {
        promoted = act_color == WHITE ? W_KNIGHT : B_KNIGHT;
        *c = 0;
    }
    else if (*c == input_symbols[param_inputlang][3]) {
        promoted = act_color == WHITE ? W_BISHOP : B_BISHOP;
        *c = 0;
    }
    else if (*c == input_symbols[param_inputlang][4]) {
        promoted = act_color == WHITE ? W_ROOK   : B_ROOK;
        *c = 0;
    }
    else {
        promoted = EMPTY;
    }

    if (promoted != EMPTY) {
        if (abs(figure) != W_PAWN) {
            sprintf(tmpbuffer,"ERROR near line %d: can only promote pawns (%s)\n",line,token);
            if (!param_dontstop) EmergencyExit(tmpbuffer);
            WriteLog(tmpbuffer,MIRROR_TO_STDERR);
            return 0;
        }
        c--;
        if (*c == '=') *c = 0; // remove a possible '=' sign
    }

    len = strlen(postfix);

    // try to extract destination field
    if (len < 2 ||
        postfix[len-1] < '1' ||
        postfix[len-1] > '8' ||
        postfix[len-2] < 'a' ||
        postfix[len-2] > 'h')
    {
        sprintf(tmpbuffer,"ERROR near line %d: invalid token (%s) (no to field)\n",line,token);
        if (!param_dontstop) EmergencyExit(tmpbuffer);
        WriteLog(tmpbuffer,MIRROR_TO_STDERR);
        return 0;
    }

    dest = 21 + (postfix[len-1]-'1')*10 + postfix[len-2]-'a';

    killed     =  0;
    fromcolumn = -1;
    fromline   = -1;
    fromfield  = -1;

    //-------------------------------------------------------------------------
    // partitional specified moves of 3 characters like:
    // xe3, de3, 1e3
    //-------------------------------------------------------------------------
    if (len == 3) {
        if (postfix[0] == 'x') killed = 1;
        else if (postfix[0] >= 'a' && postfix[0] <= 'h') {
            fromcolumn = postfix[0] - 'a';
        }
        else if (postfix[0] >= '1' && postfix[0] <= '8') {
            fromline = postfix[0] - '1';
        }
        else {
            sprintf(tmpbuffer,"ERROR near line %d: invalid token (%s)\n",line,token);
            if (!param_dontstop) EmergencyExit(tmpbuffer);
            WriteLog(tmpbuffer,MIRROR_TO_STDERR);
            return 0;
        }
    }
    //-------------------------------------------------------------------------
    // partitional specified moves of 4 characters (kill moves) like:
    // dxe3, 1xe3
    //-------------------------------------------------------------------------
    else if (len == 4) {
        if (postfix[1] == 'x' && postfix[0] >= 'a' && postfix[0] <= 'h') {
            killed = 1;
            fromcolumn = postfix[0] - 'a';
        }
        else if (postfix[1] == 'x' && postfix[0] >= '1' && postfix[0] <= '8') {
            killed = 1;
            fromline = postfix[0] - '1';
        }
        else {
            sprintf(tmpbuffer,"ERROR near line %d: invalid token (%s)\n",line,token);
            if (!param_dontstop) EmergencyExit(tmpbuffer);
            WriteLog(tmpbuffer,MIRROR_TO_STDERR);
            return 0;
        }
    }
    //-------------------------------------------------------------------------
    // A fully specified move like:
    // d2xe3, d2-d3
    //-------------------------------------------------------------------------
    else if (len == 5) {
        if (postfix[0] >= 'a' && postfix[0] <= 'h' && postfix[1] >= '1' && postfix[1] <= '8') {
             fromfield = 21 + postfix[0] - 'a' + (postfix[1] - '1')*10;
             if (postfix[2] == 'x')      killed = 1;
             else if (postfix[2] == '-') killed = 0;
             else {
                 sprintf(tmpbuffer,"ERROR near line %d: invalid token (%s)\n",line,token);
                 if (!param_dontstop) EmergencyExit(tmpbuffer);
                 WriteLog(tmpbuffer,MIRROR_TO_STDERR);
                 return 0;
             }
        }
        else {
            sprintf(tmpbuffer,"ERROR near line %d: invalid token (%s)\n",line,token);
            if (!param_dontstop) EmergencyExit(tmpbuffer);
            WriteLog(tmpbuffer,MIRROR_TO_STDERR);
            return 0;
        }
    }

    matching = 0;
    for (n=0;n<nr_moves;n++) {
        if (valid_moves[n].to != dest)    continue;
        if (valid_moves[n].fig != figure) continue;
        if (killed && valid_moves[n].killed_fig == EMPTY) continue;
        if (promoted != EMPTY && valid_moves[n].promoted_fig != promoted) continue;
        if (fromfield != -1 && valid_moves[n].from != fromfield) continue;
        if (fromcolumn != -1 && fromcolumn != ((valid_moves[n].from - 21)%10)) continue;
        if (fromline != -1 && fromline != ((valid_moves[n].from - 21)/10)) continue;
        matching++;
        matching_idx = n;
    }

    if (matching == 1) {
        ExecuteMove(&valid_moves[matching_idx]);
        return 1;
    }

    if (!matching) {
        sprintf(tmpbuffer,"ERROR near line %d: invalid %s move (%s)\n",line,
                act_color == WHITE ? "WHITE":"BLACK",token);
    }
    else {
        sprintf(tmpbuffer,"ERROR near line %d: more than one move (%d) matches notation (%s)\n",line,matching,token);
    }

    WriteLog(tmpbuffer,MIRROR_TO_STDERR);

    WriteLog("\n[BOARD]\n\n",MIRROR_TO_STDERR);
    PrintBoard(stderr);
    if (logfile) PrintBoard(logfile);
    WriteLog("\n[VALID MOVES]\n\n",MIRROR_TO_STDERR);
    PrintMoveStack(stderr);
    if (logfile) PrintMoveStack(logfile);

    if (!param_dontstop) exit(1);

    return 0;
}


//=============================================================================
//
//=============================================================================
void PlayMoves(char* moves,int line) {
    char* token;
    int   movecount = 0;
    char  tmpbuffer[255];

    debug_line = line;

    token = strtok(moves,". ");

    while (token) {
        if (!strcmp(token,"1-0") ||
            !strcmp(token,"0-1") ||
            !strcmp(token,"1/2-1/2"))
        {
            return;
        }

        if (sscanf(token,"%d",&movecount) == 1) {
            if (act_color != WHITE) {
                sprintf(tmpbuffer,"ERROR (near line %d): movecount %d parsed, but not WHITE to move (token=%s)\n",line,movecount,token);
                if (!param_dontstop) EmergencyExit(tmpbuffer);
                return;
            }
        }
        else {
            if (!ExecuteToken(token,line)) return;
        }
        token = strtok(0,". ");
    }
}

//#############################################################################
//###################### NO MORE FAKES BEYOND THIS LINE #######################
//#############################################################################
//
//=============================================================================
// Revision History
//=============================================================================
//
// $Log: board.c,v $
// Revision 1.5  2002/10/24 14:35:28  tnussb
// treatment of parameter maxply (number of max.plies per sequence) added
//
// Revision 1.4  2002/10/24 11:44:32  tnussb
// (1) ep treatment fixed
// (2) promotion postfixes including an equal sign like "=Q" are accepted now
// (3) -noparse will not allocate memory for positions anymore. this way I can
//     test the PGN parser with very large inputfile without running out of
//     memory or slowing down my machine too much
//
// Revision 1.3  2002/10/24 09:53:29  tnussb
// (1) can parse now fully qualified PGN moves like Qe2-f3, too
// (2) parameter -onlyparse added
// (3) parameter -english and -german added which can be used to switch to
//     the input move notation to german (different figure symbols)
//
// Revision 1.2  2002/10/23 21:42:34  tnussb
// modifications for parameter -dontstop
//
// Revision 1.1  2002/10/23 21:03:15  tnussb
// initial check-in
//
//
