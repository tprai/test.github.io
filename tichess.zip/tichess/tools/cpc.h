/******************************************************************************
*
* project name:    TI-Chess / Chess Puzzle Compiler
* file name:       cpc.h
* initial date:    04/10/2002
* author:          thomas.nussbaumer@gmx.net
* description:     chess puzzle compiler's header file
*
*
* $Id: cpc.h,v 1.1 2002/10/23 21:03:15 tnussb Exp $
*
******************************************************************************/

#ifndef __CPC_H__
#define __CPC_H__

//-----------------------------------------------------------------------------
// converts 4 character into an unsigned long (nice macro for magic markers)
//-----------------------------------------------------------------------------
#define C4UL(a,b,c,d)   ((((unsigned long)(a)) << 24) | \
                         (((unsigned long)(b)) << 16) | \
                         (((unsigned long)(c)) <<  8) | \
                         (((unsigned long)(d))))


//-----------------------------------------------------------------------------
//  figure defines (used also by tichess)
//-----------------------------------------------------------------------------
#define BLACK_KING     -6
#define BLACK_QUEEN    -5
#define BLACK_KNIGHT   -4
#define BLACK_BISHOP   -3
#define BLACK_ROOK     -2
#define BLACK_PAWN     -1
#define EMPTY_FIELD     0
#define WHITE_PAWN      1
#define WHITE_ROOK      2
#define WHITE_BISHOP    3
#define WHITE_KNIGHT    4
#define WHITE_QUEEN     5
#define WHITE_KING      6


//-----------------------------------------------------------------------------
// "side to move" defines
//-----------------------------------------------------------------------------
#define WHITE 0
#define BLACK 1


//-----------------------------------------------------------------------------
// field numbers (differs from tichess which uses an oversized board)
//-----------------------------------------------------------------------------
#define A1 0
#define B1 1
#define C1 2
#define D1 3
#define E1 4
#define F1 5
#define G1 6
#define H1 7
#define A2 8
#define B2 9
#define C2 10
#define D2 11
#define E2 12
#define F2 13
#define G2 14
#define H2 15
#define A3 16
#define B3 17
#define C3 18
#define D3 19
#define E3 20
#define F3 21
#define G3 22
#define H3 23
#define A4 24
#define B4 25
#define C4 26
#define D4 27
#define E4 28
#define F4 29
#define G4 30
#define H4 31
#define A5 32
#define B5 33
#define C5 34
#define D5 35
#define E5 36
#define F5 37
#define G5 38
#define H5 39
#define A6 40
#define B6 41
#define C6 42
#define D6 43
#define E6 44
#define F6 45
#define G6 46
#define H6 47
#define A7 48
#define B7 49
#define C7 50
#define D7 51
#define E7 52
#define F7 53
#define G7 54
#define H7 55
#define A8 56
#define B8 57
#define C8 58
#define D8 59
#define E8 60
#define F8 61
#define G8 62
#define H8 63

//-----------------------------------------------------------------------------
// a compressed position is a buffer which is 22 bytes long and contains the
// following data:
//
// 164 bits position
//   1 bit  epfield valid flag
//   3 bits epfield  (there are ONLY 8 possible epfields for each side)
//   1 bit  side to move
//   4 bits castle states white/black
//  (3 bits unused)
//-----------------------------------------------------------------------------
#define COMPRESSED_POS_SIZE 22

//-----------------------------------------------------------------------------
// a compressed move is an unsigned short and contains the following data:
//
// 6 bits  from_field
// 6 bits  to_field
// 2 bits  promotion_figure
// 1 bit   is_promotion_move flag
// 1 bit   exists more moves?
// (ALL 16 bits used)
//
// a pawn can be promoted to one of the followings figures:
//
// (Q,R,N,B)
//-----------------------------------------------------------------------------


#define TT_MAX_MEMBLOCK  65520
#define TT_MAX_OTHDATA   (TT_MAX_MEMBLOCK - 2 - 7)

#define CALC_TI89        0
#define CALC_TI92P       1
#define SIGNATURE_TI89   "**TI89**"
#define SIGNATURE_TI92P  "**TI92P*"
#define DEFAULT_FOLDER   "tict"


#endif


//#############################################################################
//###################### NO MORE FAKES BEYOND THIS LINE #######################
//#############################################################################
//
//=============================================================================
// Revision History
//=============================================================================
//
// $Log: cpc.h,v $
// Revision 1.1  2002/10/23 21:03:15  tnussb
// initial check-in
//
//
//
