/******************************************************************************
*
* project name:    TI-Chess / BookBuilder
* file name:       board.h
* initial date:    23/10/2002
* author:          thomas.nussbaumer@gmx.net
* description:     header file for board.c
*
* $Id: board.h,v 1.1 2002/10/23 21:03:15 tnussb Exp $
*
******************************************************************************/

//-----------------------------------------------------------------------------
// generic constants
//-----------------------------------------------------------------------------
#define BOARD_SIZE   120     // dimension of extended chess board
#define NR_DIRS       16     // number of directions of all figures
#define NR_FIGS        7     // number of different figures (including NONE)
#define STACK_SIZE  1000     // size of move stack


//-----------------------------------------------------------------------------
// figure constants
//-----------------------------------------------------------------------------
#define B_KING     -6   // black figures (negative values)
#define B_QUEEN    -5
#define B_KNIGHT   -4
#define B_BISHOP   -3
#define B_ROOK     -2
#define B_PAWN     -1
#define EMPTY       0   // empty field
#define W_PAWN      1   // white figures (positive values)
#define W_ROOK      2
#define W_BISHOP    3
#define W_KNIGHT    4
#define W_QUEEN     5
#define W_KING      6
#define OUTSIDE   100   // outside real board


//-----------------------------------------------------------------------------
// field names (increasing readability)
//-----------------------------------------------------------------------------
#define  A1    21
#define  B1    22
#define  C1    23
#define  D1    24
#define  E1    25
#define  F1    26
#define  G1    27
#define  H1    28
#define  A2    31
#define  B2    32
#define  C2    33
#define  D2    34
#define  E2    35
#define  F2    36
#define  G2    37
#define  H2    38
#define  A3    41
#define  B3    42
#define  C3    43
#define  D3    44
#define  E3    45
#define  F3    46
#define  G3    47
#define  H3    48
#define  A4    51
#define  B4    52
#define  C4    53
#define  D4    54
#define  E4    55
#define  F4    56
#define  G4    57
#define  H4    58
#define  A5    61
#define  B5    62
#define  C5    63
#define  D5    64
#define  E5    65
#define  F5    66
#define  G5    67
#define  H5    68
#define  A6    71
#define  B6    72
#define  C6    73
#define  D6    74
#define  E6    75
#define  F6    76
#define  G6    77
#define  H6    78
#define  A7    81
#define  B7    82
#define  C7    83
#define  D7    84
#define  E7    85
#define  F7    86
#define  G7    87
#define  H7    88
#define  A8    91
#define  B8    92
#define  C8    93
#define  D8    94
#define  E8    95
#define  F8    96
#define  G8    97
#define  H8    98


//-----------------------------------------------------------------------------
// line and column names
//-----------------------------------------------------------------------------
#define A_COLUMN   1
#define B_COLUMN   2
#define C_COLUMN   3
#define D_COLUMN   4
#define E_COLUMN   5
#define F_COLUMN   6
#define G_COLUMN   7
#define H_COLUMN   8
#define ROW_1      2
#define ROW_2      3
#define ROW_3      4
#define ROW_4      5
#define ROW_5      6
#define ROW_6      7
#define ROW_7      8
#define ROW_8      9


//-----------------------------------------------------------------------------
// castling defines
//-----------------------------------------------------------------------------
#define CASTLING_NONE  0
#define CASTLING_SHORT 1
#define CASTLING_LONG  2


//-----------------------------------------------------------------------------
// color defines
//-----------------------------------------------------------------------------
#define WHITE    1
#define BLACK   -1


//-----------------------------------------------------------------------------
// logical values
//-----------------------------------------------------------------------------
#define TRUE           1
#define FALSE          0
#define ILLEGAL        0


//-----------------------------------------------------------------------------
// data type for stored moves (extended move_t)
//-----------------------------------------------------------------------------
typedef struct {
   char  fig;
   int   from;          // from field
   int   to;            // to field
   char  killed_fig;    // killed figure
   char  promoted_fig;  // promoted figure
   int   castling;      // kind of castling
   int   ep_field;      // enpassant field
   int   count;         // count for 50 ply rule
                        // No pawn moved or figure
                        // captured
                        // NOTE: 0x80 will be used
                        // for side marking
} move_t;


//-----------------------------------------------------------------------------
// index of figures in offset list and long/short marker (used by move gen.)
//-----------------------------------------------------------------------------
typedef struct {
   char start;
   char end;
   char longmove;
} figoffset_t;


//-----------------------------------------------------------------------------
// information about pawn/figure constellation
//-----------------------------------------------------------------------------
typedef struct {
   char white;
   char black;
} bicolor_t;


//-----------------------------------------------------------------------------
// information about from/to field
//-----------------------------------------------------------------------------
typedef struct {
   char from;
   char to;
} fromto_t;


//-----------------------------------------------------------------------------
// data structure for killer moves
//-----------------------------------------------------------------------------
typedef struct {
   fromto_t killer1;
   fromto_t killer2;
} killer_t;

//-----------------------------------------------------------------------------
// internal used move stack size
//-----------------------------------------------------------------------------
#define MAX_STACK (32*64)

//#############################################################################
//###################### NO MORE FAKES BEYOND THIS LINE #######################
//#############################################################################
//
//=============================================================================
// Revision History
//=============================================================================
//
// $Log: board.h,v $
// Revision 1.1  2002/10/23 21:03:15  tnussb
// initial check-in
//
//