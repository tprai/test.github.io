/******************************************************************************
*
* project name:    TI-Chess / BookBuilder
* file name:       bkc.h
* initial date:    04/10/2002
* author:          thomas.nussbaumer@gmx.net
* description:     bookbuilder's header file
*
*
* $Id: bkc.h,v 1.5 2002/10/23 21:06:08 tnussb Exp $
*
******************************************************************************/

#ifndef __BKC_H__
#define __BKC_H__

//-----------------------------------------------------------------------------
// converts 4 character into an unsigned long (nice macro for magic markers)
//-----------------------------------------------------------------------------
#define C4UL(a,b,c,d)   ((((unsigned long)(a)) << 24) | \
                         (((unsigned long)(b)) << 16) | \
                         (((unsigned long)(c)) <<  8) | \
                         (((unsigned long)(d))))

//-----------------------------------------------------------------------------
// magic markers for white and black opening books
//-----------------------------------------------------------------------------
#define MAGIC_BOOK_WHITE     C4UL('B','K','W','0')
#define MAGIC_BOOK_BLACK     C4UL('B','K','B','0')


//#define isWhiteFigure(_x_) ((_x_)>0)
//#define isBlackFigure(_x_) ((_x_)<0)

//#define isCorrectColor(_x_,_c_) (((_c_)==WHITE) ? isWhiteFigure(_x_) : isBlackFigure(_x_))

//#define isFigure(_x_) ((_x_)=='K' || (_x_)=='Q' || (_x_)=='B' || (_x_)=='N' || (_x_)=='R')
//#define isCol(_x_)    ((_x_)=='a' || (_x_)=='b' || (_x_)=='c' || (_x_)=='d' || (_x_)=='e' || (_x_)=='f' || (_x_)=='g' || (_x_)=='h')
//#define isRow(_x_)    ((_x_)=='1' || (_x_)=='2' || (_x_)=='3' || (_x_)=='4' || (_x_)=='5' || (_x_)=='6' || (_x_)=='7' || (_x_)=='8')

//#define isField(_col_,_row_)     (isRow(_row_) && isCol(_col_))
//#define Chars2Field(_row_,_col_) (((_row_)-'a')+((_col_)-'1')*8)


//-----------------------------------------------------------------------------
// internal data structures
//-----------------------------------------------------------------------------
typedef struct _move_t {
   int             from;
   int             to;
   char            promote;
   struct _move_t* next;
} MOVE_T;


typedef struct _position_t {
   unsigned long long hashcode;
   char               board[BOARD_SIZE];
   char               epfield;
   char               side_to_move;
   char               castling_white_long;
   char               castling_white_short;
   char               castling_black_long;
   char               castling_black_short;
   MOVE_T*            moves;
   int                nr_moves;
   struct _position_t* next;
} POSITION_T;


//-----------------------------------------------------------------------------
// a compressed position is a buffer which is 22 bytes long and contains the
// following data:
//
// 164 bits position
//   1 bit  epfield valid flag
//   3 bits epfield  (there are ONLY 8 possible epfields for each side)
//   1 bit  side to move
//   4 bits castle states white/black
//  (3 bits unused)
//-----------------------------------------------------------------------------
#define COMPRESSED_POS_SIZE 22

//-----------------------------------------------------------------------------
// a compressed move is an unsigned short and contains the following data:
//
// 6 bits  from_field
// 6 bits  to_field
// 2 bits  promotion_figure
// 1 bit   is_promotion_move flag
// 1 bit   exists more moves?
// (ALL 16 bits used)
//
// a pawn can be promoted to one of the followings figures:
//
// (Q,R,N,B)
//-----------------------------------------------------------------------------


#define MIRROR_TO_STDERR      1
#define DONT_MIRROR_TO_STDERR 0


#define TT_MAX_MEMBLOCK  65520
#define TT_MAX_OTHDATA   (TT_MAX_MEMBLOCK - 2 - 7)

#define CALC_TI89        0
#define CALC_TI92P       1
#define SIGNATURE_TI89   "**TI89**"
#define SIGNATURE_TI92P  "**TI92P*"
#define DEFAULT_FOLDER   "tict"


#endif


//#############################################################################
//###################### NO MORE FAKES BEYOND THIS LINE #######################
//#############################################################################
//
//=============================================================================
// Revision History
//=============================================================================
//
// $Log: bkc.h,v $
// Revision 1.5  2002/10/23 21:06:08  tnussb
// changes to support PGN input instead of idiotic from-to notation
//
// Revision 1.4  2002/10/18 15:16:45  tnussb
// changes due to -name and -folder commandline parameters
//
// Revision 1.3  2002/10/11 14:13:09  tnussb
// magic markers of opening books changed
//
// Revision 1.2  2002/10/09 15:50:22  tnussb
// too many changes to list separately
//
// Revision 1.1  2002/10/08 17:40:13  tnussb
// initial check-in
//
//
