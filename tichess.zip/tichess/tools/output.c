/******************************************************************************
*
* project name:    TI-Chess / BookBuilder
* file name:       output.c
* initial date:    09/10/2002
* author:          thomas.nussbaumer@gmx.net
* description:     generates output
*
* $Id: output.c,v 1.7 2002/10/24 14:34:48 tnussb Exp $
*
******************************************************************************/

//=============================================================================
// compares the hashcodes of two positions
//=============================================================================
int compare_func(const void *p1, const void *p2) {
    POSITION_T* pos1 = (POSITION_T*)p1;
    POSITION_T* pos2 = (POSITION_T*)p2;

    if (pos1->hashcode < pos2->hashcode) return -1;
    if (pos1->hashcode > pos2->hashcode) return 1;
    return 0;
}


//=============================================================================
// converts linked position lists into linear arrays
//=============================================================================
int GeneratedSortedArray(int white_or_black) {
    int count       = (white_or_black==WHITE) ? nr_positions_white : nr_positions_black;
    POSITION_T* tmp = (white_or_black==WHITE) ? root_white : root_black;
    POSITION_T* tmp2;

    //-------------------------------------------------------------------------
    // first we convert the linked list to a linar array ...
    //-------------------------------------------------------------------------
    if (!count) return 0;

    tmp2 = (white_or_black==WHITE) ? root_white : root_black;

    if (!(tmp = (POSITION_T*)malloc(sizeof(POSITION_T)*count))) {
        EmergencyExit("ERROR: out of memory\n"); // exits program
    }

    if (white_or_black == WHITE) root_white = tmp;
    else                         root_black = tmp;

    while (tmp2) {
        memcpy(tmp,tmp2,sizeof(POSITION_T));
        tmp++;
        tmp2 = tmp2->next;
    }

    //-------------------------------------------------------------------------
    // now lets sort ...
    //-------------------------------------------------------------------------
    qsort((white_or_black==WHITE)?root_white:root_black, count, sizeof(POSITION_T),compare_func);
    return count;
}

char* field_names[BOARD_SIZE] = {
"--","--","--","--","--","--","--","--","--","--",
"--","--","--","--","--","--","--","--","--","--",
"--","a1","b1","c1","d1","e1","f1","g1","h1","--",
"--","a2","b2","c2","d2","e2","f2","g2","h2","--",
"--","a3","b3","c3","d3","e3","f3","g3","h3","--",
"--","a4","b4","c4","d4","e4","f4","g4","h4","--",
"--","a5","b5","c5","d5","e5","f5","g5","h5","--",
"--","a6","b6","c6","d6","e6","f6","g6","h6","--",
"--","a7","b7","c7","d7","e7","f7","g7","h7","--",
"--","a8","b8","c8","d8","e8","f8","g8","h8","--",
"--","--","--","--","--","--","--","--","--","--",
"--","--","--","--","--","--","--","--","--","--"
};


//=============================================================================
// outputs a position to the logfile
//=============================================================================
int OutputPosition(POSITION_T* pos,int mirror_or_not) {
    short   row,col;
    MOVE_T* tmp;
    short   count = 0;
    char    tmpstr[1000];

    //if (logfile) PrintBoard(logfile);
    //if (mirror_or_not) PrintBoard(stderr);

    for (row=7;row>=0;row--) {
        for (col=0;col<8;col++) {
            sprintf(tmpstr,"%c",FIG2SYM(LOWERCASE,pos->board[row*10+col+21]));
            WriteLog(tmpstr,mirror_or_not);
        }
        WriteLog("\n",mirror_or_not);
    }

    WriteLog("\n",mirror_or_not);

    sprintf(tmpstr,"hashcode:       %s\n",Hashcode2String(pos->hashcode));
    WriteLog(tmpstr,mirror_or_not);
    sprintf(tmpstr,"side to move:   %s\n",((pos->side_to_move) ? "BLACK":"WHITE"));
    WriteLog(tmpstr,mirror_or_not);
    sprintf(tmpstr,"epfield:        %s\n",(pos->epfield >= 0) ? field_names[pos->epfield] : "-");
    WriteLog(tmpstr,mirror_or_not);
    sprintf(tmpstr,"castling white: %c%c\n",((pos->castling_white_long) ? 'Q':'-'),((pos->castling_white_short) ? 'K':'-'));
    WriteLog(tmpstr,mirror_or_not);
    sprintf(tmpstr,"castling black: %c%c\n",((pos->castling_black_long) ? 'q':'-'),((pos->castling_black_short) ? 'k':'-'));
    WriteLog(tmpstr,mirror_or_not);
    sprintf(tmpstr,"nr_moves:       %d\n",pos->nr_moves);
    WriteLog(tmpstr,mirror_or_not);
    WriteLog("moves:          ",mirror_or_not);
    tmp = pos->moves;
    while (tmp) {
         sprintf(tmpstr,"%c%c%c%c",
                 ((tmp->from-21)%10)+'a',((tmp->from-21)/10)+'1',
                 ((tmp->to-21)%10)+'a',((tmp->to-21)/10)+'1');
         WriteLog(tmpstr,mirror_or_not);
         if (tmp->promote) {
             sprintf(tmpstr,"(%c)",tmp->promote);
             WriteLog(tmpstr,mirror_or_not);
         }
         WriteLog(" ",mirror_or_not);
         tmp = tmp->next;
         count++;
    }
    WriteLog("\n\n",mirror_or_not);
    return count;
}


//=============================================================================
// evaluate index of last fitting position for a single book
//=============================================================================
unsigned int EvaluateFittingEndIndex(POSITION_T*   root,
                                     unsigned int  nr_positions,
                                     unsigned int  index,
                                     unsigned int* nr_moves,
                                     unsigned int* booksize)
{
    unsigned int position_size;

    *booksize = 4+2+2; // magic(4)+poscount(2)+movecount(2)
    *nr_moves = 0;

    do {
        position_size  = root[index].nr_moves*2; // size of moves
        position_size += COMPRESSED_POS_SIZE;    // size of compressed position
        position_size += 8+2;                    // hashcode & offset

        if (*booksize+position_size>param_booksize-9) {
            // will not fit anymore ...
            return index-1;
        }

        *booksize += position_size;
        *nr_moves += root[index].nr_moves;
        index++;
        if (index==nr_positions) {
            return index-1;
        }
    }
    while(1);

    return nr_positions-1; // never comes here ...
}


//=============================================================================
// generate all book files for a given side
//=============================================================================
void OutputAllPositions(int white_or_black) {
    int            i;
    unsigned char  compressed_board[COMPRESSED_POS_SIZE];
    short          compressed;
    POSITION_T*    root;
    unsigned int   nr_positions;
    unsigned int   act_index;
    unsigned int   end_index;
    unsigned int   nr_moves;
    unsigned int   size_of_book;
    char           varname[100];
    char           tmpstr[255];
    unsigned char* buffer;
    unsigned char* orig;
    unsigned int   count;
    unsigned int   offset;
    POSITION_T*    tmp;


    // convert linked list into linear array for simple stepping
    GeneratedSortedArray(white_or_black);

    if (white_or_black == WHITE) {
        root         = root_white;
        nr_positions = nr_positions_white;
        nr_moves     = nr_moves_white;
    }
    else {
        root         = root_black;
        nr_positions = nr_positions_black;
        nr_moves     = nr_moves_black;
    }

    if (nr_positions == 0) {
        if (param_noti89 && param_noti92p) return;
        sprintf(tmpstr,"WARNING: no positions for %s\n",((white_or_black==WHITE)?"white":"black"));
        WriteLog(tmpstr,MIRROR_TO_STDERR);
        return;
    }

    sprintf(tmpstr,"\ntotal number of %s positions = %u\n",white_or_black==WHITE?"WHITE":"BLACK",nr_positions);
    WriteLog(tmpstr,MIRROR_TO_STDERR);
    sprintf(tmpstr,"total number of %s moves     = %u\n\n",white_or_black==WHITE?"WHITE":"BLACK",nr_moves);
    WriteLog(tmpstr,MIRROR_TO_STDERR);

    act_index = 0;
    do {
        if (white_or_black == WHITE) {
            // check postfix of file to generate ...
            if (param_offset>9) {
                sprintf(tmpstr,"ERROR: Sorry, can only generate files %s0 up to %s9\n",param_prefix,param_prefix);
                WriteLog(tmpstr,MIRROR_TO_STDERR);
                return;
            }
            sprintf(varname,"%s%d",param_prefix,param_offset);
        }
        else {
            if (param_offset>9) {
                sprintf(tmpstr,"ERROR: Sorry, can only generate files %s0 up to %s9\n",param_prefix,param_prefix);
                WriteLog(tmpstr,MIRROR_TO_STDERR);
                return;
            }
            sprintf(varname,"%s%d",param_prefix,param_offset);
        }


        end_index = EvaluateFittingEndIndex(root,nr_positions,act_index,&nr_moves,&size_of_book);
        count = end_index-act_index+1;

        sprintf(tmpstr,"\n======== %s book (%s) ========\n\n",((white_or_black==WHITE)?"white":"black"),varname);
        WriteLog(tmpstr,DONT_MIRROR_TO_STDERR);
        sprintf(tmpstr,"number of positions   = %d\n",count);
        WriteLog(tmpstr,DONT_MIRROR_TO_STDERR);
        sprintf(tmpstr,"number of moves       = %d\n",nr_moves);
        WriteLog(tmpstr,DONT_MIRROR_TO_STDERR);
        sprintf(tmpstr,"expected booksize     = %d\n\n",size_of_book);
        WriteLog(tmpstr,DONT_MIRROR_TO_STDERR);

        // allocate memory for output buffer
        if (!(buffer = malloc(size_of_book))) {
            EmergencyExit("ERROR: out of memory\n"); // exits program
        }
        orig = buffer;

        // write magic marker
        if (white_or_black == WHITE) {
            *buffer++ = (MAGIC_BOOK_WHITE >> 24) & 0xff;
            *buffer++ = (MAGIC_BOOK_WHITE >> 16) & 0xff;
            *buffer++ = (MAGIC_BOOK_WHITE >>  8) & 0xff;
            *buffer++ = (MAGIC_BOOK_WHITE)       & 0xff;
        }
        else {
            *buffer++ = (MAGIC_BOOK_BLACK >> 24) & 0xff;
            *buffer++ = (MAGIC_BOOK_BLACK >> 16) & 0xff;
            *buffer++ = (MAGIC_BOOK_BLACK >>  8) & 0xff;
            *buffer++ = (MAGIC_BOOK_BLACK)       & 0xff;
        }

        // write position count
        *buffer++ = (count >> 8) & 0xff;
        *buffer++ = (count)      & 0xff;

        // write move count
        if (nr_moves > 65535) nr_moves = 65535; // clip down!!
        *buffer++ = (nr_moves >> 8) & 0xff;
        *buffer++ = (nr_moves)      & 0xff;


        // write index table (hashcodes and indices)
        tmp = root + act_index;
        offset = count*10+8;   // magic(4) + poscount(2) + movecount(2) + size of index table(count*10)

        for (i=0;i<count;i++,tmp++) {
            unsigned long th = (unsigned long)(tmp->hashcode >> 32);
            unsigned long tl = (unsigned long)(tmp->hashcode & 0xffffffffUL);

            *buffer++ = (th >> 24) & 0xff;
            *buffer++ = (th >> 16) & 0xff;
            *buffer++ = (th >>  8) & 0xff;
            *buffer++ = (th)       & 0xff;
            *buffer++ = (tl >> 24) & 0xff;
            *buffer++ = (tl >> 16) & 0xff;
            *buffer++ = (tl >>  8) & 0xff;
            *buffer++ = (tl)       & 0xff;

            *buffer++ = (offset>>8) & 0xff;
            *buffer++ = (offset)    & 0xff;

            offset += WriteCompressedPosition(orig+offset,tmp);

            sprintf(tmpstr,"=========== pos %04d/%04d =============\n",i+1,count);
            WriteLog(tmpstr,DONT_MIRROR_TO_STDERR);
            OutputPosition(tmp,DONT_MIRROR_TO_STDERR);
            compressed = CompressAndTry(tmp,compressed_board);
            sprintf(tmpstr,"compressed size = %d bits\n\n",compressed);
            WriteLog(tmpstr,DONT_MIRROR_TO_STDERR);
            if (compressed < 0) {
                EmergencyExit("FATAL: compression failed (internal problem)\n"); // exits program
            }
        }

        // write positions
        tmp = root + act_index;

        for (i=0;i<count;i++,tmp++) {
            if (!FetchAndCompare(orig,i,tmp)) {
                EmergencyExit("FATAL: output is damaged (internal problem)\n");  // exits program
            }
        }

        if (!GenerateOutputFiles(varname,orig,size_of_book,white_or_black)) {
            free(orig);
            EmergencyExit("FATAL: outputfiles generation failed!");
        }

        free(orig);

        act_index = end_index+1;
    }
    while (act_index != nr_positions);
}


//#############################################################################
//###################### NO MORE FAKES BEYOND THIS LINE #######################
//#############################################################################
//
//=============================================================================
// Revision History
//=============================================================================
//
// $Log: output.c,v $
// Revision 1.7  2002/10/24 14:34:48  tnussb
// output statistics also to stderr
//
// Revision 1.6  2002/10/24 11:45:27  tnussb
// don't spill out a warning about no positions parsed if we are using
// parameter -noparse.
//
// Revision 1.5  2002/10/23 21:40:42  tnussb
// fileindex counting fixed
//
// Revision 1.4  2002/10/23 21:06:08  tnussb
// changes to support PGN input instead of idiotic from-to notation
//
// Revision 1.3  2002/10/18 15:16:45  tnussb
// changes due to -name and -folder commandline parameters
//
// Revision 1.2  2002/10/11 14:14:11  tnussb
// number of continuation moves in a book gets now stored at the beginning
// of the bookfile.
//
// Revision 1.1  2002/10/09 15:49:23  tnussb
// initial version
//
//
