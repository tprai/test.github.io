/******************************************************************************
*
* project name:    TI-Chess / BookBuilder
* file name:       bkc.c
* initial date:    04/10/2002
* author:          thomas.nussbaumer@gmx.net
* description:     Bookbuilder main file
*
* $Id: bkc.c,v 1.18 2002/10/24 14:36:12 tnussb Exp $
*
******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>


//-----------------------------------------------------------------------------
// just used internally
//-----------------------------------------------------------------------------
#define CVS_TRUNC_PREFIX    ((strlen((CVS_FILE_REVISION))<=11) ? 0 : (CVS_FILE_REVISION+11))
#define CVS_FIND_COMMA      (strchr(CVS_TRUNC_PREFIX,'.'))
#define CVSREV_MAIN         (int)(!(CVS_TRUNC_PREFIX) ? 0 : atoi(CVS_TRUNC_PREFIX))
#define CVSREV_SUB          (int)(!(CVS_TRUNC_PREFIX) ? 0 : (!(CVS_FIND_COMMA) ? 0 : atoi(CVS_FIND_COMMA+1)))

//-----------------------------------------------------------------------------
// NOTE: THE FOLLOWING MACRO WILL ONLY HANDLE MAIN VERSION < 10 AT CONSTANT
//       LENGTH !!!
//       (subversions from 1 .. 99 are mapped to 01 .. 99)
//
// the following macro may be used to setup a printf(),sprintf() or fprintf()
// call
//-----------------------------------------------------------------------------
#define CVSREV_PRINTPARAMS  "v%d.%02d",CVSREV_MAIN,CVSREV_SUB


#define PRINT_ID(x,name)  {fprintf(x,"\n");fprintf(x, name" ");\
                           fprintf(x,CVSREV_PRINTPARAMS);\
                           fprintf(x," (TI-Chess/Supplemental Tools)\n(c) thomas.nussbaumer@gmx.net "__DATE__" "__TIME__"\n\n");}


#ifdef CVS_FILE_REVISION
#undef CVS_FILE_REVISION
#endif
//-----------------------------------------------------------------------------
// DON'T EDIT THE NEXT DEFINE BY HAND! THIS IS DONE AUTOMATICALLY BY THE
// CVS SYSTEM !!!
//-----------------------------------------------------------------------------
#define CVS_FILE_REVISION "$Revision: 1.18 $"

#include "board.h"
#include "bkc.h"

#define DEFAULT_PREFIX "ticbook"

#define LANG_ENGLISH 0
#define LANG_GERMAN  1

int          param_inputlang = LANG_ENGLISH;
int          param_maxply    = 0;
int          param_offset    = 0;
int          param_nowhite   = 0;
int          param_noblack   = 0;
int          param_noti89    = 0;
int          param_noti92p   = 0;
int          param_writelog  = 0;
int          param_dontstop  = 0;
char*        param_folder    = DEFAULT_FOLDER;
char*        param_prefix    = DEFAULT_PREFIX;
unsigned int param_booksize  = TT_MAX_OTHDATA;
FILE*        logfile         = 0;

POSITION_T*  root_white         = 0;
unsigned int nr_positions_white = 0;
unsigned int nr_moves_white     = 0;
POSITION_T*  root_black         = 0;
unsigned int nr_positions_black = 0;
unsigned int nr_moves_black     = 0;


//=============================================================================
// writes log to logfile and stderr if wanted
//=============================================================================
void WriteLog(char* s,int mirror_to_stderr) {
    if (param_writelog)   fprintf(logfile,"%s",s);
    if (mirror_to_stderr) fprintf(stderr,"%s",s);
}


//=============================================================================
// writes log to logfile AND stderr and exits
//=============================================================================
void EmergencyExit(char* s) {
    WriteLog(s,MIRROR_TO_STDERR);
    if (logfile) fclose(logfile);
    exit(0);
}



#include "hash.c"
#include "board.c"
#define BOOK_COMPILER
#include "bin2oth.c"
#include "compress.c"
#include "output.c"



//=============================================================================
// outputs usage text
//=============================================================================
void OutputUsage() {
    PRINT_ID(stderr,"Opening Book Compiler");
    fprintf(stderr,"usage: bkc [flags] inputfile\n\n" \
                   "-offset digit  ... postfix of first generated book (0..9)\n"\
                   "-nowhite       ... don't generate WHITE opening books\n"\
                   "-noblack       ... don't generate BLACK opening books\n"\
                   "-noti89        ... don't generate files for TI89\n"\
                   "-noti92p       ... don't generate files for TI92p\n"\
                   "-parse         ... don't generate any outputfile\n"\
                   "-log           ... generates logfile bkclog.txt\n"\
                   "-nostop        ... dont stop after first error\n"\
                   "-ger           ... use german figure symbols for input\n"\
                   "-eng           ... use english figure symbols for input\n"\
                   "-size number   ... maximum oncalc size of books (<= %d)\n"\
                   "-ply number    ... maximum number of plies per sequence\n"\
                   "-folder name   ... oncalc folder name (default: %s)\n"\
                   "-prefix name   ... oncalc file name prefix (default: %s)\n\n"\
                   "Converts a textfile into TI-Chess opening books.\n\n"\
                   "By default the TI89 outputfiles are named %s0.89y up to\n"\
                   "%s9.89y and the TI92p/V200 files are named %s0.9xy up to\n"\
                   "%s9.9xy and will be stored in the oncalc folder %s. Note that\n"\
                   "if you specify an own filename with option -prefix the program will\n"\
                   "automatically append a number to it.\n"\
                   "If the inputfile contains white positions first one or more white\n"\
                   "books are generated, then the black books are generated. White and\n"\
                   "black positons are not mixed within a single bookfile\n",
                   TT_MAX_OTHDATA,DEFAULT_FOLDER,DEFAULT_PREFIX,
                   DEFAULT_PREFIX,DEFAULT_PREFIX,DEFAULT_PREFIX,DEFAULT_PREFIX,DEFAULT_FOLDER);
}






//=============================================================================
// buffered file access (streamed) ...
//=============================================================================
#define _INBUFFER_LENGTH  65535
static unsigned char _inputbuffer[_INBUFFER_LENGTH];

int _bytes_available   = 0;
int _act_pointer       = 0;
int _input_line_number = 1;
int _unget_character   = -100;


int statistics_nrgames = 0;
int statistics_nrfens  = 0;


//=============================================================================
// buffered file access (streamed) ...
//=============================================================================
int GetCharacter(FILE* fp) {
    if (_unget_character != -100) {
        int ret = _unget_character;
        _unget_character = -100;
        return ret;
    }

    // refill cache
    if (_act_pointer>=_bytes_available) {
        if (!(_bytes_available = fread(_inputbuffer,1,_INBUFFER_LENGTH-1,fp))) {
            _act_pointer = 0;
            return EOF;
        }
        _act_pointer = 0;
    }

    return _inputbuffer[_act_pointer++];
}


//=============================================================================
// ungets previously read character
//
// (maybe called at least twice)
//=============================================================================
void UngetCharacter(char c) {
    if (!_act_pointer) {
        if (_unget_character != -100) {
            EmergencyExit("FATAL: cannot process UngetCharacter()\n");  // exits!
        }
        else {
            _unget_character = c;
        }
    }
    else {
        _act_pointer--;
    }
}


//=============================================================================
// get a line
//=============================================================================
void SkipCharsUntil(char endtoken,char* backbuffer,int length,FILE* fp,int* fen_line_nr) {
    int input;
    int count = 0;
    char tmpbuffer[200];

    if (fen_line_nr) *fen_line_nr = _input_line_number;

    do {
        input = GetCharacter(fp);
        if (input == '\n') _input_line_number++;
        else if (backbuffer) {
            backbuffer[count++] = input;
            if (count == length) {
                sprintf(tmpbuffer,"FATAL: too long tag ([..]) near line %d\n",_input_line_number);
                EmergencyExit(tmpbuffer);
            }
        }
    }
    while (input != endtoken && input != EOF);

    if (backbuffer) backbuffer[count] = 0;
}


char internal_fenbuffer[10000];
//=============================================================================
// get a line
//=============================================================================
int GetGameLine(char* buffer, int bufferlen, int* line_nr,char* fenbuffer,
                int fenlength,int* fen_line_nr, FILE* fp)
{
    int  count       = 0;
    int  whitespace  = 0;
    int  is_new_line = 0;
    int  input;
    char tmpbuffer[200];

    memset(fenbuffer,0,fenlength);

    while ((input = GetCharacter(fp)) != EOF) {
        switch(input) {
            case EOF:  return ((count) ? count : EOF);
            case '\n': buffer[count] = 0;
                       _input_line_number++;
                       if (count) is_new_line = 1,whitespace++;
                       break;
            case '\t': // fall through
            case ' ':  if (count) whitespace++; break;
            case '/':  if (GetCharacter(fp) == '/') {
                           SkipCharsUntil('\n',0,0,fp,0);
                           if (count) is_new_line = 1,whitespace++;
                           break;
                       }
                       UngetCharacter('/');
                       if (whitespace) {
                           buffer[count++] = ' ';
                           whitespace = 0;
                           if (count == bufferlen) {
                               sprintf(tmpbuffer,"FATAL: game lines limited to %d\n",bufferlen);
                               EmergencyExit(tmpbuffer);
                           }
                       }
                       buffer[count++] = '/';
                       if (count == bufferlen) {
                           sprintf(tmpbuffer,"FATAL: game lines limited to %d\n",bufferlen);
                           EmergencyExit(tmpbuffer);
                       }
                       break;
            case ';':  SkipCharsUntil('\n',0,0,fp,0);   // PGN end of line comment
                       break;
            case '{':  SkipCharsUntil('}',0,0,fp,0);
                       break;
            case '[':  if (count) {    // a comment will indicate a new game!
                           UngetCharacter('[');
                           buffer[count] = 0;
                           return count;
                       }
                       SkipCharsUntil(']',internal_fenbuffer,10000,fp,fen_line_nr);
                       if (!strncmp(internal_fenbuffer,"FEN \"",5)) {
                           char* c = &internal_fenbuffer[5];
                           int tmpcount = 0;
                           while(*c != '"' && *c != 0) {
                               fenbuffer[tmpcount++] = *c;
                               if (tmpcount == fenlength) {
                                   sprintf(tmpbuffer,"FATAL: fenbuffer overflow in line %d (%s)\n",*fen_line_nr,internal_fenbuffer);
                                   EmergencyExit(tmpbuffer);
                               }
                               c++;
                           }
                           fenbuffer[tmpcount] = 0;
                       }
                       break;
            case 0x0d: break;
            default:   if (!count) {
                           *line_nr = _input_line_number;
                       }
                       else {
                           if (is_new_line) {
                               if (input == '1') {
                                   int tmp2 = GetCharacter(fp);
                                   if (tmp2 == '.') {
                                       UngetCharacter('.');
                                       UngetCharacter('1');
                                       buffer[count] = 0;
                                       return (count) ? count : EOF;
                                   }
                                   UngetCharacter(tmp2);
                               }
                               is_new_line = 0;
                           }
                       }
                       if (whitespace) {
                           buffer[count++] = ' ';
                           whitespace = 0;
                           if (count == bufferlen) {
                               sprintf(tmpbuffer,"FATAL: game lines limited to %d\n",bufferlen);
                               EmergencyExit(tmpbuffer);
                           }
                       }
                       buffer[count++] = input;
                       if (count == bufferlen) {
                           sprintf(tmpbuffer,"FATAL: game lines limited to %d\n",bufferlen);
                           EmergencyExit(tmpbuffer);
                       }
                       break;
        }
    }

    return (count) ? count : EOF;
}


//=============================================================================
// parses complete file
//=============================================================================
void HandleGame(char* fenpos, int fen_nr, char* moves, int moves_nr) {
    char tmpbuffer[250];
    if (fenpos) {
        if (!InitBoardWithFEN(fenpos,fen_nr)) {
            WriteLog("skipping sequence due to invalid FEN\n",MIRROR_TO_STDERR);
            return;
        }
        sprintf(tmpbuffer,"[line %05d] using FEN: %s\n",fen_nr,fenpos);
        WriteLog(tmpbuffer,DONT_MIRROR_TO_STDERR);
        statistics_nrfens++;
    }
    else {
        InitBoard();
    }

    printf("processing sequence %d starting at line %d ...\x0d",statistics_nrgames+1,moves_nr);

    sprintf(tmpbuffer,"[line %05d] moves: ",moves_nr);
    WriteLog(tmpbuffer,DONT_MIRROR_TO_STDERR);
    WriteLog(moves,DONT_MIRROR_TO_STDERR);
    WriteLog("\n",DONT_MIRROR_TO_STDERR);
    PlayMoves(moves,moves_nr);
    statistics_nrgames++;
}


//=============================================================================
// parses complete file
//=============================================================================
char linebuffer[10000];
char fenbuffer[10000];

void ParseFile(FILE* fp) {
    int nr_chars;
    int line_nr;
    int fen_line_nr;
    while ((nr_chars = GetGameLine(linebuffer,9999,&line_nr,fenbuffer,9999,&fen_line_nr,fp))!=EOF) {
        //---------------------------------------------------------------------
        // here we go ...
        // linebuffer contains the complete move sequence and
        // fenbuffer contains the latest FEN parsed
        //---------------------------------------------------------------------
        HandleGame(((fenbuffer[0])?fenbuffer:0),fen_line_nr,linebuffer,line_nr);
    }
}


//=============================================================================
// simple main which opens just the inputfile and hands it over to the parser
//=============================================================================
int main(int argc, char* argv[]) {
    char* inputfile = 0;
    int   n;
    FILE* fp;

    //textmode(-1);

    if (argc < 2) {
        OutputUsage();
        return 1;
    }

    // parse arguments
    for (n=1; n<argc; n++) {
        if (!strcmp(argv[n], "-noti89"))       param_noti89    = 1;
        else if (!strcmp(argv[n], "-noti92p")) param_noti92p   = 1;
        else if (!strcmp(argv[n], "-parse"))   param_noti89    = param_noti92p  = 1;
        else if (!strcmp(argv[n], "-ger"))     param_inputlang = LANG_GERMAN;
        else if (!strcmp(argv[n], "-eng"))     param_inputlang = LANG_ENGLISH;
        else if (!strcmp(argv[n], "-nowhite")) param_nowhite   = 1;
        else if (!strcmp(argv[n], "-noblack")) param_noblack   = 1;
        else if (!strcmp(argv[n], "-log"))     param_writelog  = 1;
        else if (!strcmp(argv[n], "-nostop"))  param_dontstop  = 1;
        else if (!strcmp(argv[n], "-folder")) {
            if (n == argc -1) {
                fprintf(stderr,"ERROR: missing parameter for option '-folder'\n");
                return 1;
            }

            if (strlen(argv[n+1])>8) {
                fprintf(stderr,"ERROR: folder name too long (max. 8 characters)\n");
                return 1;
            }

            param_folder = argv[n+1];
            n++;
        }
        else if (!strcmp(argv[n], "-prefix")) {
            if (n == argc -1) {
                fprintf(stderr,"ERROR: missing parameter for option '-prefix'\n");
                return 1;
            }

            if (strlen(argv[n+1])>7) {
                fprintf(stderr,"ERROR: prefix too long (max. 7 characters)\n");
                return 1;
            }

            param_prefix = argv[n+1];
            n++;
        }
        else if (!strcmp(argv[n], "-offset")) {
            if (n == argc -1) {
                fprintf(stderr,"ERROR: missing digit for option '-offset'\n");
                return 1;
            }

            if (sscanf(argv[n+1],"%d",&param_offset) != 1) {
                fprintf(stderr,"ERROR: invalid parameter for option '-offset'\n");
                return 1;
            }

            if (param_offset < 0 || param_offset > 9) {
                fprintf(stderr,"ERROR: only digits (0..9) are valid for option '-offset'\n");
                return 1;
            }

            n++;
        }
        else if (!strcmp(argv[n], "-ply")) {
            if (n == argc -1) {
                fprintf(stderr,"ERROR: missing number for option '-ply'\n");
                return 1;
            }

            if (sscanf(argv[n+1],"%d",&param_maxply) != 1) {
                fprintf(stderr,"ERROR: invalid parameter for option '-ply'\n");
                return 1;
            }

            if (param_maxply <= 0) {
                fprintf(stderr,"ERROR: only number > 0 are valid for option '-ply'\n");
                return 1;
            }

            n++;
        }
        else if (!strcmp(argv[n], "-size")) {
            if (n == argc -1) {
                fprintf(stderr,"ERROR: missing number for option '-size'\n");
                return 1;
            }

            if (sscanf(argv[n+1],"%u",&param_booksize) != 1) {
                fprintf(stderr,"ERROR: invalid parameter for option '-size'\n");
                return 1;
            }

            if (param_booksize > TT_MAX_OTHDATA) {
                fprintf(stderr,"ERROR: cannot generate books larger than %d\n",TT_MAX_OTHDATA);
                return 1;
            }

            n++;
        }
        else if (argv[n][0] == '-') {
            fprintf(stderr,"ERROR: invalid option %s\n",argv[n]);
            return 1;
        }
        else if (!inputfile) inputfile = argv[n];
        else {
            OutputUsage(argv[0]);
            return 1;
        }
    }

    if (!inputfile) {
        fprintf(stderr,"ERROR: no inputfile specified\n");
        return 1;
    }

    if (param_nowhite && param_noblack) {
        fprintf(stderr,"nothing to do (-nowhite and -noblack specified)\n");
        return 0;
    }

    if (param_noti89 && param_noti92p) {
        fprintf(stderr,"generating no files (only parsing)\n");
    }

    if (param_writelog) {
        if (!(logfile = fopen("bkclog.txt","w"))) {
            fprintf(stderr,"ERROR: cannot open logfile bkclog.txt\n");
            return 1;
        }
        PRINT_ID(logfile,"Opening Book Compiler");
    }

    PRINT_ID(stderr,"Opening Book Compiler");


    if (!(fp = fopen(inputfile,"r"))) {
        fprintf(stderr,"ERROR: cannot open inputfile %s\n",inputfile);
        return 1;
    }

    ParseFile(fp);
    fclose(fp);

    printf("\x0d                                                                            \n");
    printf("FENs parsed      = %d\n",statistics_nrfens);
    printf("sequences parsed = %d\n",statistics_nrgames);

    if (!param_nowhite) {
        WriteLog("=======================================\n",DONT_MIRROR_TO_STDERR);
        WriteLog("=========== WHITE POSITIONS ===========\n",DONT_MIRROR_TO_STDERR);
        WriteLog("=======================================\n",DONT_MIRROR_TO_STDERR);
        OutputAllPositions(WHITE);
    }

    if (!param_noblack) {
        WriteLog("=======================================\n",DONT_MIRROR_TO_STDERR);
        WriteLog("=========== BLACK POSITIONS ===========\n",DONT_MIRROR_TO_STDERR);
        WriteLog("=======================================\n",DONT_MIRROR_TO_STDERR);
        OutputAllPositions(BLACK);
    }

    if (logfile) fclose(logfile);

    fprintf(stderr,"\n");

    return 0;
}

//#############################################################################
//###################### NO MORE FAKES BEYOND THIS LINE #######################
//#############################################################################
//
//=============================================================================
// Revision History
//=============================================================================
//
// $Log: bkc.c,v $
// Revision 1.18  2002/10/24 14:36:12  tnussb
// (1) many commandline parameters shortened
// (2) commandline parameter -ply added (maximum number of plies per sequence)
//
// Revision 1.17  2002/10/24 11:42:27  tnussb
// outputs now progress counter during parsing
//
// Revision 1.16  2002/10/24 09:53:49  tnussb
// (1) can parse now fully qualified PGN moves like Qe2-f3, too
// (2) parameter -onlyparse added
// (3) parameter -english and -german added which can be used to switch to
//     the input move notation to german (different figure symbols)
//
// Revision 1.15  2002/10/23 21:43:01  tnussb
// (1) modifications for param -dontstop
// (2) file index counting fixed
//
// Revision 1.14  2002/10/23 21:06:08  tnussb
// changes to support PGN input instead of idiotic from-to notation
//
// Revision 1.13  2002/10/18 15:16:45  tnussb
// changes due to -name and -folder commandline parameters
//
// Revision 1.12  2002/10/16 17:00:54  tnussb
// typo in usage text fixed
//
// Revision 1.11  2002/10/14 12:05:42  tnussb
// help text slightly modified
//
// Revision 1.10  2002/10/14 12:03:54  tnussb
// option -dontstop (don't stop after errors) added
//
// Revision 1.9  2002/10/14 07:50:59  tnussb
// just commited to raise version number
//
// Revision 1.8  2002/10/11 15:25:59  tnussb
// bug in promotion handling fixed
//
// Revision 1.7  2002/10/11 14:15:14  tnussb
// just a dummy changement to raise version number of complete program
//
// Revision 1.6  2002/10/11 10:29:35  tnussb
// treatment of special tokens [WO] and [BO] are added. If a move sequence
// starts with one of these tokens only the BLACK or WHITE positions and
// continuation moves are added to the opening book.
//
// Revision 1.5  2002/10/10 13:06:59  tnussb
// minor modifications, because part of the bkc sources are shared with cpc yet
//
// Revision 1.4  2002/10/09 18:26:24  tnussb
// changes related to FEN position description parsing
//
// Revision 1.3  2002/10/09 15:50:21  tnussb
// too many changes to list separately
//
// Revision 1.2  2002/10/08 17:42:36  tnussb
// complete rewrite for new opening book format (see history.txt v3.90/91)
//
//
