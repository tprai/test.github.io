/******************************************************************************
*
* project name:    TI-Chess / Chess Puzzle Compiler
* file name:       fen.c
* initial date:    04/10/2002
* author:          thomas.nussbaumer@gmx.net
* description:     FEN position parsing
*
* $Id: fen.c,v 1.2 2002/10/23 21:07:18 tnussb Exp $
*
******************************************************************************/


//=============================================================================
// sets the board content taking the inverse FEN notation into account
//=============================================================================
int SetBoardField(int current_field,char figure,char* board,int repeat) {
    int actfield;

    for (actfield=current_field;actfield<current_field+repeat;actfield++) {
        int col = actfield % 8;
        int row = 7-actfield/8; // INVERTED!! That's FEN ;-)

        if (row*8+col >= 64) return 0;
        *(board+row*8+col) = figure;
    }
    return 1;
}


//=============================================================================
// parses figure positions (field 1 of FEN description)
// returns 1 if position is okay
//=============================================================================
int ParseFigurePositions(char* position,char* board) {
    int current_field = 0;

    do {
         switch(*position) {
             case 'p': if (!SetBoardField(current_field,BLACK_PAWN,board,1)) return 0;current_field++;break;
             case 'r': if (!SetBoardField(current_field,BLACK_ROOK,board,1)) return 0;current_field++;break;
             case 'n': if (!SetBoardField(current_field,BLACK_KNIGHT,board,1)) return 0;current_field++;break;
             case 'b': if (!SetBoardField(current_field,BLACK_BISHOP,board,1)) return 0;current_field++;break;
             case 'q': if (!SetBoardField(current_field,BLACK_QUEEN,board,1)) return 0;current_field++;break;
             case 'k': if (!SetBoardField(current_field,BLACK_KING,board,1)) return 0;current_field++;break;
             case 'P': if (!SetBoardField(current_field,WHITE_PAWN,board,1)) return 0;current_field++;break;
             case 'R': if (!SetBoardField(current_field,WHITE_ROOK,board,1)) return 0;current_field++;break;
             case 'N': if (!SetBoardField(current_field,WHITE_KNIGHT,board,1)) return 0;current_field++;break;
             case 'B': if (!SetBoardField(current_field,WHITE_BISHOP,board,1)) return 0;current_field++;break;
             case 'Q': if (!SetBoardField(current_field,WHITE_QUEEN,board,1)) return 0;current_field++;break;
             case 'K': if (!SetBoardField(current_field,WHITE_KING,board,1)) return 0;current_field++;break;
             case '1': if (!SetBoardField(current_field,EMPTY_FIELD,board,1)) return 0;current_field++;break;
             case '2': if (!SetBoardField(current_field,EMPTY_FIELD,board,2)) return 0;current_field+=2;break;
             case '3': if (!SetBoardField(current_field,EMPTY_FIELD,board,3)) return 0;current_field+=3;break;
             case '4': if (!SetBoardField(current_field,EMPTY_FIELD,board,4)) return 0;current_field+=4;break;
             case '5': if (!SetBoardField(current_field,EMPTY_FIELD,board,5)) return 0;current_field+=5;break;
             case '6': if (!SetBoardField(current_field,EMPTY_FIELD,board,6)) return 0;current_field+=6;break;
             case '7': if (!SetBoardField(current_field,EMPTY_FIELD,board,7)) return 0;current_field+=7;break;
             case '8': if (!SetBoardField(current_field,EMPTY_FIELD,board,8)) return 0;current_field+=8;break;
             case '/': break;
             default:  return 0;  // invalid character in input
         }
         position++;
    }
    while (current_field < 64);
    return 1;
}


//=============================================================================
// parses castling states (field 3 of FEN description)
// returns 1 castling states are okay
//=============================================================================
int ParseCastlingStates(char* input,char* white_long,char* white_short,
                         char* black_long, char* black_short)
{
    *white_long  = 0;
    *white_short = 0;
    *black_long  = 0;
    *black_short = 0;

    if (*input == 0)   return 0;  // not even a '-' .... invalid!
    if (*input == '-') return 1;

    do {
        switch(*input) {
            case 'K': *white_short = 1; break;
            case 'Q': *white_long  = 1; break;
            case 'k': *black_short = 1; break;
            case 'q': *black_long  = 1; break;
            case 0:   return 1;
            default:  return 0;  // some unknown character found!
        }
        input++;
    }
    while (1);

    return 0; // just for the compiler ... we'll never come here ...
}


//=============================================================================
// tests FEN parsing
//=============================================================================
int ParseFEN(char* s,char* board,char* side,char* white_long,char* white_short,
             char* black_long,char* black_short,char* ep,int* halfmove, int* fullmove)
{
    char *token;
    int  count = 0;

    strtrim(s); // trim input

    token = strtok(s," ");

    do {
        if (!token && count < 6) return 0;

        //printf("parsing field %d (%s)\n",count+1,token);

        switch(count) {
            case 0: if (!ParseFigurePositions(token,board)) return 0; break;
            case 1: if (token[0] == 'w')      {*side = WHITE; break;}
                    else if (token[0] == 'b') {*side = BLACK; break;}
                    else return 0;
            case 2: if (!ParseCastlingStates(token,white_long,white_short,black_long,black_short)) return 0;break;
            case 3: if (token[0] == '-') {*ep = -1; break;}
                    if (token[0] == 0) return 0;
                    token[0]=tolower(token[0]);
                    if (token[0] < 'a' || token[0] > 'h') return 0;
                    if (token[1] == 0) return 0;
                    token[1]=tolower(token[1]);
                    if (token[1] < '1' || token[1] > '8') return 0;
                    *ep = token[0]-'a' + (token[1]-'1')*8;
                    break;
            case 4: if (sscanf(token,"%d",halfmove)!=1) return 0; break;
            case 5: if (sscanf(token,"%d",fullmove)!=1) return 0; break;
        }
        count++;
        if (count == 6) return 1;
        token = strtok(0," ");
    }
    while(1);
    return 0; // we'll never come here ...
}


//=============================================================================
// tests FEN parsing
//=============================================================================
/*
void TestFENParsing() {
    char board[64];
    char side;
    char white_long;
    char white_short;
    char black_long;
    char black_short;
    char ep;
    int  halfmove;
    int  fullmove;

    if (!ParseFEN("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1",board,&side,&white_long,&white_short,&black_long,&black_short,&ep,&halfmove,&fullmove)) {
        printf("ERROR pos1\n");
    }
    else {
        printf("pos1 ok\n");
    }
    if (!ParseFEN("rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq e3 0 1",board,&side,&white_long,&white_short,&black_long,&black_short,&ep,&halfmove,&fullmove)) {
        printf("ERROR pos2\n");
    }
    else {
        printf("pos2 ok\n");
    }
    if (!ParseFEN("rnbqkbnr/pp1ppppp/8/2p5/4P3/8/PPPP1PPP/RNBQKBNR w KQkq c6 0 2",board,&side,&white_long,&white_short,&black_long,&black_short,&ep,&halfmove,&fullmove)) {
        printf("ERROR pos3\n");
    }
    else {
        printf("pos3 ok\n");
    }
    if (!ParseFEN("rnbqkbnr/pp1ppppp/8/2p5/4P3/5N2/PPPP1PPP/RNBQKB1R b KQkq - 1 2",board,&side,&white_long,&white_short,&black_long,&black_short,&ep,&halfmove,&fullmove)) {
        printf("ERROR pos4\n");
    }
    else {
        printf("pos4 ok\n");
    }
    if (!ParseFEN("4k3/8/8/8/8/8/4P3/4K3 w - - 5 39",board,&side,&white_long,&white_short,&black_long,&black_short,&ep,&halfmove,&fullmove)) {
        printf("ERROR pos5\n");
    }
    else {
        printf("pos5 ok\n");
    }
}
*/

//#############################################################################
//###################### NO MORE FAKES BEYOND THIS LINE #######################
//#############################################################################
//
//=============================================================================
// Revision History
//=============================================================================
//
// $Log: fen.c,v $
// Revision 1.2  2002/10/23 21:07:18  tnussb
// just the header modified
//
// Revision 1.1  2002/10/09 18:25:30  tnussb
// initial version
//
//
