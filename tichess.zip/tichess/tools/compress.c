/******************************************************************************
*
* project name:    TI-Chess / BookBuilder
* file name:       compress.c
* initial date:    04/10/2002
* author:          thomas.nussbaumer@gmx.net
* description:
*
* $Id: compress.c,v 1.6 2002/10/23 21:06:08 tnussb Exp $
*
******************************************************************************/

//-----------------------------------------------------------------------------
// huffman encoded chess pieces (C==0 -> white / C==1 -> black)
//
// Empty:  0
// Pawn:   10C
// Bishop: 1100C
// Knight: 1101C
// Rook:   1110C
// Queen:  11110C
// King:   11111C
//-----------------------------------------------------------------------------



#define AddBit(_x_) { if (_x_) *output |= bitmask;  \
                      else     *output &= ~bitmask; \
                      bitmask>>=1;                  \
                      if (!bitmask) {               \
                          bitmask=0x80;             \
                          output++;                 \
                      }                             \
                      retval++;                     \
                      if (retval>164) {             \
                          fprintf(stderr,"FATAL: too much bits in compressed position\n");\
                          exit(1);\
                      }}

//=============================================================================
// compresses a chess position (huffman encoding)
//
// input is a 64-byte long buffer holding a chess position
// output is a 21-byte buffer for compressed chess position
//
// returns size in bits of the compressed chess position (MAX=164 bits)
//=============================================================================
short EncodeBoard(char* input, unsigned char* output) {
    short i;
    short retval  = 0;
    short bitmask = 0x80;


    for (i=0;i<BOARD_SIZE;i++,input++) {
        char tmpstr[255];
        if (*input == OUTSIDE) continue;
        switch(*input) {
            case EMPTY:    AddBit(0); break;
            case W_PAWN:   AddBit(1); AddBit(0); AddBit(0); break;
            case B_PAWN:   AddBit(1); AddBit(0); AddBit(1); break;
            case W_BISHOP: AddBit(1); AddBit(1); AddBit(0); AddBit(0); AddBit(0); break;
            case B_BISHOP: AddBit(1); AddBit(1); AddBit(0); AddBit(0); AddBit(1); break;
            case W_KNIGHT: AddBit(1); AddBit(1); AddBit(0); AddBit(1); AddBit(0); break;
            case B_KNIGHT: AddBit(1); AddBit(1); AddBit(0); AddBit(1); AddBit(1); break;
            case W_ROOK:   AddBit(1); AddBit(1); AddBit(1); AddBit(0); AddBit(0); break;
            case B_ROOK:   AddBit(1); AddBit(1); AddBit(1); AddBit(0); AddBit(1); break;
            case W_QUEEN:  AddBit(1); AddBit(1); AddBit(1); AddBit(1);AddBit(0); AddBit(0); break;
            case B_QUEEN:  AddBit(1); AddBit(1); AddBit(1); AddBit(1);AddBit(0); AddBit(1); break;
            case W_KING:   AddBit(1); AddBit(1); AddBit(1); AddBit(1);AddBit(1); AddBit(0); break;
            case B_KING:   AddBit(1); AddBit(1); AddBit(1); AddBit(1);AddBit(1); AddBit(1); break;
            default:
                sprintf(tmpstr,"FATAL: unknown piece (%d) on field %d\n",*input,i);
                EmergencyExit(tmpstr);
        }
    }

    return retval;
}


#define CORRECT_POSITION() { bitpos>>=1;      \
                             if (!bitpos) {   \
                                 bitpos=0x80; \
                                 input++;     \
                             }}

//=============================================================================
// decompresses a huffman encoded chess position
//
// input is a 21-byte long buffer holding a compressed chess position
// output is a 64-byte buffer for decompressed chess position
//=============================================================================
void DecodeBoard(unsigned char* input, char* output) {
    short i;
    short bitpos = 0x80;

    for (i=0;i<BOARD_SIZE;i++,output++) {
        if (board_setup[i] == OUTSIDE) {
            *output = OUTSIDE;
            continue;
        }

        if (!(*input & bitpos)) {
            *output = EMPTY;
            goto correct_and_continue;
        }

        CORRECT_POSITION();

        if (!(*input & bitpos)) {
            CORRECT_POSITION();
            if (!(*input & bitpos)) *output = W_PAWN;
            else                    *output = B_PAWN;
            goto correct_and_continue;
        }

        CORRECT_POSITION();

        if (!(*input & bitpos)) {
            CORRECT_POSITION();
            if (!(*input & bitpos)) {
                 CORRECT_POSITION();
                 if (!(*input & bitpos)) *output = W_BISHOP;
                 else                    *output = B_BISHOP;
                 goto correct_and_continue;
            }
            CORRECT_POSITION();
            if (!(*input & bitpos)) *output = W_KNIGHT;
            else                    *output = B_KNIGHT;
            goto correct_and_continue;
        }

        CORRECT_POSITION();

        if (!(*input & bitpos)) {
            CORRECT_POSITION();
            if (!(*input & bitpos)) *output = W_ROOK;
            else                    *output = B_ROOK;
            goto correct_and_continue;
        }

        CORRECT_POSITION();

        if (!(*input & bitpos)) {
            CORRECT_POSITION();
            if (!(*input & bitpos)) *output = W_QUEEN;
            else                    *output = B_QUEEN;
            goto correct_and_continue;
        }

        CORRECT_POSITION();

        if (!(*input & bitpos)) *output = W_KING;
        else                    *output = B_KING;

    correct_and_continue:
        CORRECT_POSITION();
    }
}


int OutputPosition(POSITION_T* pos,int mirror_or_not); // forward declaration
int DecodeMove(MOVE_T* m,unsigned short val);


short FetchAndCompare(unsigned char* buffer,int index,POSITION_T* pos) {
    POSITION_T         test;
    int                i;
    unsigned long long val = 0;
    unsigned char*     output = buffer;
    MOVE_T*            orig_move;
    char               tmpstr[255];

    buffer += 8 + 10*index;  // 8 = magic + poscount + movecount

    val |= *buffer++;val <<= 8;val |= *buffer++;val <<= 8;
    val |= *buffer++;val <<= 8;val |= *buffer++;val <<= 8;
    val |= *buffer++;val <<= 8;val |= *buffer++;val <<= 8;
    val |= *buffer++;val <<= 8;val |= *buffer++;

    if (val != pos->hashcode) {
        WriteLog("ERROR: hashcode missmatch\n",MIRROR_TO_STDERR);
        return 0;
    }

    output += (*buffer<<8)+*(buffer+1);

    //-------------------------------------------------------------------------
    // now try to decompress it and check if it is equal ...
    //-------------------------------------------------------------------------
    DecodeBoard(output,test.board);

    test.side_to_move = (output[21] & 0x1) ? BLACK : WHITE;

    if (output[20] & 0x08) {
        test.epfield = output[20] & 0x7;
        if (test.side_to_move == BLACK) test.epfield += A3;
        else                            test.epfield += A6;
    }
    else {
        test.epfield = ILLEGAL;
    }

    test.castling_white_long  = (output[21] & 0x2) ? 1 : 0;
    test.castling_white_short = (output[21] & 0x4) ? 1 : 0;
    test.castling_black_long  = (output[21] & 0x8) ? 1 : 0;
    test.castling_black_short = (output[21] & 0x10) ? 1 : 0;

    test.hashcode = pos->hashcode;
    test.moves    = pos->moves;

    // equality checking starts here ...

    if (test.castling_white_long != pos->castling_white_long) {
        sprintf(tmpstr,"ERROR: compress missmatch in castling long white! (%d != %d)\n",
                        test.castling_white_long,pos->castling_white_long);
        WriteLog(tmpstr,MIRROR_TO_STDERR);
        OutputPosition(&test,MIRROR_TO_STDERR);return 0;
    }
    if (test.castling_white_short != pos->castling_white_short) {
        sprintf(tmpstr,"ERROR: compress missmatch in castling short white!\n");
        WriteLog(tmpstr,MIRROR_TO_STDERR);
        OutputPosition(&test,MIRROR_TO_STDERR);return 0;
    }
    if (test.castling_black_long  != pos->castling_black_long) {
        sprintf(tmpstr,"ERROR: compress missmatch in castling long black! (%d != %d)\n",
                        test.castling_black_long,pos->castling_black_long);
        WriteLog(tmpstr,MIRROR_TO_STDERR);
        OutputPosition(&test,MIRROR_TO_STDERR);return 0;
    }
    if (test.castling_black_short != pos->castling_black_short) {
        sprintf(tmpstr,"ERROR: compress missmatch in castling short black!\n");
        WriteLog(tmpstr,MIRROR_TO_STDERR);
        OutputPosition(&test,MIRROR_TO_STDERR);return 0;
    }
    if (test.epfield != pos->epfield) {
        sprintf(tmpstr,"ERROR: compress missmatch in epfield!\n");
        WriteLog(tmpstr,MIRROR_TO_STDERR);
        OutputPosition(&test,MIRROR_TO_STDERR);return 0;
    }
    if (test.side_to_move != pos->side_to_move) {
        sprintf(tmpstr,"ERROR: compress missmatch in side_to_move!\n");
        WriteLog(tmpstr,MIRROR_TO_STDERR);
        OutputPosition(&test,MIRROR_TO_STDERR);return 0;
    }
    if (memcmp(test.board,pos->board,BOARD_SIZE)) {
        sprintf(tmpstr,"ERROR: compress missmatch in board!\n");
        WriteLog(tmpstr,MIRROR_TO_STDERR);
        OutputPosition(&test,MIRROR_TO_STDERR);return 0;
    }


    output += COMPRESSED_POS_SIZE;

    orig_move = pos->moves;
    while (orig_move) {
        unsigned short compressed_move;
        MOVE_T         tmp_move;
        int            result;

        compressed_move = (*output<<8)+*(output+1);
        output+=2;

        result = DecodeMove(&tmp_move,compressed_move);
        if (result && !orig_move->next) {
            WriteLog("ERROR: compress missmatch in number of moves!\n",MIRROR_TO_STDERR);
            return 0;
        }
        if (tmp_move.from != orig_move->from) {
            WriteLog("ERROR: compress missmatch in from field\n",MIRROR_TO_STDERR);
            return 0;
        }
        if (tmp_move.to != orig_move->to) {
            WriteLog("ERROR: compress missmatch in to field\n",MIRROR_TO_STDERR);
            return 0;
        }
        if (tmp_move.promote != orig_move->promote) {
            WriteLog("ERROR: compress missmatch in promote field\n",MIRROR_TO_STDERR);
            return 0;
        }
        orig_move = orig_move->next;
    }

    return 1;
}



short CompressAndTry(POSITION_T* pos,unsigned char *output) {
    POSITION_T test;
    short      ret;
    char       tmpstr[255];

    memset(output,0,COMPRESSED_POS_SIZE);

    //-------------------------------------------------------------------------
    // compress position ...
    //-------------------------------------------------------------------------
    ret = EncodeBoard(pos->board,output);

    //-------------------------------------------------------------------------
    // fill the other flags ...
    //-------------------------------------------------------------------------
    if (pos->side_to_move == WHITE) output[21] &= 0xfe;
    else                            output[21] |= 0x01;

    if (pos->epfield != ILLEGAL) {
        //printf("setting epfield (%d)\n",pos->epfield);
        output[20] |= 0x08; // epfield is used
        output[20] |= ((pos->epfield-21) % 10) & 0x07;
    }

    if (pos->castling_white_long)  output[21] |= 0x2;
    else                           output[21] &= 0xfd;
    if (pos->castling_white_short) output[21] |= 0x4;
    else                           output[21] &= 0xfb;
    if (pos->castling_black_long)  output[21] |= 0x8;
    else                           output[21] &= 0xf7;
    if (pos->castling_black_short) output[21] |= 0x10;
    else                           output[21] &= 0xef;


    //-------------------------------------------------------------------------
    // now try to decompress it and check if it is equal ...
    //-------------------------------------------------------------------------
    DecodeBoard(output,test.board);

    test.side_to_move = (output[21] & 0x1) ? BLACK : WHITE;

    if (output[20] & 0x08) {
        test.epfield = output[20] & 0x7;
        if (test.side_to_move == BLACK) test.epfield += A3;
        else                            test.epfield += A6;
    }
    else {
        test.epfield = ILLEGAL;
    }

    test.castling_white_long  = (output[21] & 0x2) ? 1 : 0;
    test.castling_white_short = (output[21] & 0x4) ? 1 : 0;
    test.castling_black_long  = (output[21] & 0x8) ? 1 : 0;
    test.castling_black_short = (output[21] & 0x10) ? 1 : 0;

    test.hashcode = pos->hashcode;
    test.moves    = pos->moves;

    // equality checking starts here ...

    if (test.castling_white_long != pos->castling_white_long) {
        sprintf(tmpstr,"ERROR: compress missmatch in - castling long white! (%d != %d)\n",
                        test.castling_white_long,pos->castling_white_long);
        WriteLog(tmpstr,MIRROR_TO_STDERR);
        OutputPosition(&test,MIRROR_TO_STDERR);return -1;
    }
    if (test.castling_white_short != pos->castling_white_short) {
        WriteLog("ERROR: compress missmatch in - castling short white!\n",MIRROR_TO_STDERR);
        OutputPosition(&test,MIRROR_TO_STDERR);return -1;
    }
    if (test.castling_black_long  != pos->castling_black_long) {
        sprintf(tmpstr,"ERROR: compress missmatch in - castling long black! (%d != %d)\n",
                        test.castling_black_long,pos->castling_black_long);
        WriteLog(tmpstr,MIRROR_TO_STDERR);
        OutputPosition(&test,MIRROR_TO_STDERR);return -1;
    }
    if (test.castling_black_short != pos->castling_black_short) {
        WriteLog("ERROR: compress missmatch in - castling short black!\n",MIRROR_TO_STDERR);
        OutputPosition(&test,MIRROR_TO_STDERR);return -1;
    }
    if (test.epfield != pos->epfield) {
        sprintf(tmpstr,"ERROR: compress missmatch in - epfield (orig=%d compressed= %d)\n",pos->epfield, test.epfield);
        WriteLog(tmpstr,MIRROR_TO_STDERR);
        OutputPosition(&test,MIRROR_TO_STDERR);return -1;
    }
    if (test.side_to_move != pos->side_to_move) {
        WriteLog("ERROR: compress missmatch in - side_to_move!\n",MIRROR_TO_STDERR);
        OutputPosition(&test,MIRROR_TO_STDERR);return -1;
    }
    if (memcmp(test.board,pos->board,BOARD_SIZE)) {
        WriteLog("ERROR: compress missmatch in - board!\n",MIRROR_TO_STDERR);

        //{
        //    int x,y;
        //
        //    fprintf(stderr,"orig=\n");
        //    for (y=7;y>=0;y--) {
        //        for (x=0;x<8;x++) {
        //            fprintf(stderr,"%c",FIG2SYM(LOWERCASE,*(pos->board+21+x+y*10)));
        //        }
        //        fprintf(stderr,"\n");
        //    }
        //    fprintf(stderr,"\n");
        //}

        OutputPosition(&test,MIRROR_TO_STDERR);return -1;
    }

    return ret;
}


unsigned short CompressMove(MOVE_T* m) {
    unsigned short ret = 0;

    unsigned short from = ((m->from-21)%10) + ((m->from-21)/10)*8;
    unsigned short to   = ((m->to-21)%10) + ((m->to-21)/10)*8;

    //printf("%d/%d -> %d/%d\n",m->from,m->to,from,to);

    ret |= from & 0x3f;
    ret |= ((unsigned char)(to) & 0x3f) << 6;

    switch(m->promote) {
       case 0:   break;
       case 'q': ret |= 0x1000; break;   // 0b001
       case 'r': ret |= 0x2000; break;   // 0b010
       case 'b': ret |= 0x3000; break;   // 0b011
       case 'n': ret |= 0x4000; break;   // 0b100
       default:  EmergencyExit("FATAL: unknown promotion (internal problem)\n");
    }

    if (m->next) ret |= 0x8000;

    return ret;
}

int DecodeMove(MOVE_T* m,unsigned short val) {
    unsigned short prom;

    int tmp = val & 0x3f;

    m->from = 21+(tmp/8)*10+(tmp%8);
    tmp     = (val >> 6) & 0x3f;
    m->to   = 21+(tmp/8)*10+(tmp%8);

    prom = (val >> 12) & 0x7;
    switch(prom) {
       case 0:  m->promote = 0;   break;
       case 1:  m->promote = 'q'; break;
       case 2:  m->promote = 'r'; break;
       case 3:  m->promote = 'b'; break;
       case 4:  m->promote = 'n'; break;
       default: EmergencyExit("FATAL: missmatch in promotion!\n");
    }

    return (val & 0x8000) ? 1 : 0;
}


int WriteCompressedPosition(unsigned char* buffer,POSITION_T* pos) {
    unsigned char  compressed_board[COMPRESSED_POS_SIZE];
    int            bytes_written = COMPRESSED_POS_SIZE;
    MOVE_T*        tmp = pos->moves;
    unsigned short compressed_move;

    CompressAndTry(pos,compressed_board);
    memcpy(buffer,compressed_board,COMPRESSED_POS_SIZE);
    buffer+=COMPRESSED_POS_SIZE;

    while (tmp) {
        compressed_move = CompressMove(tmp);
        *buffer++ = (compressed_move >> 8) & 0xff;
        *buffer++ = compressed_move & 0xff;
        bytes_written+=2;
        tmp = tmp->next;
    }

    return bytes_written;
}




//#############################################################################
//###################### NO MORE FAKES BEYOND THIS LINE #######################
//#############################################################################
//
//=============================================================================
// Revision History
//=============================================================================
//
// $Log: compress.c,v $
// Revision 1.6  2002/10/23 21:06:08  tnussb
// changes to support PGN input instead of idiotic from-to notation
//
// Revision 1.5  2002/10/16 17:00:04  tnussb
// check against maximum number of bits for compressed board position added
//
// Revision 1.4  2002/10/11 15:25:59  tnussb
// bug in promotion handling fixed
//
// Revision 1.3  2002/10/11 14:14:11  tnussb
// number of continuation moves in a book gets now stored at the beginning
// of the bookfile.
//
// Revision 1.2  2002/10/09 15:50:22  tnussb
// too many changes to list separately
//
// Revision 1.1  2002/10/08 17:40:13  tnussb
// initial check-in
//
//
