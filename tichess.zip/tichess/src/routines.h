/******************************************************************************
*
* project name:    TI-Chess
* file name:       routines.h
* initial date:    08/02/2002
* author:          thomas.nussbaumer@gmx.net
* description:     prototypes of routines which are shared between files
*
* $Id: routines.h,v 1.14 2004/08/06 13:59:25 DEBROUX Lionel Exp $
*
******************************************************************************/

#ifndef TICROUTINES_H
#define TICROUTINES_H

#include "defines.h"


//-----------------------------------------------------------------------------
// logo.c
//-----------------------------------------------------------------------------
void Logo(void);

//-----------------------------------------------------------------------------
// bg_ti89.c / bg_ti92.c
//-----------------------------------------------------------------------------
void OutputBackground();

//-----------------------------------------------------------------------------
// board.c
//-----------------------------------------------------------------------------
void DrawFigure(short x, short y,char s);
void DrawSquare(short x, short y,char s);
void DrawCoordinates(short inverted);

//-----------------------------------------------------------------------------
// clocks.c
//-----------------------------------------------------------------------------
void IncrementClock(void);
void SwitchClockPositions(void);
void ToggleClocks(short reset,short inverted);

//-----------------------------------------------------------------------------
// engine.c
//-----------------------------------------------------------------------------
void        FreeReservedMemory(void);
void        TakeBackMove(short silent);
void        UndoTakeBackMove(short silent);
short       InitMemory(void);
void        FreeMemory(void);
inline void InitEngine(short level);
char*       Field2Notation(short fieldnumber,char* fieldnotation);
const char* Move2Str(move_t *pmove,short fromboard);
short       AttacksField(short field, short side);
void        InitPawnVars(void);
move_t*     ComputerMove(void);
short       UserMove(char* input,short updateboards,short level);

//-----------------------------------------------------------------------------
// hash.c (but exported through engine.c -- for speedup reasons hash.c is
//         included in engine.c)
//-----------------------------------------------------------------------------
void ResetHashCounters(void);
inline void InitHashCode(void);
void CalcHashKey(void);


//-----------------------------------------------------------------------------
// generic.c
//-----------------------------------------------------------------------------
void DrawColorLine(short x0,short y0,short x1, short y1, short color);
void DrawColorRect(short x0,short y0,short x1, short y1, short color,short fill);
void InvertGrayRect(short x0,short y0,short x1, short y1);
void DrawPopup(short x0,short y0,short x1, short y1);
void DrawString(short x,short y,const char* s,short font,short attr);
extern short InitFastDraw(void);
extern void FastDraw(register short x asm("%d0"),register short y asm("%d1"),register const unsigned char* s asm("%a0"));
short FastStringWidth(char* s);
void FastDrawCentered(short y,const unsigned char* s);

//-----------------------------------------------------------------------------
// gui.c
//-----------------------------------------------------------------------------
short RequestDialog(const char* request);
short ForceRequestDialog(const char* request);
void  LeavePrg(const char* msg);
void  CorrectInfoBoard(void);
void  MainGUI(void);


//-----------------------------------------------------------------------------
// infoboards.c
//-----------------------------------------------------------------------------
void DrawInfoBoard(short nr);
void UpdateMoveDisplay(move_t* pmove,short fromboard);
void MisuseNodeDisplay(char* s);
void UpdateNodeDisplay(long nodes);
void SetActiveInfo(short color,short level,short redraw);
void OutputSpecial(const char* s1,const char* s2);
void SwitchInfoBoards(void);
void ClearActiveInfoBoardData(void);
void ClearActiveMoveAndNodeInfoBoardData(void);
void ClearInfoBoardData(void);
void InitInfo(short color,short level1,short level2,short inverted);

//-----------------------------------------------------------------------------
// input.c
//-----------------------------------------------------------------------------
short KeyPressed(void);
short GetUserInput(short inc_clock);
void WaitForMillis(register unsigned short asm("%d2"));


//-----------------------------------------------------------------------------
// loadsave.c
//-----------------------------------------------------------------------------
short OpenTICFile(ticfile_t* f);
void  CloseTICFile(ticfile_t* f);
short FindAndOpenTICFiles(ticfile_t* f,short maxfiles,unsigned long magic);
void  CompressedMove2String(unsigned short move,char* buffer);
unsigned short GenerateCompressedMove(char from,char to, char promote);
short HandleLoad(short automatic);
short HandleSave(short automatic);
short LoadDefaults(void);
void  SaveDefaults(void);
void  InitPuzzles(void);
void  CleanupPuzzles(void);
void  LoadPuzzleDesc(void);
void  LoadActivePuzzle(void);
void  HandleExport(void);


//-----------------------------------------------------------------------------
// menu.c
//-----------------------------------------------------------------------------
short MainMenu(short showmenu);
short PromotionDialog(void);
void  InitCenterMenu(void);


//-----------------------------------------------------------------------------
// opening.c
//-----------------------------------------------------------------------------
void  InitBooks(void);
void  CleanupBooks(void);
char* GetOpening(void);
char* GetOpeningDesc(void);
//char* GetBookInfo(short booktype,short index);
void  ShowContinuationList(void);


#endif


//#############################################################################
//###################### NO MORE FAKES BEYOND THIS LINE #######################
//#############################################################################
//
//=============================================================================
// Revision History
//=============================================================================
//
// $Log: routines.h,v $
// Revision 1.14  2004/08/06 13:59:25  DEBROUX Lionel
// generic commit
//
// Revision 1.13  2002/10/21 18:06:28  tnussb
// generic commit
//
// Revision 1.12  2002/10/18 16:03:54  tnussb
// see history.txt for v3.98b
//
// Revision 1.11  2002/10/17 11:30:56  tnussb
// changes due to new font graphics data retrieving by Lionel Debroux
// (the sprite data is fetched from the AMS)
//
// Revision 1.10  2002/10/17 09:56:42  tnussb
// generic commit for v3.97
//
// Revision 1.9  2002/10/16 18:28:52  tnussb
// changes related to the complete new puzzle file support (see history.txt)
//
// Revision 1.8  2002/10/14 12:51:18  tnussb
// generic commit
//
// Revision 1.7  2002/10/11 13:22:53  tnussb
// (1) BooksMenu() removed
// (2) GetBookInfo() added
//
// Revision 1.6  2002/10/10 13:19:30  tnussb
// changes related to new chess puzzle format
//
// Revision 1.5  2002/10/08 17:44:30  tnussb
// changes related to v3.90/v3.91
//
// Revision 1.4  2002/09/13 16:18:21  tnussb
// generic commit
//
// Revision 1.3  2002/09/13 15:25:03  tnussb
// changes for v3.81 BETA (external opening book support)
//
// Revision 1.2  2002/09/13 10:20:01  tnussb
// changes related to opening book support (3.80 Beta)
//
// Revision 1.1  2002/02/11 16:34:23  tnussb
// initial version
//
//
