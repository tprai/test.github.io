/******************************************************************************
*
* project name:    TI-Chess
* file name:       logout.c
* initial date:    16/03/2000
* authors:         thomas.nussbaumer@gmx.net (coding)
*                  marcos.lopez@gmx.net      (design/graphics/beta testing)
* description:     routines for log output to virtual port
*                  (only used during engine debugging stage)
*
* $Id: logout.c,v 1.5 2004/08/06 13:55:39 DEBROUX Lionel Exp $
*
******************************************************************************/

#include "hardware.h"   // MUST BE ALWAYS HERE ON THE FIRST LINE !!!!
#include <mem.h>
#include <string.h>
#include <link.h>

#define LBUFFER_MAX 128



/*===========================================================================*/
/* low level routine to output a binary string to the link port              */
/*                                                                           */
/* NOTE: This routine shouldn't be used directly. Use the macros from        */
/*       logout.h instead                                                    */
/*===========================================================================*/
void _Bin2Link(unsigned long len,const char* msg) {
    unsigned short  idx;
    unsigned short  needed;

    idx = 0;

    while (len > 0) {
        if (len < LBUFFER_MAX) {
            needed = len;
        }
        else {
            needed = LBUFFER_MAX;
        }
        do {
        } while (OSWriteLinkBlock((char*)msg+idx,needed));

        idx += needed;
        len -= needed;
    }
}



/*===========================================================================*/
/* low level routine to output a log message to the link port                */
/*                                                                           */
/* NOTE: This routine shouldn't be used directly. Use the macros from        */
/*       logout.h instead                                                    */
/*===========================================================================*/
void _Log2Link(const char* msg) {
    if (msg == 0) return;
    _Bin2Link(strlen((char*)msg),msg);
}



/*===========================================================================*/
/* low level routine to output a binary string as HEX dump to the link port  */
/*                                                                           */
/* NOTE: This routine shouldn't be used directly. Use the macros from        */
/*       logout.h instead                                                    */
/*===========================================================================*/
void _Hex2Link(unsigned long len,const char* msg) {
    //
    //
    // !!! NOT IMPLEMENTED UNTIL NOW !!!
    //
    //
}


//#############################################################################
//###################### NO MORE FAKES BEYOND THIS LINE #######################
//#############################################################################
//
//=============================================================================
// Revision History
//=============================================================================
//
// $Log: logout.c,v $
// Revision 1.5  2004/08/06 13:55:39  DEBROUX Lionel
// generic commit
//
// Revision 1.4  2002/02/11 16:38:12  tnussb
// many changes due to "separate file compiling" restructuring
//
// Revision 1.3  2001/02/17 15:00:11  Thomas Nussbaumer
// changes due to new TIGCC version
//
// Revision 1.2  2000/08/12 15:31:13  Thomas Nussbaumer
// substitution keywords added
//
//
