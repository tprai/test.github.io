/******************************************************************************
*
* project name:    TI-Chess
* file name:       version.h
* authors:         thomas.nussbaumer@gmx.net (coding)
*                  marcos.lopez@gmx.net      (design/graphics/beta testing)
* description:     contains just the version number as string
*
* NOTE that this file contains no CVS history by intention (doesn't make sense)
*
* $Id: version.h,v 1.22 2004/08/06 14:01:43 DEBROUX Lionel Exp $
*
******************************************************************************/

#ifndef TICVERSION_H
#define TICVERSION_H

#define TIC_VERSION_MAIN "4.11"TIC_VERSION_LANG
#define TIC_VERSION_SUB  ""

#define TIC_VERSION_COMPLETE TIC_VERSION_MAIN""TIC_VERSION_SUB

#endif
