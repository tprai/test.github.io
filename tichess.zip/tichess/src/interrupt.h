/******************************************************************************
*
* project name:    TI-Chess
* file name:       interrupt.h
* initial date:    12/07/2000
* authors:         thomas.nussbaumer@gmx.net (coding)
*                  marcos.lopez@gmx.net      (design/graphics/beta testing)
* description:     headerfile for keyboard handler routine
*
* !!! Thanx to Zeljko Juric to help me out with informations !!!
*
* $Id: interrupt.h,v 1.7 2004/08/06 13:54:45 DEBROUX Lionel Exp $
*
******************************************************************************/

#ifndef __INTERRUPT_H__
#define __INTERRUPT_H__


extern volatile unsigned char onkey;     // used to detect [ON] key pressed for break
extern unsigned char trow[10];

void InstallInterruptHandlers(void);
void RestoreInterruptHandlers(void);



#if defined(USE_TI92P)
//=============================================================================
// low level key definitions for TI92 version
//-----------------------------------------------------------------------------
//
//  Row    +-------+-------+-------+-------+-------+-------+-------+-------+
//   V Col>| Bit 7 | Bit 6 | Bit 5 | Bit 4 | Bit 3 | Bit 2 | Bit 1 | Bit 0 |
// +-------+-------+-------+-------+-------+-------+-------+-------+-------+
// | 0     |  down | right |   up  |  left |  hand | shift |diamond|  2nd  |
// | 1     |   3   |   2   |   1   |   F8  |   W   |   S   |   Z   | unused|
// | 2     |   6   |   5   |   4   |   F3  |   E   |   D   |   X   | unused|
// | 3     |   9   |   8   |   7   |   F7  |   R   |   F   |   C   |  STO  |
// | 4     |   ,   |   )   |   (   |   F2  |   T   |   G   |   V   | space |
// | 5     |  TAN  |  COS  |  SIN  |   F6  |   Y   |   H   |   B   |   /   |
// | 6     |   P   | ENTER2|   LN  |   F1  |   U   |   J   |   N   |   ^   |
// | 7     |   *   |  APPS | CLEAR |   F5  |   I   |   K   |   M   |   =   |
// | 8     | unused|  ESC  |  MODE |   +   |   O   |   L   | theta |backspc|
// | 9     |  (-)  |   .   |   0   |   F4  |   Q   |   A   | ENTER1|   -   |
// +-------+-------+-------+-------+-------+-------+-------+-------+-------+
// Note: ENTER1 is on the alphabetic _and_ numeric keypads.
//       ENTER2 is next to the cursor pad.
//
//=============================================================================

//-----------------------------------------------------------------------------
// TI92 - row 0
//-----------------------------------------------------------------------------
#define KEYPRESS_2ND     (trow[0] & 0x01)
#define KEYPRESS_DIAMOND (trow[0] & 0x02)
#define KEYPRESS_SHIFT   (trow[0] & 0x04)
#define KEYPRESS_HAND    (trow[0] & 0x08)
#define KEYPRESS_LEFT    (trow[0] & 0x10)
#define KEYPRESS_UP      (trow[0] & 0x20)
#define KEYPRESS_RIGHT   (trow[0] & 0x40)
#define KEYPRESS_DOWN    (trow[0] & 0x80)

//-----------------------------------------------------------------------------
// TI92 - row 1
//-----------------------------------------------------------------------------
#define KEYPRESS_Z  (trow[1] & 0x02)
#define KEYPRESS_S  (trow[1] & 0x04)
#define KEYPRESS_W  (trow[1] & 0x08)
#define KEYPRESS_F8 (trow[1] & 0x10)
#define KEYPRESS_1  (trow[1] & 0x20)
#define KEYPRESS_2  (trow[1] & 0x40)
#define KEYPRESS_3  (trow[1] & 0x80)

//-----------------------------------------------------------------------------
// TI92 - row 2
//-----------------------------------------------------------------------------
#define KEYPRESS_X  (trow[2] & 0x02)
#define KEYPRESS_D  (trow[2] & 0x04)
#define KEYPRESS_E  (trow[2] & 0x08)
#define KEYPRESS_F3 (trow[2] & 0x10)
#define KEYPRESS_4  (trow[2] & 0x20)
#define KEYPRESS_5  (trow[2] & 0x40)
#define KEYPRESS_6  (trow[2] & 0x80)

//-----------------------------------------------------------------------------
// TI92 - row 3
//-----------------------------------------------------------------------------
#define KEYPRESS_STO (trow[3] & 0x01)
#define KEYPRESS_C   (trow[3] & 0x02)
#define KEYPRESS_F   (trow[3] & 0x04)
#define KEYPRESS_R   (trow[3] & 0x08)
#define KEYPRESS_F7  (trow[3] & 0x10)
#define KEYPRESS_7   (trow[3] & 0x20)
#define KEYPRESS_8   (trow[3] & 0x40)
#define KEYPRESS_9   (trow[3] & 0x80)

//-----------------------------------------------------------------------------
// TI92 - row 4
//-----------------------------------------------------------------------------
#define KEYPRESS_SPACE    (trow[4] & 0x01)
#define KEYPRESS_V        (trow[4] & 0x02)
#define KEYPRESS_G        (trow[4] & 0x04)
#define KEYPRESS_T        (trow[4] & 0x08)
#define KEYPRESS_F2       (trow[4] & 0x10)
#define KEYPRESS_OBRACKET (trow[4] & 0x20)
#define KEYPRESS_CBRACKET (trow[4] & 0x40)
#define KEYPRESS_COMMA    (trow[4] & 0x80)

//-----------------------------------------------------------------------------
// TI92 - row 5
//-----------------------------------------------------------------------------
#define KEYPRESS_SLASH (trow[5] & 0x01)
#define KEYPRESS_B     (trow[5] & 0x02)
#define KEYPRESS_H     (trow[5] & 0x04)
#define KEYPRESS_Y     (trow[5] & 0x08)
#define KEYPRESS_F6    (trow[5] & 0x10)
#define KEYPRESS_SIN   (trow[5] & 0x20)
#define KEYPRESS_COS   (trow[5] & 0x40)
#define KEYPRESS_TAN   (trow[5] & 0x80)

//-----------------------------------------------------------------------------
// TI92 - row 6
//-----------------------------------------------------------------------------
#define KEYPRESS_TOPARROW (trow[6] & 0x01)
#define KEYPRESS_N        (trow[6] & 0x02)
#define KEYPRESS_J        (trow[6] & 0x04)
#define KEYPRESS_U        (trow[6] & 0x08)
#define KEYPRESS_F1       (trow[6] & 0x10)
#define KEYPRESS_LN       (trow[6] & 0x20)
#define KEYPRESS_ENTER2   (trow[6] & 0x40)
#define KEYPRESS_P        (trow[6] & 0x80)

//-----------------------------------------------------------------------------
// TI92 - row 7
//-----------------------------------------------------------------------------
#define KEYPRESS_EQUAL (trow[7] & 0x01)
#define KEYPRESS_M     (trow[7] & 0x02)
#define KEYPRESS_K     (trow[7] & 0x04)
#define KEYPRESS_I     (trow[7] & 0x08)
#define KEYPRESS_F5    (trow[7] & 0x10)
#define KEYPRESS_CLEAR (trow[7] & 0x20)
#define KEYPRESS_APPS  (trow[7] & 0x40)
#define KEYPRESS_TIMES (trow[7] & 0x80)

//-----------------------------------------------------------------------------
// TI92 - row 8
//-----------------------------------------------------------------------------
#define KEYPRESS_BACK  (trow[8] & 0x01)
#define KEYPRESS_THETA (trow[8] & 0x02)
#define KEYPRESS_L     (trow[8] & 0x04)
#define KEYPRESS_O     (trow[8] & 0x08)
#define KEYPRESS_PLUS  (trow[8] & 0x10)
#define KEYPRESS_MODE  (trow[8] & 0x20)
#define KEYPRESS_ESC   (trow[8] & 0x40)

//-----------------------------------------------------------------------------
// TI92 - row 9
//-----------------------------------------------------------------------------
#define KEYPRESS_MINUS  (trow[9] & 0x01)
#define KEYPRESS_ENTER1 (trow[9] & 0x02)
#define KEYPRESS_A      (trow[9] & 0x04)
#define KEYPRESS_Q      (trow[9] & 0x08)
#define KEYPRESS_F4     (trow[9] & 0x10)
#define KEYPRESS_0      (trow[9] & 0x20)
#define KEYPRESS_DOT    (trow[9] & 0x40)
#define KEYPRESS_MINUS2 (trow[9] & 0x80)



#else



//=============================================================================
// low level key definitions for TI89 version
//-----------------------------------------------------------------------------
//
//  Row    +-------+-------+-------+-------+-------+-------+-------+-------+
//   V Col>| Bit 7 | Bit 6 | Bit 5 | Bit 4 | Bit 3 | Bit 2 | Bit 1 | Bit 0 |
// +-------+-------+-------+-------+-------+-------+-------+-------+-------+
// | 0     | Alpha | Diam. | Shift |  2nd  | Right | Down  | Left  |  Up   |
// | 1     |   F5  | Clear |   ^   |   /   |   *   |   -   |   +   | Enter |
// | 2     |   F4  |Backspc|   T   |   ,   |   9   |   6   |   3   |  (-)  |
// | 3     |   F3  |Catalog|   Z   |   )   |   8   |   5   |   2   |   .   |
// | 4     |   F2  |  Mode |   Y   |   (   |   7   |   4   |   1   |   0   |
// | 5     |   F1  |  Home |   X   |   =   |   |   |   EE  |  STO  |  Apps |
// | 6     |       |       |       |       |       |       |       |  Esc  |
// +-------+-------+-------+-------+-------+-------+-------+-------+-------+
//
//=============================================================================

//-----------------------------------------------------------------------------
// TI89 - row 0
//-----------------------------------------------------------------------------
#define KEYPRESS_UP      (trow[0] & 0x01)
#define KEYPRESS_LEFT    (trow[0] & 0x02)
#define KEYPRESS_DOWN    (trow[0] & 0x04)
#define KEYPRESS_RIGHT   (trow[0] & 0x08)
#define KEYPRESS_2ND     (trow[0] & 0x10)
#define KEYPRESS_SHIFT   (trow[0] & 0x20)
#define KEYPRESS_DIAMOND (trow[0] & 0x40)
#define KEYPRESS_ALPHA   (trow[0] & 0x80)

//-----------------------------------------------------------------------------
// TI89 - row 1
//-----------------------------------------------------------------------------
#define KEYPRESS_ENTER   (trow[1] & 0x01)
#define KEYPRESS_PLUS    (trow[1] & 0x02)
#define KEYPRESS_MINUS   (trow[1] & 0x04)
#define KEYPRESS_CLEAR   (trow[1] & 0x40)
#define KEYPRESS_F5      (trow[1] & 0x80)

//-----------------------------------------------------------------------------
// TI89 - row 2
//-----------------------------------------------------------------------------
#define KEYPRESS_N    (trow[2] & 0x04)
#define KEYPRESS_6    KEYPRESS_N
#define KEYPRESS_9    (trow[2] & 0x08)
#define KEYPRESS_T    (trow[2] & 0x20)
#define KEYPRESS_BACK (trow[2] & 0x40)

//-----------------------------------------------------------------------------
// TI89 - row 3
//-----------------------------------------------------------------------------
#define KEYPRESS_DOT      (trow[3] & 0x01)
#define KEYPRESS_2        (trow[3] & 0x02)
#define KEYPRESS_CBRACKET (trow[3] & 0x10)
#define KEYPRESS_CAT      (trow[3] & 0x40)
#define KEYPRESS_F3       (trow[3] & 0x80)

//-----------------------------------------------------------------------------
// TI89 - row 4
//-----------------------------------------------------------------------------
#define KEYPRESS_0        (trow[4] & 0x01)
#define KEYPRESS_1        (trow[4] & 0x02)
#define KEYPRESS_OBRACKET (trow[4] & 0x10)
#define KEYPRESS_Y        (trow[4] & 0x20)
#define KEYPRESS_MODE     (trow[4] & 0x40)
#define KEYPRESS_F2       (trow[4] & 0x80)

//-----------------------------------------------------------------------------
// TI89 - row 5
//-----------------------------------------------------------------------------
#define KEYPRESS_STO    (trow[5] & 0x02)
#define KEYPRESS_EQUAL  (trow[5] & 0x10)
#define KEYPRESS_X      (trow[5] & 0x20)
#define KEYPRESS_HOME   (trow[5] & 0x40)
#define KEYPRESS_F1     (trow[5] & 0x80)

//-----------------------------------------------------------------------------
// TI89 - row 6
//-----------------------------------------------------------------------------
#define KEYPRESS_ESC    (trow[6] & 0x01)

#endif



//=============================================================================
// low level key definitions for both calculators
//=============================================================================

//-----------------------------------------------------------------------------
// special keys and combinations
//-----------------------------------------------------------------------------
#define KEYPRESS_OFF        (onkey)
#define KEYPRESS_CONTRASTUP KEYPRESS_PLUS
#define KEYPRESS_CONTRASTDN KEYPRESS_MINUS


#define ClearKeyBuffer()  {do_reset=1;}

#endif



//#############################################################################
//###################### NO MORE FAKES BEYOND THIS LINE #######################
//#############################################################################
//
//=============================================================================
// Revision History
//=============================================================================
//
// $Log: interrupt.h,v $
// Revision 1.7  2004/08/06 13:54:45  DEBROUX Lionel
// generic commit
//
// Revision 1.6  2002/03/01 17:29:04  tnussb
// changes due to multilanguage support
//
// Revision 1.5  2002/02/07 11:39:45  tnussb
// changes for v3.50beta and v3.50 (see history.txt)
//
// Revision 1.4  2001/02/17 15:00:11  Thomas Nussbaumer
// changes due to new TIGCC version
//
// Revision 1.3  2000/12/02 15:20:01  Thomas Nussbaumer
// KEYPRESS_F2 and KEYPRESS_F3 for TI89 added
//
// Revision 1.2  2000/08/12 15:31:13  Thomas Nussbaumer
// substitution keywords added
//
//
