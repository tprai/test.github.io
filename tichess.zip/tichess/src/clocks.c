/******************************************************************************
*
* project name:    TI-Chess
* file name:       clocks.c
* initial date:    11/07/2000
* authors:         thomas.nussbaumer@gmx.net (coding)
*                  marcos.lopez@wol.es (design/graphics/beta testing)
* description:     contains data and handling routines for clocks
*
* number sprites converted using Image Studio v1.1 (Matt Johnson)
*
* $Id: clocks.c,v 1.9 2004/08/06 13:48:26 DEBROUX Lionel Exp $
*
*******************************************************************************/

#include "hardware.h"    // MUST BE ALWAYS HERE ON THE FIRST LINE !!!!
#include <graph.h>
#include <gray.h>
#include <string.h>
#include <sprites.h>
#include "generic.h"
#include "defines.h"

extern short act_color;


STATIC_FUNC void Sprite8x7Gray(short x,short y,unsigned char *sprite1,unsigned char *sprite2,short mode);
STATIC_FUNC void DrawNumberOfClock(short nr,short clocknr);
STATIC_FUNC void DrawPointsOfClock(short clocknr);
STATIC_FUNC void UpdateAllNumbers(short nr);
STATIC_FUNC void RedrawClocks(void);


//--------------------------------------------------
// calculator depended definition of clock positions
//--------------------------------------------------
#define CLOCK_START_X    C89_92(116,166)
#define CLOCK_START_Y0   C89_92(91,99)
#define CLOCK_START_Y1   C89_92(2,10)


//------------------------------------------------------------------
//digital numbers for clocks (Both planes equal)
//------------------------------------------------------------------
unsigned char numbers[]={
0x30,0x48,0x48,0x00,0x48,0x48,0x30, //0
0x00,0x08,0x08,0x00,0x08,0x08,0x00, //1
0x30,0x08,0x08,0x30,0x40,0x40,0x30, //2
0x30,0x08,0x08,0x30,0x08,0x08,0x30, //3
0x00,0x48,0x48,0x30,0x08,0x08,0x00, //4
0x30,0x40,0x40,0x30,0x08,0x08,0x30, //5
0x30,0x40,0x40,0x30,0x48,0x48,0x30, //6
0x30,0x08,0x08,0x00,0x08,0x08,0x00, //7
0x30,0x48,0x48,0x30,0x48,0x48,0x30, //8
0x30,0x48,0x48,0x30,0x08,0x08,0x30};//9



//------------------------------------------------------------------
//inverted digital numbers for clocks used for inactive clock output
//------------------------------------------------------------------
unsigned char invnumbers[]={
~0x30,~0x48,~0x48,~0x00,~0x48,~0x48,~0x30, //0
~0x00,~0x08,~0x08,~0x00,~0x08,~0x08,~0x00, //1
~0x30,~0x08,~0x08,~0x30,~0x40,~0x40,~0x30, //2
~0x30,~0x08,~0x08,~0x30,~0x08,~0x08,~0x30, //3
~0x00,~0x48,~0x48,~0x30,~0x08,~0x08,~0x00, //4
~0x30,~0x40,~0x40,~0x30,~0x08,~0x08,~0x30, //5
~0x30,~0x40,~0x40,~0x30,~0x48,~0x48,~0x30, //6
~0x30,~0x08,~0x08,~0x00,~0x08,~0x08,~0x00, //7
~0x30,~0x48,~0x48,~0x30,~0x48,~0x48,~0x30, //8
~0x30,~0x48,~0x48,~0x30,~0x08,~0x08,~0x30};//9


//------------------------------------------------------------------
//misc. sprites for masking and inactive clock output
//------------------------------------------------------------------
unsigned char numclean[] = {0x03,0x03,0x03,0x03,0x03,0x03,0x03};
unsigned char numzeros[] = {0x0,0x0,0x0,0x0,0x0,0x0,0x0};
unsigned char numfill[]  = {0xfc,0xfc,0xfc,0xfc,0xfc,0xfc,0xfc};



//------------------------------------------------------------------
// structure describing a clock
//------------------------------------------------------------------
typedef struct {
    short x;              // x position of clock
    short y;              // y position of clock
    short digits[5];      // internally used
    short old_digits[5];  // internally used
} clock_t;


clock_t clocks[2]    = {};  // internal used clock structures for
                            // white and black
short   active_clock = 0;   // the active clock



/*===========================================================================*/
/* draws a 8x7 sprite in both planes                                         */
/*===========================================================================*/
STATIC_FUNC void Sprite8x7Gray(short x,short y,unsigned char *sprite1,unsigned char *sprite2,short mode)
{
    long           addr1 = (long)GetPlane(LIGHT_PLANE)+30*y+((x>>4)+(x>>4)),d1_1;
    long           addr2 = (long)GetPlane(DARK_PLANE) +30*y+((x>>4)+(x>>4)),d2_1;
    unsigned short cnt  = 24-(x&15),data1,data2;
    short          h = 7;

    for (;h--;addr1+=30,addr2+=30) {
        data1=*sprite1++;
        data2=*sprite2++;
        if (mode==SPRT_AND) {
            *(long*)addr1&=~((long)(~data1&0xff)<<cnt);
            *(long*)addr2&=~((long)(~data2&0xff)<<cnt);
        }
        else {
            d1_1=(long)data1<<cnt;
            d2_1=(long)data2<<cnt;
            *(long*)addr1|=d1_1;
            *(long*)addr2|=d2_1;
        }
    }
}



/*===========================================================================*/
/* draws single digit                                                        */
/*===========================================================================*/
STATIC_FUNC void DrawNumberOfClock(short nr,short clocknr) {
    static short nr_offset[] = {0,7,12,19,24};
    short x;
    short y;
    short offset;

    if (clocks[clocknr].digits[nr] != 13) { //clocks[clocknr].old_digits[nr]) {
        x      = nr_offset[nr] + clocks[clocknr].x;
        y      = clocks[clocknr].y;
        offset = clocks[clocknr].digits[nr]*7;
        if (clocknr == active_clock) {
            Sprite8x7Gray(x,y,numclean,numclean,SPRT_AND);
            Sprite8x7Gray(x,y,&numbers[offset],&numbers[offset],SPRT_OR);
        }
        else {
            Sprite8x7Gray(x,y,numclean,numclean,SPRT_AND);
            Sprite8x7Gray(x,y,numfill,numzeros,SPRT_OR);
            Sprite8x7Gray(x,y,&invnumbers[offset],numclean,SPRT_AND);
            Sprite8x7Gray(x,y,numzeros,&numbers[offset],SPRT_OR);
        }
        clocks[clocknr].old_digits[nr] = clocks[clocknr].digits[nr];
    }
}



/*===========================================================================*/
/* draws a double-point of clock                                             */
/*===========================================================================*/
STATIC_FUNC void DrawPointsOfClock(short clocknr) {
    short nr;

    for (nr=0;nr<2;nr++) {
        short x = clocks[clocknr].x+5;
        short y = clocks[clocknr].y;

        if (nr) x+=12;

        if (clocknr == active_clock) {
            Sprite8x7Gray(x,y,numclean,numclean,SPRT_AND);
        }
        else {
            Sprite8x7Gray(x,y,numclean,numclean,SPRT_AND);
            Sprite8x7Gray(x,y,numfill,numzeros,SPRT_OR);
        }
        x++;
        y+=2;
        SetPlane(0);
        if (clocknr == active_clock) {
            DrawPix(x,y,A_NORMAL);
            DrawPix(x,y+2,A_NORMAL);
        }
        else {
            DrawPix(x,y,A_REVERSE);
            DrawPix(x,y+2,A_REVERSE);
        }
        SetPlane(1);
        DrawPix(x,y,A_NORMAL);
        DrawPix(x,y+2,A_NORMAL);
    }
}



/*===========================================================================*/
/* update all numbers of a clock (redraw if changed)                         */
/*===========================================================================*/
STATIC_FUNC void UpdateAllNumbers(short nr) {
    short i;
    for (i=0;i<5;i++) DrawNumberOfClock(i,nr);
}



/*===========================================================================*/
/* increments the active clock                                               */
/*===========================================================================*/
void IncrementClock(void) {
    short x;
    short y;
    short i;

    short *digits;

    x      = clocks[active_clock].x;
    y      = clocks[active_clock].y;
    digits = clocks[active_clock].digits;

    digits[4]++;
    for (i=4;i>=0;i--) {
        if (digits[i] == (10 - ((i%2)<<2))) {
            digits[i] = 0;
            if (i) digits[i-1]++;
        }
    }
    UpdateAllNumbers(active_clock);
}



/*===========================================================================*/
/* redraws both clocks                                                       */
/*===========================================================================*/
STATIC_FUNC void RedrawClocks(void) {
    short tmp;
    short i;

    // hack to get a full refresh of all numbers of the clocks
    memset(clocks[0].old_digits,0xff,sizeof(short)*5);
    memset(clocks[1].old_digits,0xff,sizeof(short)*5);

    // redraw background of clocks
    for (tmp=0;tmp<2;tmp++) {
        short mode = A_REPLACE;
        short x    = clocks[tmp].x;
        short y    = clocks[tmp].y;

        if (tmp == active_clock) mode = A_REVERSE;

        SetPlane(0);
        DrawLine(x+1,y-1,x+28,y-1,mode);  // top
        DrawLine(x+1,y+7,x+28,y+7,mode);  // bottom
        DrawLine(x-1,y+1,x-1,y+5,mode);   // left
        DrawLine(x+30,y+1,x+30,y+5,mode); // right

        // fill the "which color" marking area
        for (i=0;i<2;i++) {
            SetPlane(i);
            mode = A_REPLACE;
            if (tmp==0) mode = A_REVERSE;
            DrawLine(x-12,y+1,x-3,y+1,mode);DrawLine(x+32,y+1,x+41,y+1,mode);
            DrawLine(x-13,y+2,x-3,y+2,mode);DrawLine(x+32,y+2,x+42,y+2,mode);
            DrawLine(x-13,y+3,x-3,y+3,mode);DrawLine(x+32,y+3,x+42,y+3,mode);
            DrawLine(x-13,y+4,x-3,y+4,mode);DrawLine(x+32,y+4,x+42,y+4,mode);
            DrawLine(x-12,y+5,x-3,y+5,mode);DrawLine(x+32,y+5,x+41,y+5,mode);
        }
    }

    // draw double points and numbers
    DrawPointsOfClock(0);
    DrawPointsOfClock(1);
    UpdateAllNumbers(0);
    UpdateAllNumbers(1);
}



/*===========================================================================*/
/* switches positions of clocks                                              */
/*===========================================================================*/
void SwitchClockPositions(void) {
    short y = clocks[0].y;

    clocks[0].y = clocks[1].y;
    clocks[1].y = y;
    RedrawClocks();
}



/*===========================================================================*/
/* Toggles the clocks                                                        */
/* if (reset == 1) the clocks will be reset to 0:00:00 and white clock       */
/* will be set active                                                        */
/*===========================================================================*/
void ToggleClocks(short reset,short inverted) {
    if (reset) {
        memset(clocks[0].digits,0,sizeof(short)*5);
        memset(clocks[1].digits,0,sizeof(short)*5);
        clocks[0].x     = CLOCK_START_X;
        clocks[0].y     = CLOCK_START_Y0;
        clocks[1].x     = CLOCK_START_X;
        clocks[1].y     = CLOCK_START_Y1;
    }

    if (act_color == WHITE) active_clock = 0;
    else                    active_clock = 1;

    if (clocks[inverted].y != CLOCK_START_Y0) SwitchClockPositions();
    else                                      RedrawClocks();

}



//#############################################################################
//###################### NO MORE FAKES BEYOND THIS LINE #######################
//#############################################################################
//
//=============================================================================
// Revision History
//=============================================================================
//
// $Log: clocks.c,v $
// Revision 1.9  2004/08/06 13:48:26  DEBROUX Lionel
// generic commit
//
// Revision 1.8  2002/10/21 08:53:03  tnussb
// toggleClocks(): use active_color to evaluate which clock should be active.
// this prevents the wrong clock from running
//
// Revision 1.7  2002/02/11 16:38:11  tnussb
// many changes due to "separate file compiling" restructuring
//
// Revision 1.6  2001/06/20 20:24:15  Thomas Nussbaumer
// size optimizations
//
// Revision 1.5  2001/02/17 15:00:11  Thomas Nussbaumer
// changes due to new TIGCC version
//
// Revision 1.4  2000/12/19 13:55:29  Thomas Nussbaumer
// warnings stated by compiling with option -Wall fixed
//
// Revision 1.3  2000/12/02 15:16:47  Thomas Nussbaumer
// changes due to global plane1/2 renaming
//
// Revision 1.2  2000/08/12 15:31:12  Thomas Nussbaumer
// substitution keywords added
//
//
