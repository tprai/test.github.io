/******************************************************************************
*
* project name:    TI-Chess
* file name:       debug.c
* initial date:    08/10/2002
* author:          thomas.nussbaumer@gmx.net
* description:     displays debug menu
*
******************************************************************************/

// THIS FILE GETS INCLUDED INTO gui.c !!!

extern short*         ep_field;
extern short*         material_bal;
extern short*         material_sum;
extern short          act_color;
extern unsigned short move_count;
extern short          moves_stored;
extern short          moves_forward;
extern unsigned short flags[];
extern hash_t         act_hashkey;
extern short          act_depth;
extern store_t*       move_store;


#define DEBUGMENU_ENTRIES 8
static const char* str_debugmenu[DEBUGMENU_ENTRIES] = {
    "hashcode:",
    "ep_field[0,1]:",
    "mat_bal[0,1]:",
    "mat_sum[0,1]:",
    "flags[0,1]:",
    "move_count:",
    "stored/forward:",
    "act_depth:"
};


extern openingbook_t  books[2][MAX_BOOKS_USED];
extern ticfile_t      bookfiles[2][MAX_BOOKS_USED];
extern short          nr_books[2];
extern ticfile_t      puzzle_files[MAX_PUZZLES_USED];
extern unsigned short puzzle_counts[MAX_PUZZLES_USED];
extern short          nr_puzzle_files;


/*===========================================================================*/
/* shows debug menu                                                          */
/*===========================================================================*/
void DebugMenu(void) {
    char           tmpstr[100];
    unsigned long  low  = act_hashkey & 0xffffffff;
    unsigned long  high = (act_hashkey >> 32) & 0xffffffff;
    short          i,j,booktype;
    LCD_BUFFER LCD_tmp1;
    LCD_BUFFER LCD_tmp2;

    memcpy(LCD_tmp1,GetPlane(LIGHT_PLANE),LCD_SIZE);
    memcpy(LCD_tmp2,GetPlane(DARK_PLANE), LCD_SIZE);

    //-------------------------------------------------------------------------
    // debug info of engine ...
    //-------------------------------------------------------------------------
    InitCenterMenu();
    FastDrawCentered(C89_92(7,17)-1,"-- ENGINE --");

    for (i=0;i<DEBUGMENU_ENTRIES;i++) {
        FastDraw(C89_92(12,52),10+i*7+C89_92(7,17)-1,str_debugmenu[i]);
    }
    sprintf(tmpstr,"%08lX%08lX",high,low);
    FastDraw(C89_92(12,52)+60,2*7+C89_92(7,17)-5,tmpstr);
    sprintf(tmpstr,"%d %d",ep_field[0],ep_field[1]);
    FastDraw(C89_92(12,52)+60,3*7+C89_92(7,17)-5,tmpstr);
    sprintf(tmpstr,"%d %d",material_bal[0],material_bal[1]);
    FastDraw(C89_92(12,52)+60,4*7+C89_92(7,17)-5,tmpstr);
    sprintf(tmpstr,"%d %d",material_sum[0],material_sum[1]);
    FastDraw(C89_92(12,52)+60,5*7+C89_92(7,17)-5,tmpstr);
    sprintf(tmpstr,"0x%04X 0x%04X",flags[0],flags[1]);
    FastDraw(C89_92(12,52)+60,6*7+C89_92(7,17)-5,tmpstr);
    sprintf(tmpstr,"%u",move_count);
    FastDraw(C89_92(12,52)+60,7*7+C89_92(7,17)-5,tmpstr);
    sprintf(tmpstr,"%d / %d",moves_stored,moves_forward);
    FastDraw(C89_92(12,52)+60,8*7+C89_92(7,17)-5,tmpstr);
    sprintf(tmpstr,"%d",act_depth);
    FastDraw(C89_92(12,52)+60,9*7+C89_92(7,17)-5,tmpstr);
    FastDrawCentered(12*7+C89_92(7,17)-1,"(press [=] for more infos)");

    if (GetUserInput(0)!=KEY_TESTING) goto get_out_here;

    //-------------------------------------------------------------------------
    // debug info of opening books ...
    //-------------------------------------------------------------------------
    for (booktype = 0;booktype<2;booktype++) {
        InitCenterMenu();
        if (!booktype) FastDrawCentered(C89_92(7,17)-1,"-- WHITE OPENING BOOKS --");
        else           FastDrawCentered(C89_92(7,17)-1,"-- BLACK OPENING BOOKS --");
        j=10+C89_92(7,17)-1;
        if (!nr_books[booktype]) {
            FastDrawCentered(j,"none installed");
        }
        else {
            for (i=0;i<nr_books[booktype];i++,j+=7) {
                sprintf(tmpstr,"%s\\%s",bookfiles[booktype][i].folder,bookfiles[booktype][i].name);
                FastDraw(C89_92(12,52),j,tmpstr);
                sprintf(tmpstr,"p=%05u m=%05u",
                        books[booktype][i].nr_pos,books[booktype][i].nr_moves);
                FastDraw(C89_92(12,52)+75,j,tmpstr);
            }
        }
        FastDrawCentered(12*7+C89_92(7,17)-1,"(press [=] for more infos)");
        if (GetUserInput(0) != KEY_TESTING) goto get_out_here;
    }

    //-------------------------------------------------------------------------
    // debug info of puzzle files ...
    //-------------------------------------------------------------------------
    InitCenterMenu();
    FastDrawCentered(C89_92(7,17)-1,"-- PUZZLE FILES --");
    j=10+C89_92(7,17)-1;

    if (!nr_puzzle_files) {
        FastDrawCentered(j,"none installed");
    }
    else {
        for (i=0;i<nr_puzzle_files;i++,j+=7) {
            sprintf(tmpstr,"%s\\%s",puzzle_files[i].folder,puzzle_files[i].name);
            FastDraw(C89_92(12,52),j,tmpstr);
            sprintf(tmpstr,"puzzles = %u",puzzle_counts[i]);
            FastDraw(C89_92(12,52)+75,j,tmpstr);
        }
    }
    GetUserInput(0);

get_out_here:
    memcpy(GetPlane(LIGHT_PLANE),LCD_tmp1,LCD_SIZE);
    memcpy(GetPlane(DARK_PLANE), LCD_tmp2,LCD_SIZE);
}


//#############################################################################
//###################### NO MORE FAKES BEYOND THIS LINE #######################
//#############################################################################
//
//=============================================================================
// Revision History
//=============================================================================
//
// $Log: debug.c,v $
// Revision 1.6  2004/08/06 13:48:39  DEBROUX Lionel
// generic commit
//
// Revision 1.5  2002/10/18 16:03:54  tnussb
// see history.txt for v3.98b
//
// Revision 1.4  2002/10/14 12:48:48  tnussb
// using now FastDraw() for string output
//
// Revision 1.3  2002/10/11 13:19:14  tnussb
// display informations of opening books
//
// Revision 1.2  2002/10/10 13:19:30  tnussb
// changes related to new chess puzzle format
//
// Revision 1.1  2002/10/08 17:43:06  tnussb
// initial version
//
//
//
