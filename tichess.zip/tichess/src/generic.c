/******************************************************************************
*
* project name:    TI-Chess
* file name:       generic.c
* initial date:    13/07/2000
* authors:         thomas.nussbaumer@gmx.net (coding)
*                  marcos.lopez@gmx.net      (design/graphics/beta testing)
* description:     generic drawing routines
*
* $Id: generic.c,v 1.10 2004/08/06 13:50:31 DEBROUX Lionel Exp $
*
******************************************************************************/

#include "hardware.h"    // MUST BE ALWAYS HERE ON THE FIRST LINE !!!!

#include <stdlib.h>
#include <string.h>
#include <graph.h>
#include <gray.h>

#include "generic.h"

SCR_RECT fullscreen = {{0, 0, 239, 127}}; // used for fullscreen clipping



/*===========================================================================*/
/* draw a line with given color from (x0,y0) to (x1,y1)                      */
/*===========================================================================*/
void DrawColorLine(short x0,short y0,short x1, short y1, short color) {
    SetPlane(LIGHT_PLANE);
    if (color == COLOR_WHITE || color == COLOR_DARKGRAY) {
        DrawLine(x0, y0, x1, y1, A_REVERSE);
    }
    else {
        DrawLine(x0, y0, x1, y1, A_NORMAL);
    }
    SetPlane(DARK_PLANE);
    if (color == COLOR_WHITE || color == COLOR_LIGHTGRAY) {
        DrawLine(x0, y0, x1, y1, A_REVERSE);
    }
    else {
        DrawLine(x0, y0, x1, y1, A_NORMAL);
    }
}



/*===========================================================================*/
/* draws a rectangle with given color                                        */
/* if fill == 1) the rectangle is filled                                     */
/*===========================================================================*/
void DrawColorRect(short x0,short y0,short x1, short y1, short color,short fill) {
    WIN_RECT wrect;
    SCR_RECT rect;
    void     (__ATTR_TIOS__ * df)(void*,void*,short);
    void*    parea;

    if (fill) {
        rect.xy.x0 = x0;
        rect.xy.y0 = y0;
        rect.xy.x1 = x1;
        rect.xy.y1 = y1;
        parea      = &rect;
        df         = (void __ATTR_TIOS__(*)(void*,void*,short))ScrRectFill;
    }
    else {
        wrect.x0 = x0;
        wrect.y0 = y0;
        wrect.x1 = x1;
        wrect.y1 = y1;
        parea    = &wrect;
        df       = (void __ATTR_TIOS__(*)(void*,void*,short))DrawClipRect;
    }

    SetPlane(LIGHT_PLANE);
    if (color == COLOR_WHITE || color == COLOR_DARKGRAY) {
        (*df)(parea,&fullscreen, A_REVERSE);
    }
    else {
        (*df)(parea,&fullscreen, A_NORMAL);
    }
    SetPlane(DARK_PLANE);
    if (color == COLOR_WHITE || color == COLOR_LIGHTGRAY) {
        (*df)(parea,&fullscreen, A_REVERSE);
    }
    else {
        (*df)(parea,&fullscreen, A_NORMAL);
    }
}



/*===========================================================================*/
/* invert a given area                                                       */
/*===========================================================================*/
void InvertGrayRect(short x0,short y0,short x1, short y1) {
    short p;
    SCR_RECT sr = {{x0,y0,x1,y1}};


    for (p=0;p<2;p++) {
        SetPlane(p);
        ScrRectFill(&sr,&fullscreen,A_XOR);
    }
}



/*===========================================================================*/
/* draws a popup window                                                      */
/*===========================================================================*/
void DrawPopup(short x0,short y0,short x1, short y1) {
    DrawColorRect(x0,y0,x1,y1,COLOR_BLACK,RECT_EMPTY);
    x0++,y0++,x1--,y1--;
    DrawColorRect(x0,y0,x1,y1,COLOR_DARKGRAY,RECT_EMPTY);
    x0++,y0++,x1--,y1--;
    DrawColorRect(x0,y0,x1,y1,COLOR_LIGHTGRAY,RECT_EMPTY);
    x0++,y0++,x1--,y1--;
    DrawColorRect(x0,y0,x1,y1,COLOR_WHITE,RECT_FILLED);
}


extern void FastDraw(register short x asm("%d0"),register short y asm("%d1"),register const unsigned char* s asm("%a0"));


/*===========================================================================*/
/* utility function to draw a string to both planes                          */
/* NOTE: there exists two new styles which are handled as flags              */
/*       A_CENTERED ... the given font will be used and the string will be   */
/*                      drawn centered on the screen                         */
/*       A_SHADOWED ... if this flag is set in the attributes a lightgray    */
/*                      shadow will be drawn with +1 pixel offset in all     */
/*                      two directions                                       */
/*===========================================================================*/
void DrawString(short x,short y,const char* s,short font,short attr) {
    short do_shadow = attr & A_SHADOWED;

    FontSetSys(font);

    if (attr & A_CENTERED) {
        x = (STATIC_LCD_WIDTH-DrawStrWidth(s,font))/2;
        attr &= ~A_CENTERED;
    }

    attr &= ~A_SHADOWED;

    if ((font == F_4x6) && ((attr == A_NORMAL)||(attr == A_REPLACE))) {
        FastDraw(x,y,s);
    }
    else {
        SetPlane(DARK_PLANE);
        DrawStr(x,y,s,attr);
        SetPlane(LIGHT_PLANE);
        DrawStr(x,y,s,attr);
    }

    if (do_shadow) {
        SetPlane(LIGHT_PLANE);
        DrawStr(x+1,y+1,s,A_NORMAL);
    }
}



extern unsigned char* __F_4x6_Font__;
extern unsigned char* __F_6x8_Font__;

//=============================================================================
// setup fast font 4x6 drawing functions
// Thanx to Lionel Debroux for the new implementation which takes up no
// additionally memory
//=============================================================================
extern short InitFastDraw(void);
asm (".xdef __F_4x6_Font__\n"\
".even\n"\
"__F_4x6_Font__:\n"\
".long 0\n"\
".xdef __F_6x8_Font__\n"\
".even\n"\
"__F_6x8_Font__:\n"\
".long 0\n"\
".xdef InitFastDraw\n"\
"InitFastDraw:\n"\
"    movem.l %d3/%a2,-(%sp)\n"\
"    movea.l 0xC8.w,%a2\n"\
"    cmpi.w #1000,-2(%a2)\n"\
"    bgt.s __Prepare_fonts_AMS_2xx__\n"\
"__Prepare_fonts_AMS_1xx__:\n"\
"    movea.l 0x1A9*4(%a2),%a0\n"\
"    cmpi.l #0x50656472,-(%a0) | 'Pedr', a signature of PedroM.\n"\
"    bne.s __The_ROM_we_re_running_on_is_not_PedroM__\n"\
"    lea __F_6x8_Font__(%pc),%a1\n"\
"    subq.l #4,%a0\n"\
"    move.l -(%a0),(%a1)\n"\
"    move.l -(%a0),-(%a1)\n"\
"    bra.s __Prepare_fonts_end__\n"\
"__The_ROM_we_re_running_on_is_not_PedroM__:\n"\
"    lea 58+4(%a0),%a0 | Get rid of the cmpi.l #0x50656472,-(%a0) above.\n"\
"    movea.w (%a0),%a1\n"\
"    adda.l %a0,%a1\n"\
"    lea __F_4x6_Font__(%pc),%a0\n"\
"    move.l 122(%a1),(%a0)+\n"\
"    move.l 106(%a1),(%a0)\n"\
"    bra.s __Prepare_fonts_end__\n"\
"__Prepare_fonts_AMS_2xx__:\n"\
"    movea.l 0x45D*4(%a2),%a0 | EV_runningApp\n"\
"    move.w (%a0),%d3\n"\
"    beq.s __Prepare_fonts_GetAttr__\n"\
"    movea.l 0x441*4(%a2),%a0  | HeapTable\n"\
"    lsl.w #2,%d3\n"\
"    movea.l 0(%a0,%d3.w),%a0\n"\
"    movea.l 20(%a0),%a0\n"\
"    bra.s _Prepare_fonts_GetAttr__\n"\
"__Prepare_fonts_GetAttr__:\n"\
"    lea 0xFF000000.l,%a0\n"\
"_Prepare_fonts_GetAttr__:\n"\
"    movea.l 0x3FA*4(%a2),%a2 | OO_CondGetAttr\n"\
"    pea __F_4x6_Font__(%pc)\n"\
"    pea 0x300.w\n"\
"    pea (%a0)\n"\
"    jsr (%a2)\n"\
"    tst.w %d0\n"\
"    beq.s __Prepare_fonts_problem__\n"\
"    addq.l #4,8(%sp)\n"\
"    addq.w #1,6(%sp)\n"\
"    jsr (%a2)\n"\
"    tst.w %d0\n"\
"    beq.s __Prepare_fonts_problem__\n"\
"    lea 12(%sp),%sp\n"\
"__Prepare_fonts_end__:\n"\
"    moveq #1,%d0\n"\
"_Prepare_fonts_end__:\n"\
"    movem.l (%sp)+,%d3/%a2\n"\
"    rts\n"\
"__Prepare_fonts_problem__:\n"\
"    moveq #0,%d0\n"\
"    bra.s _Prepare_fonts_end__");


//=============================================================================
// returns width of given string
//=============================================================================
short FastStringWidth(const unsigned char* s) {
    short width = 0;
    while (*s) width += *(unsigned char*)&(__F_4x6_Font__[(short)(*s++)*6]);;
    return width;
}


//=============================================================================
// draws string using own sprites (more than 5 times faster than DrawStrXY)
//=============================================================================
asm("
.data
    .global FastDraw
FastDraw:
    movem.l  %d3/%a2-%a6,-(%sp)

    add.w    %d1,%d1
    move.w   %d1,%d2
    lsl.w    #4,%d2
    sub.w    %d1,%d2
| Hack, this is the only way to get the grayplanes in pure ASM.
| Remove (%pc) if the grayscale routines are too far...
    move.l   __L_plane(%pc),%a1
    move.l   __D_plane(%pc),%a5
    adda.w   %d2,%a1
    adda.w   %d2,%a5

    move.l   __F_4x6_Font__(%pc),%a2
    
_beginning_of_loop_FD_:
    moveq    #0,%d2
    move.b   (%a0)+,%d2
    jbeq     _finished_FD_

    add.w    %d2,%d2
    move.w   %d2,%d1
    add.w    %d2,%d2
    add.w    %d1,%d2
    lea      1(%a2,%d2.w),%a4

    move.w   %d0,%d1
    lsr.w    #4,%d1
    add.w    %d1,%d1
    lea      0(%a1,%d1.w),%a3
    lea      0(%a5,%d1.w),%a6
    
_draw_sprite_FD_:
    move.w   %d0,%d1
    andi.w   #0xF,%d1
    
    moveq    #24,%d2
    sub.w    %d1,%d2
    moveq    #5-1,%d1

_loop_one_long_FD_:
    moveq    #0,%d3
    move.b   (%a4)+,%d3
    lsl.l    %d2,%d3
    or.l     %d3,(%a3)
    or.l     %d3,(%a6)
    lea      30(%a3),%a3
    lea      30(%a6),%a6

    dbf      %d1,_loop_one_long_FD_

_next_letter_FD_:
    moveq    #0,%d1
    move.b   -6(%a4),%d1
    add.w    %d1,%d0
    jbra     _beginning_of_loop_FD_
    
_finished_FD_:
    movem.l  (%sp)+,%d3/%a2-%a6
    rts
");

/*
void FastDraw(short x,short y,const unsigned char* s) {
    unsigned char* sprite;
    long           addr1;
    long           addr2;
    unsigned short cnt;
    short          ytemp;
    short          i;

    while (*s) {
        sprite = &(__F_4x6_Font__[(short)(*s)*6])+1;
        ytemp  = (y<<5)-(y<<1)+((x>>3)&0x1e);

        addr1 = ((long)GetPlane(DARK_PLANE))+ytemp;
        addr2 = ((long)GetPlane(LIGHT_PLANE))+ytemp;
        cnt  = 24-(x&15);

        // unrolled loop for more speed ....
        *(long*)addr1|=(long)(*sprite)<<cnt;
        *(long*)addr2|=(long)(*sprite++)<<cnt;
        addr1+=30;addr2+=30;
        *(long*)addr1|=(long)(*sprite)<<cnt;
        *(long*)addr2|=(long)(*sprite++)<<cnt;
        addr1+=30;addr2+=30;
        *(long*)addr1|=(long)(*sprite)<<cnt;
        *(long*)addr2|=(long)(*sprite++)<<cnt;
        addr1+=30;addr2+=30;
        *(long*)addr1|=(long)(*sprite)<<cnt;
        *(long*)addr2|=(long)(*sprite++)<<cnt;
        addr1+=30;addr2+=30;
        *(long*)addr1|=(long)(*sprite)<<cnt;
        *(long*)addr2|=(long)(*sprite)<<cnt;

        x+=*(sprite - 5);
        s++;
    }
}
*/

//=============================================================================
// draws string using own sprites (about 4 times faster than DrawStrXY)
// CENTERED version
//=============================================================================
void FastDrawCentered(short y,const unsigned char* s) {
    FastDraw((C89_92(160,240)-FastStringWidth(s))>>1,y,s);
}


//#############################################################################
//###################### NO MORE FAKES BEYOND THIS LINE #######################
//#############################################################################
//
//=============================================================================
// Revision History
//=============================================================================
//
// $Log: generic.c,v $
// Revision 1.10  2004/08/06 13:50:31  DEBROUX Lionel
// (1) new __regparm__ fonts support
// (2) made DrawColorRect safer
//
// Revision 1.9  2002/11/11 11:08:19  nussbaumer
// minor improvement in character sprites retrievement
//
// Revision 1.8  2002/10/17 11:30:56  tnussb
// changes due to new font graphics data retrieving by Lionel Debroux
// (the sprite data is fetched from the AMS)
//
// Revision 1.7  2002/10/16 18:28:51  tnussb
// changes related to the complete new puzzle file support (see history.txt)
//
// Revision 1.6  2002/10/14 12:48:27  tnussb
// FastDraw() added
//
// Revision 1.5  2002/02/11 16:38:11  tnussb
// many changes due to "separate file compiling" restructuring
//
// Revision 1.4  2001/02/17 15:00:11  Thomas Nussbaumer
// changes due to new TIGCC version
//
// Revision 1.3  2000/12/19 13:55:29  Thomas Nussbaumer
// warnings stated by compiling with option -Wall fixed
//
// Revision 1.2  2000/08/12 15:31:12  Thomas Nussbaumer
// substitution keywords added
//
//
