/******************************************************************************
*
* project name:    TI-Chess
* file name:       opening.c
* initial date:    03/08/2002
* author:          thomas.nussbaumer@gmx.net
* description:     contains the opening book engine
*
******************************************************************************/

#include "hardware.h"    // MUST BE ALWAYS HERE ON THE FIRST LINE !!!!
#include <stdio.h>
#include <stdlib.h>
#include <vat.h>
#include <graph.h>
#include <gray.h>

#include "defines.h"

/*---------------------------------------------------------------------------*/
/* Needs to know what has been played until now                              */
/*---------------------------------------------------------------------------*/

extern short           act_color;
extern hash_t          act_hashkey;
extern char*           board;
extern unsigned short  move_count;
extern short*          ep_field;
extern unsigned short  flags[];

//-----------------------------------------------------------------------------
// TI-Chess uses up to 10 files for openings: ticbook0 ... ticbook9
//-----------------------------------------------------------------------------


openingbook_t  books[2][MAX_BOOKS_USED];
ticfile_t      bookfiles[2][MAX_BOOKS_USED];
short          nr_books[2];


/*===========================================================================*/
/*  initialize books                                                         */
/*===========================================================================*/
void InitBooks(void) {
    short          i,j;
    unsigned char* src;
    unsigned long  magic;

    randomize(); // set random number generator to a random seed

    for (j=0;j<2;j++) {
        if (!j) magic = MAGIC_BOOK_WHITE;
        else    magic = MAGIC_BOOK_BLACK;

        nr_books[j] = FindAndOpenTICFiles(bookfiles[j],MAX_BOOKS_USED,magic);

        for (i=0;i<nr_books[j];i++) {
            src = bookfiles[j][i].start+6;
            books[j][i].nr_pos = *(unsigned short*)src;
            src += 2;
            books[j][i].nr_moves = *(unsigned short*)src;
            src += 2;
            books[j][i].first_hashcode = *(hash_t*)src;
            src += (books[j][i].nr_pos-1)*10;
            books[j][i].last_hashcode = *(hash_t*)src;
        }
    }
}


/*===========================================================================*/
/* cleanup books                                                             */
/*===========================================================================*/
void CleanupBooks() {
    short i,j;

    for (j=0;j<2;j++) {
        for (i=0;i<nr_books[j];i++) {
            CloseTICFile(&(bookfiles[j][i]));
        }
    }
}


char opening_move[6];
char opening_desc[20];


/*===========================================================================*/
/*  returns the BOOK (%d/%d) string if there is any                          */
/*===========================================================================*/
char* GetOpeningDesc(void) {
    if (opening_desc[0] == 0) return 0;
    return opening_desc;
}


#define CORRECT_POSITION() ({ bitpos>>=1;     \
                             if (!bitpos) {   \
                                 bitpos=0x80; \
                                 input++;     \
                             }})



//=============================================================================
// decompresses a huffman encoded chess position
//
// input is a 21-byte long buffer holding a compressed chess position
// output is a 64-byte buffer for decompressed chess position
//=============================================================================
short CheckPositionInDetail(unsigned char* input) {
    short i;
    unsigned char  bitpos = 0x80;
    unsigned char* orig   = input;
    short          ef     = ILLEGAL;
    char           fig;
    //char           tmpstr[100];

    for (i=0;i<BOARD_SIZE;i++) {
        if (board[i] == OUTSIDE) continue;

        if (!(*input & bitpos)) {
            fig = EMPTY;
            goto correct_and_continue;
        }

        CORRECT_POSITION();

        if (!(*input & bitpos)) {
            CORRECT_POSITION();
            if (!(*input & bitpos)) fig = W_PAWN;
            else                    fig = B_PAWN;
            goto correct_and_continue;
        }

        CORRECT_POSITION();

        if (!(*input & bitpos)) {
            CORRECT_POSITION();
            if (!(*input & bitpos)) {
                 CORRECT_POSITION();
                 if (!(*input & bitpos)) fig = W_BISHOP;
                 else                    fig = B_BISHOP;
                 goto correct_and_continue;
            }
            CORRECT_POSITION();
            if (!(*input & bitpos)) fig = W_KNIGHT;
            else                    fig = B_KNIGHT;
            goto correct_and_continue;
        }

        CORRECT_POSITION();

        if (!(*input & bitpos)) {
            CORRECT_POSITION();
            if (!(*input & bitpos)) fig = W_ROOK;
            else                    fig = B_ROOK;
            goto correct_and_continue;
        }

        CORRECT_POSITION();

        if (!(*input & bitpos)) {
            CORRECT_POSITION();
            if (!(*input & bitpos)) fig = W_QUEEN;
            else                    fig = B_QUEEN;
            goto correct_and_continue;
        }

        CORRECT_POSITION();

        if (!(*input & bitpos)) fig = W_KING;
        else                    fig = B_KING;

    correct_and_continue:
        if (board[i] != fig) {
            //-----------------------------------------------------------------
            // if this occurs than there is more than 1 position matching the
            // same hashcode. Just skip ...
            //-----------------------------------------------------------------
            //sprintf(tmpstr,"MISSMATCH: %d (%d != %d)",i,fig,board[i]);
            //ForceRequestDialog(tmpstr);
            return 0;
        }
        CORRECT_POSITION();
    }

    if ((orig[21] & 0x1) && act_color == WHITE) {
        //---------------------------------------------------------------------
        // This SHOULDN'T happen, BECAUSE for positions for white are stored
        // in a separate WHITE opening book and positions for black are stored
        // in a separate BLACK opening book. This check is ONLY for possible
        // future changes here ...
        //---------------------------------------------------------------------
        //ForceRequestDialog("COLOR MISSMATCH");
        return 0;
    }

    if (!move_count) return 1;

    if (orig[20] & 0x08) {
        ef = orig[20] & 0x7;
        if (act_color == BLACK) ef += 20 + 21;
        else                    ef += 50 + 21;
    }

    if (ef != ep_field[1]) {
        //---------------------------------------------------------------------
        // epfield missmatches CAN OCCUR by move rearrangements
        // simply skip this position ...
        //---------------------------------------------------------------------
        //sprintf(tmpstr,"EP MISSMATCH: %d != %d",ef,ep_field[1]);
        //ForceRequestDialog(tmpstr);
        return 0;
    }

    if (orig[21] & 0x2) {   // white long castling
        if (flags[1] & (A1_MOVE_MASK | E1_MOVE_MASK | W_ROCHADE_MASK)) {
            //---------------------------------------------------------------------
            // castling missmatches CAN OCCUR by move rearrangements
            // simply skip this position ...
            //---------------------------------------------------------------------
            //ForceRequestDialog("WHITE LONG MISSMATCH");
            return 0;
        }
    }

    if (orig[21] & 0x4) {   // white short castling
        if (flags[1] & (H1_MOVE_MASK | E1_MOVE_MASK | W_ROCHADE_MASK)) {
            //---------------------------------------------------------------------
            // castling missmatches CAN OCCUR by move rearrangements
            // simply skip this position ...
            //---------------------------------------------------------------------
            //ForceRequestDialog("WHITE SHORT MISSMATCH");
            return 0;
        }
    }
    if (orig[21] & 0x8) {   // black long castling
        if (flags[1] & (A8_MOVE_MASK | E8_MOVE_MASK | B_ROCHADE_MASK)) {
            //---------------------------------------------------------------------
            // castling missmatches CAN OCCUR by move rearrangements
            // simply skip this position ...
            //---------------------------------------------------------------------
            //ForceRequestDialog("BLACK SHORT MISSMATCH");
            return 0;
        }
    }
    if (orig[21] & 0x10) {   // black short castling
        if (flags[1] & (H8_MOVE_MASK | E8_MOVE_MASK | B_ROCHADE_MASK)) {
            //---------------------------------------------------------------------
            // castling missmatches CAN OCCUR by move rearrangements
            // simply skip this position ...
            //---------------------------------------------------------------------
            //ForceRequestDialog("BLACK SHORT MISSMATCH");
            return 0;
        }
    }

    return 1;
}


#define MAX_VALID_MOVES 100  // not more than 200 continuation moves per position


//=============================================================================
// fetches all possible continuation moves from the installed books
//=============================================================================
static short GetMoveList(short* moves) {
    short          nr_book;
    unsigned short loop;
    short          nr_moves = 0;
    short          booktype;

    if (act_color == WHITE) booktype = WHITEBOOK;
    else                    booktype = BLACKBOOK;

    for (nr_book=0;nr_book<nr_books[booktype];nr_book++) {
        if (act_hashkey >= books[booktype][nr_book].first_hashcode &&
            act_hashkey <= books[booktype][nr_book].last_hashcode)
        {
            unsigned char* src = bookfiles[booktype][nr_book].start + 10;
            for (loop=0;loop<books[booktype][nr_book].nr_pos;loop++,src+=10) {
                if (*(hash_t*)src == act_hashkey) {
                    unsigned char* pos = bookfiles[booktype][nr_book].start+2+*(unsigned short*)(src+8);
                    if (CheckPositionInDetail(pos)) {
                        pos+=22;
                        do {
                            moves[nr_moves] = *(unsigned short*)pos;
                            pos+=2;
                            nr_moves++;
                        }
                        while (nr_moves < MAX_VALID_MOVES && (moves[nr_moves-1] & 0x8000));
                        if (nr_moves == MAX_VALID_MOVES) goto max_moves_reached;
                    }
                }
            }
        }
    }

max_moves_reached:
    return nr_moves;
}



//=============================================================================
// get opening ... if an opening is found a valid "user" move string is
// returned, otherwise NULL
//=============================================================================
char* GetOpening(void) {
    unsigned short moves[MAX_VALID_MOVES];
    short          nr_moves;
    short          selected;

    if (!(nr_moves=GetMoveList(moves))) {
        opening_desc[0] = 0;
        return 0;
    }

    selected = random(nr_moves);
    CompressedMove2String(moves[selected],opening_move);
    sprintf(opening_desc,INFOBOARD_BOOK,selected+1,nr_moves);
    return opening_move;
}


//=============================================================================
// popups a dialog to the right which shows all available continuation moves
// from the installed books
//=============================================================================
#define OPENINGMOVE_WINDOW_X      C89_92(102,152)
#define OPENINGMOVE_WINDOW_Y      C89_92(10,18)
#define OPENINGMOVE_WINDOW_X_END  C89_92(159,209)
#define OPENINGMOVE_WINDOW_Y_END  C89_92(89,97)

void ShowContinuationList(void) {
    LCD_BUFFER LCD_tmp1;
    LCD_BUFFER LCD_tmp2;
    unsigned short moves[MAX_VALID_MOVES];
    short          nr_moves = GetMoveList(moves);
    short          i;
    char           move_string[6];
    char           tmpbuf[100];
    short          start_idx = 0;
    short          end_idx;

    memcpy(LCD_tmp1,GetPlane(LIGHT_PLANE),LCD_SIZE);
    memcpy(LCD_tmp2,GetPlane(DARK_PLANE), LCD_SIZE);

    do {
        DrawPopup(OPENINGMOVE_WINDOW_X,OPENINGMOVE_WINDOW_Y,
                  OPENINGMOVE_WINDOW_X_END,OPENINGMOVE_WINDOW_Y_END);

        end_idx = start_idx + 10;
        if (end_idx > nr_moves) end_idx = nr_moves;

        if (!nr_moves) {
            FastDraw(OPENINGMOVE_WINDOW_X+3,OPENINGMOVE_WINDOW_Y+4,"-----");
        }
        else {
            sprintf(tmpbuf,"%d-%d / %d",start_idx+1,end_idx,nr_moves);
            FastDraw(OPENINGMOVE_WINDOW_X+3,OPENINGMOVE_WINDOW_Y+4,tmpbuf);
        }
        for (i=start_idx;i<end_idx;i++) {
            CompressedMove2String(moves[i],move_string);
            sprintf(tmpbuf,"(%d) %s",i+1,move_string);
            FastDraw(OPENINGMOVE_WINDOW_X+3,OPENINGMOVE_WINDOW_Y+16+(i-start_idx)*6,tmpbuf);
        }
        start_idx = end_idx;
        if (start_idx == nr_moves) start_idx = 0;
    }
    while (GetUserInput(1) == KEY_OPENINGMOVES);

    memcpy(GetPlane(LIGHT_PLANE),LCD_tmp1,LCD_SIZE);
    memcpy(GetPlane(DARK_PLANE), LCD_tmp2,LCD_SIZE);
}



//#############################################################################
//###################### NO MORE FAKES BEYOND THIS LINE #######################
//#############################################################################
//
//=============================================================================
// Revision History
//=============================================================================
//
// $Log: opening.c,v $
// Revision 1.10  2004/08/06 13:58:27  DEBROUX Lionel
// generic commit
//
// Revision 1.9  2002/10/21 12:19:48  tnussb
// see changes for v3.99b in history.txt
//
// Revision 1.8  2002/10/18 16:03:54  tnussb
// see history.txt for v3.98b
//
// Revision 1.7  2002/10/16 18:28:52  tnussb
// changes related to the complete new puzzle file support (see history.txt)
//
// Revision 1.6  2002/10/14 12:50:54  tnussb
// function ShowContinuationList() added
//
// Revision 1.5  2002/10/11 13:21:42  tnussb
// (1) opening book popup during startup removed.
// (2) GetBookInfo() added which is used by debug screen to display infos
//     about the books
// (3) changes related to the number of moves storing in the header of the
//     opening book
// (4) no opening book warning popups anymore for ep missmatch and castling
//     missmatch which can occur due to move arrangements
//
// Revision 1.4  2002/10/08 17:44:30  tnussb
// changes related to v3.90/v3.91
//
// Revision 1.3  2002/09/13 16:18:03  tnussb
// pops up "installed opening books" dialog when at least one book is found
//
// Revision 1.2  2002/09/13 15:25:03  tnussb
// changes for v3.81 BETA (external opening book support)
//
// Revision 1.1  2002/09/13 10:19:15  tnussb
// initial version
//
//
