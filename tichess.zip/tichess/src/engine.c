/******************************************************************************
*
* project name:    TI-Chess
* file name:       engine.c
* initial date:    24/02/2000
* authors:         thomas.nussbaumer@gmx.net (coding)
*                  marcos.lopez@gmx.net      (design/graphics/beta testing)
* description:     contains the chess playing engine's stuff
*
*
* [based on ideas and code of minimax engine from Ch.Donninger]
*
* $Id: engine.c,v 1.16 2004/08/06 13:49:34 DEBROUX Lionel Exp $
*
******************************************************************************/

#include "hardware.h"    // MUST BE ALWAYS HERE ON THE FIRST LINE !!!!
#include <string.h>
#include <system.h>
#include <graph.h>
#include <alloc.h>
#include <kbd.h>
#include <math.h>

#include "input.h"
#include "generic.h"
#include "routines.h"


STATIC_FUNC inline short BlackPawnEvaluation(short field,short row, short column,short developed);
STATIC_FUNC inline short WhitePawnEvaluation(short field,short row, short column,short developed);
STATIC_FUNC short   CheckForRepetition(short exact);
STATIC_FUNC void    StoreMove(short i);
//STATIC_FUNC char    Figure2Char(char figure);
STATIC_FUNC short   Notation2Field(char* fieldnotation);
STATIC_FUNC void    InitTree(void);
STATIC_FUNC short   NextBestMove(void);
STATIC_FUNC short   AlphaBetaSearch(short alpha,short beta,short distance);
STATIC_FUNC void    CopyMainVariant(short idx);
STATIC_FUNC void    HandleMoveFlags(short field,unsigned short* flags);
STATIC_FUNC void    HandleKilledFigure(char figure,short field,short increment);
STATIC_FUNC void    HandleFromField(char figure,char promoted,short from,short to,short increment);
STATIC_FUNC void    ExecMove(short idx);
STATIC_FUNC void    UndoMove(short idx);
STATIC_FUNC short   Evaluate(short side);
STATIC_FUNC void    PutMoveOnStack(short from,short to);
STATIC_FUNC void    PutKillMoveOnStack(short from,short to);
STATIC_FUNC void    PutEpOnStack(short from,short to,short epfield);
STATIC_FUNC void    PutPromotionOnStack(short from,short to);
STATIC_FUNC void    GenerateMoves(short allmoves);


extern short       inverted;
extern defaults_t  defaults;



#define WHITE_DEVELOPED(flags) developed_look_up[(flags) & 0x001f]
#define BLACK_DEVELOPED(flags) developed_look_up[((flags) >> 5) & 0x001f]

char developed_look_up[32] = {
  0,1,1,2,1,2,2,3,1,2,2,3,2,3,3,4,
  1,2,2,3,2,3,3,4,2,3,3,4,3,4,4,5
};


unsigned char* reserved_memory = 0;

/*===========================================================================*/
/*===========================================================================*/
/*===========================================================================*/
/*                                                                           */
/* G L O B A L S                                                             */
/*                                                                           */
/*===========================================================================*/
/*===========================================================================*/
/*===========================================================================*/

char           movetext[8]           = {'0'};   // used by Move2Str() routine
short          updatecounter         = 0;       // used to overcome LONG modulo
                                                // operation (size!!)
short          already_mate          = FALSE;
char*          board                 = 0;       // the board
short*         ep_field              = 0;
move_t*        move_stack            = 0;       // generated moves go here
short*         stack_ranges          = 0;       // stores ranges within move_stack
fromto_t**     main_var              = 0;       // table of main variants
killer_t*      killer_tab            = 0;       // table of killer moves
bicolor_t*     p_controlled          = 0;       // fields controlled by pawns
bicolor_t*     p_per_column          = 0;       // number of pawns on a column
bicolor_t*     r_per_column          = 0;       // number of rooks on a column
short*         mobility              = 0;       // mobility of bishop and rook
short*         to_fields             = 0;       // used for sorting and search ext.
short*         material_bal          = 0;       // material balance  white/black
short*         material_sum          = 0;       // material sum
short          act_index             = 0;       // actual index in move_stack
short          white_king_pos        = 0;       // position of white king
short          black_king_pos        = 0;       // position of black king
short          act_color             = 0;       // which turn (white or black)
short          std_depth             = 0;       // standard depth
short          max_extend            = 0;       // max.extention of search tree
short          act_depth             = 0;       // actual search depth
long           nr_nodes              = 0;       // number of evaluated nodes
short          last_move             = 0;       // last executed move
short          chess_indicator       = 0;       // actual side is in chess
unsigned short move_count            = 0;       // number of moves so far
hentry_t*      hashtable_w           = 0;       // hashtable
hentry_t*      hashtable_b           = 0;       // hashtable
hash_t**       hashcodes             = 0;
store_t*       move_store            = 0;
short          moves_stored          = 0;
short          abort_move            = FALSE;

unsigned short flags[MAX_DEPTH]      = {0};

unsigned short flags_0          = 0; // used to restore value before 1.stored move
short          ep_field_0       = 0; // used to restore value before 1.stored move
short          material_sum_0   = 0; // used to restore value before 1.stored move
short          material_bal_0   = 0; // used to restore value before 1.stored move



/*---------------------------------------------------------------------------*/
/* initial board setup                                                       */
/*---------------------------------------------------------------------------*/
const char board_setup[BOARD_SIZE] =  {
OUTSIDE,OUTSIDE,OUTSIDE, OUTSIDE, OUTSIDE,OUTSIDE,OUTSIDE, OUTSIDE, OUTSIDE,OUTSIDE,
OUTSIDE,OUTSIDE,OUTSIDE, OUTSIDE, OUTSIDE,OUTSIDE,OUTSIDE, OUTSIDE, OUTSIDE,OUTSIDE,
OUTSIDE,W_ROOK, W_KNIGHT,W_BISHOP,W_QUEEN,W_KING, W_BISHOP,W_KNIGHT,W_ROOK, OUTSIDE,
OUTSIDE,W_PAWN, W_PAWN,  W_PAWN,  W_PAWN, W_PAWN, W_PAWN,  W_PAWN,  W_PAWN, OUTSIDE,
OUTSIDE,EMPTY,  EMPTY,   EMPTY,   EMPTY,  EMPTY,  EMPTY,   EMPTY,   EMPTY,  OUTSIDE,
OUTSIDE,EMPTY,  EMPTY,   EMPTY,   EMPTY,  EMPTY,  EMPTY,   EMPTY,   EMPTY,  OUTSIDE,
OUTSIDE,EMPTY,  EMPTY,   EMPTY,   EMPTY,  EMPTY,  EMPTY,   EMPTY,   EMPTY,  OUTSIDE,
OUTSIDE,EMPTY,  EMPTY,   EMPTY,   EMPTY,  EMPTY,  EMPTY,   EMPTY,   EMPTY,  OUTSIDE,
OUTSIDE,B_PAWN, B_PAWN,  B_PAWN,  B_PAWN, B_PAWN, B_PAWN,  B_PAWN,  B_PAWN, OUTSIDE,
OUTSIDE,B_ROOK, B_KNIGHT,B_BISHOP,B_QUEEN,B_KING, B_BISHOP,B_KNIGHT,B_ROOK, OUTSIDE,
OUTSIDE,OUTSIDE,OUTSIDE, OUTSIDE, OUTSIDE,OUTSIDE,OUTSIDE, OUTSIDE, OUTSIDE,OUTSIDE,
OUTSIDE,OUTSIDE,OUTSIDE, OUTSIDE, OUTSIDE,OUTSIDE,OUTSIDE, OUTSIDE, OUTSIDE,OUTSIDE};



/*---------------------------------------------------------------------------*/
/* move generator tables                                                     */
/*---------------------------------------------------------------------------*/
const char offset_vals[NR_DIRS] = {
   -9,-11,9,11,                    /* bishop directions  */
   -1,10,1,-10,                    /* rook               */
   19,21,12,-8,-19,-21,-12,8};     /* knight             */

const figoffset_t figure_offsets[NR_FIGS] = {
   {0,0,FALSE},   /* empty field                         */
   {-1,-1,FALSE}, /* pawn moves are generated separately */
   {4,7,TRUE},    /* rook                                */
   {0,3,TRUE},    /* bishop                              */
   {8,15,FALSE},  /* knight                              */
   {0,7,TRUE},    /* queen                               */
   {0,7,FALSE}};  /* king                                */



/*---------------------------------------------------------------------------*/
/* table used for king position evaluation and mobility of rook/bishop       */
/*---------------------------------------------------------------------------*/
const char center_table[H8+1] = {
   0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
   0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
   0,  4,  0,  8, 12, 12,  8,  0,  4,  0,
   0,  4,  8, 12, 16, 16, 12,  8,  4,  0,
   0,  8, 12, 16, 20, 20, 16, 12,  8,  0,
   0, 12, 16, 20, 24, 24, 20, 16, 12,  0,
   0, 12, 16, 20, 24, 24, 20, 16, 12,  0,
   0,  8, 12, 16, 20, 20, 16, 12,  8,  0,
   0,  4,  8, 12, 16, 16, 12,  8,  4,  0,
   0,  4,  0,  8, 12, 12,  8,  0,  4};



/*---------------------------------------------------------------------------*/
/* field values for white pawns                                              */
/*---------------------------------------------------------------------------*/
const char wp_fieldvalues[H7+1]= {
   0,  0,  0,  0,  0,  0,  0,  0,  0, 0,
   0,  0,  0,  0,  0,  0,  0,  0,  0, 0,
   0,  0,  0,  0,  0,  0,  0,  0,  0, 0,
   0,  4,  4,  0,  0,  0,  6,  6,  6, 0,
   0,  6,  6,  8,  8,  8,  4,  6,  6, 0,
   0,  8,  8, 16, 22, 22,  4,  4,  4, 0,
   0, 10, 10, 20, 26, 26, 10, 10, 10, 0,
   0, 12, 12, 22, 28, 28, 14, 14, 14, 0,
   0, 18, 18, 28, 32, 32, 20, 20, 20};



/*---------------------------------------------------------------------------*/
/* field values for black pawns                                              */
/*---------------------------------------------------------------------------*/
const char bp_fieldvalues[H7+1]= {
   0,  0,  0,  0,  0,  0,  0,  0,  0, 0,
   0,  0,  0,  0,  0,  0,  0,  0,  0, 0,
   0,  0,  0,  0,  0,  0,  0,  0,  0, 0,
   0, 18, 18, 28, 32, 32, 20, 20, 20, 0,
   0, 12, 12, 22, 28, 28, 14, 14, 14, 0,
   0, 10, 10, 20, 26, 26, 10, 10, 10, 0,
   0,  8,  8, 16, 22, 22,  4,  4,  4, 0,
   0,  6,  6,  8,  8,  8,  4,  6,  6, 0,
   0,  4,  4,  0,  0,  0,  6,  6,  6};



/*---------------------------------------------------------------------------*/
/* figure values                                                             */
/*---------------------------------------------------------------------------*/
const short fig_values[NR_FIGS]= {0, VALUE_PAWN,   VALUE_ROOK,  VALUE_BISHOP,
                                     VALUE_KNIGHT, VALUE_QUEEN, VALUE_KING};



/*---------------------------------------------------------------------------*/
/* figure symbols                                                            */
/*---------------------------------------------------------------------------*/
const char fig_symbols[NR_FIGS*2-1] = { FIGURE_SYMBOLS };


//-----------------------------------------------------------------------------
// declarations of the necessary "external" routines and variables
//-----------------------------------------------------------------------------
extern hash_t act_hashkey;
extern char   default_hashmode;
extern short  twoplayer_mode;


short  moves_forward    = 0;  // how much moves can be played forward
hash_t initial_position = 0;  // used to detect move repetition at the start


#include "hash.c"


/*===========================================================================*/
/* checks the move_store for repetitions or 50 plys without a pawn move or   */
/* killed figure                                                             */
/*                                                                           */
/* if exact == FALSE:                                                        */
/*                                                                           */
/* simple checks move_store if actual hash_key is there                      */
/* this would be treaten as draw by the AlphaBetaSearch                      */
/*                                                                           */
/* if exact == TRUE:                                                         */
/* checks for a minimum of 3 repetitions                                     */
/*===========================================================================*/
#define NO_REPETITION     0
#define REPETITION_FOUND  1
#define PLY50_FOUND       2

STATIC_FUNC short CheckForRepetition(short exact) {
    short count = 0;
    short i;

    // first check for 50-ply rule (there have to be at least 1 move be stored)
    if (moves_stored > 0) {
        if ((move_store[moves_stored-1].count & 0x7f) >= 100) return PLY50_FOUND;
    }

    // loop through all stored moves to find the repetitions
    for (i=moves_stored-1;i>0;i--) {
        if (move_store[i-1].key == act_hashkey) {
            if (act_color == WHITE) {
                if (move_store[i-1].count & 0x80) continue; // not a white position -> skip
            }
            else {
                if (!(move_store[i-1].count & 0x80)) continue; // not a black position -> skip
            }

            if (!exact) return REPETITION_FOUND;
            count++;
            if (count == 3) return REPETITION_FOUND;
        }
    }

    // include the initial position in the check !!!
    if (initial_position == act_hashkey && act_color == WHITE) {
        if (count == 2) return REPETITION_FOUND;
    }

    return NO_REPETITION;
}



/*===========================================================================*/
/* stores move in move store and handles move store overflow                 */
/*===========================================================================*/
STATIC_FUNC void StoreMove(short i) {
    // if we haven't enough space (copy move_store upwards)
    if (moves_stored == MAX_MOVES_STORED) {
        flags_0         = move_store[MAX_MOVES_REMOVED-1].flags;
        ep_field_0      = move_store[MAX_MOVES_REMOVED-1].epfield;
        material_sum_0  = move_store[MAX_MOVES_REMOVED-1].sum;
        material_bal_0  = move_store[MAX_MOVES_REMOVED-1].bal;
        memmove(&move_store[0],&move_store[MAX_MOVES_REMOVED],
                sizeof(store_t)*(MAX_MOVES_STORED-MAX_MOVES_REMOVED));
        moves_stored -= MAX_MOVES_REMOVED;
    }
    memcpy(&move_store[moves_stored],&move_stack[i],sizeof(move_t));
    move_store[moves_stored].flags   = flags[0];
    move_store[moves_stored].figure  = abs(board[(unsigned char)(move_store[moves_stored].to)]);
#if 0
    move_store[moves_stored].epfield = ep_field[0];
    move_store[moves_stored].sum     = material_sum[0];
    move_store[moves_stored].bal     = material_bal[0];
#else
    // BUGFIX FOR TAKEBACK/REPLAY !!
    move_store[moves_stored].epfield = ep_field[1];
    move_store[moves_stored].sum     = material_sum[1];
    move_store[moves_stored].bal     = material_bal[1];
#endif
    move_store[moves_stored].key     = act_hashkey;

    //-------------------------------------------------------------------------
    // handle counting for 50-ply rule ...
    //-------------------------------------------------------------------------
    if (move_store[moves_stored].killed_fig != 0 ||
        move_store[moves_stored].figure == W_PAWN ||
        moves_stored < 2)
    {
       move_store[moves_stored].count = 0;
    }
    else {
       unsigned char c = move_store[moves_stored-1].count & 0x7f;
       if (c < 127) c++;
       move_store[moves_stored].count = c;
    }

    //-------------------------------------------------------------------------
    // set color bit for repetition detection -> white bit 7 cleared
    //-------------------------------------------------------------------------
    if (act_color == WHITE) move_store[moves_stored].count &= 0x7f;
    else                    move_store[moves_stored].count |= 0x80;

    moves_stored++;
    moves_forward = 0;
}



/*===========================================================================*/
/* takes back an already played move                                         */
/*===========================================================================*/
void TakeBackMove(short silent) {
    if (moves_stored > 0) {
        moves_stored--;
        memcpy(&move_stack[0],&move_store[moves_stored],sizeof(move_t));
        UndoMove(0);
        act_depth=0;

        //---------------------------------------------------------------------
        // fix to restored the correct values if we take back the first stored
        // move
        //
        // the values before the first stored move are stored in XXX_0
        // variables
        //---------------------------------------------------------------------
        if (moves_stored > 0) {
            flags[0]        = flags[1]        = move_store[moves_stored-1].flags;
            ep_field[0]     = ep_field[1]     = move_store[moves_stored-1].epfield;
            material_sum[0] = material_sum[1] = move_store[moves_stored-1].sum;
            material_bal[0] = material_bal[1] = move_store[moves_stored-1].bal;
        }
        else {
            flags[0]        = flags_0;
            ep_field[0]     = ep_field_0;
            material_sum[0] = material_sum_0;
            material_bal[0] = material_bal_0;
        }

        ResetHashCounters();
        moves_forward++;

        if (!silent) {
            ClearActiveInfoBoardData();
            CorrectInfoBoard();
            ToggleClocks(0,inverted);
        }
    }
}



/*===========================================================================*/
/* undos a previously "TAKE BACK"                                            */
/*===========================================================================*/
void UndoTakeBackMove(short silent) {
    if (moves_forward > 0) {
        memcpy(&move_stack[0],&move_store[moves_stored],sizeof(move_t));
        InitTree();
        ExecMove(0);
        // BUGFIX for takeback and forward problem
        //act_depth=0;
        flags[0] = flags[1];
        ep_field[0] = ep_field[1]; // ep_fix!!
        moves_forward--;
        moves_stored++;
        if (!silent) {
            ClearActiveInfoBoardData();
            CorrectInfoBoard();
            ToggleClocks(0,inverted);
        }
    }
}


void FreeReservedMemory(void) {
    if (reserved_memory) {
        free(reserved_memory);
        reserved_memory = 0;
    }
}

/*===========================================================================*/
/* allocates memory (returns true if everything is allocated)                */
/*===========================================================================*/
// TODO: optimize this !
short InitMemory(void) {
    short i;

    if (!(reserved_memory = malloc(SIZE_OF_RESERVED_MEMORY)))            return FALSE;
    if (!(board       = (char*)malloc(sizeof(char)*BOARD_SIZE)))         return FALSE;
    if (!(ep_field    = (short*)malloc(sizeof(short)*MAX_DEPTH)))        return FALSE;
    if (!(move_stack  = (move_t*)malloc(sizeof(move_t)*(STACK_SIZE+1)))) return FALSE;
    if (!(stack_ranges  = (short*)malloc(sizeof(short)*MAX_DEPTH)))      return FALSE;
    if (!(killer_tab    = (killer_t*)malloc(sizeof(killer_t)*MAX_DEPTH)))      return FALSE;
    if (!(p_controlled  = (bicolor_t*)malloc(sizeof(bicolor_t)*BOARD_SIZE)))   return FALSE;
    if (!(p_per_column  = (bicolor_t*)malloc(sizeof(bicolor_t)*(H_COLUMN+2)))) return FALSE;
    if (!(r_per_column  = (bicolor_t*)malloc(sizeof(bicolor_t)*(H_COLUMN+2)))) return FALSE;
    if (!(move_store    = (store_t*)malloc(sizeof(store_t)*MAX_MOVES_STORED))) return FALSE;
    if (!(mobility      = (short*)malloc(sizeof(short)*MAX_DEPTH)))  return FALSE;
    if (!(to_fields     = (short*)malloc(sizeof(short)*MAX_DEPTH)))  return FALSE;
    if (!(material_bal  = (short*)malloc(sizeof(short)*MAX_DEPTH)))  return FALSE;
    if (!(material_sum  = (short*)malloc(sizeof(short)*MAX_DEPTH)))  return FALSE;

    //-----------------------------------------
    // allocate 1st dimension of main_var array
    //-----------------------------------------
    if (!(main_var = (fromto_t**)malloc(sizeof(fromto_t*)*MAX_DEPTH))) return FALSE;

    //--------------------------------------------------------------
    // now allocate space for 2nd dimension of main_var in one piece
    // and split it afterwards into the single pointers
    //--------------------------------------------------------------
    if (!(main_var[0] = (fromto_t*)malloc(sizeof(fromto_t)*MAX_DEPTH*MAX_DEPTH))) return FALSE;
    for (i=1;i<MAX_DEPTH;i++) main_var[i] = main_var[0] + i*MAX_DEPTH;

    //------------------------------------------
    // allocate 1st dimension of hashcodes array
    //------------------------------------------
    if (!(hashcodes = (hash_t**)malloc(sizeof(hash_t*)*12))) return FALSE;

    //---------------------------------------------------------------
    // now allocate space for 2nd dimension of hashcodes in one piece
    // and split it afterwards into the single pointers
    //---------------------------------------------------------------
    if (!(hashcodes[0] = (hash_t*)malloc(sizeof(hash_t)*64*12))) return FALSE;
    for (i=1;i<12;i++) hashcodes[i] = hashcodes[0] + i*64;

    hashtable_w = 0;
    hashtable_b = 0;
    if (default_hashmode == OPTION_ON) {
        if ((hashtable_w = (hentry_t*)malloc(sizeof(hentry_t)*HASHSIZE))) {
            if ((hashtable_b = (hentry_t*)malloc(sizeof(hentry_t)*HASHSIZE)))
            {
                return TRUE;
            }
        }

        if (hashtable_w) free(hashtable_w);
        if (hashtable_b) free(hashtable_b);

        hashtable_w = 0;
        hashtable_b = 0;
        DrawStr(0,0,"TOO LESS MEM FOR HASHING.",A_REPLACE);
        DrawStr(0,10,"HASHING TURNED OFF.",A_REPLACE);
        DrawStr(0,20,"[PRESS A KEY]",A_REPLACE);

        //------------------------------------------------------------------
        // we cannot use GetUserInput() here, because our keyboard handler
        // isn't already running, we have to use the system keyboard handler
        //------------------------------------------------------------------
        ngetchx();
        ClrScr();
        default_hashmode    = OPTION_OFF;
        defaults.hashtables = OPTION_OFF;
    }

    return TRUE;
}



/*===========================================================================*/
/* frees previously allocated memory and sets pointers to zero               */
/*===========================================================================*/
// TODO: optimize this !
void FreeMemory(void) {
    FreeReservedMemory();

    if (board)        {free(board);        board        = 0;}
    if (ep_field)     {free(ep_field);     ep_field     = 0;}
    if (move_stack)   {free(move_stack);   move_stack   = 0;}
    if (stack_ranges) {free(stack_ranges); stack_ranges = 0;}
    if (killer_tab)   {free(killer_tab);   killer_tab   = 0;}
    if (p_controlled) {free(p_controlled); p_controlled = 0;}
    if (p_per_column) {free(p_per_column); p_per_column = 0;}
    if (r_per_column) {free(r_per_column); r_per_column = 0;}
    if (mobility)     {free(mobility);     mobility     = 0;}
    if (to_fields)    {free(to_fields);    to_fields    = 0;}
    if (material_bal) {free(material_bal); material_bal = 0;}
    if (material_sum) {free(material_sum); material_sum = 0;}
    if (move_store)   {free(move_store);   move_store   = 0;}

    if (main_var) {
        if (main_var[0]) free(main_var[0]);
        free(main_var);
        main_var = 0;
    }

    if (hashcodes) {
        if (hashcodes[0]) free(hashcodes[0]);
        free(hashcodes);
        hashcodes = 0;
    }
    if (hashtable_w)     {free(hashtable_w);hashtable_w=0;}
    if (hashtable_b)     {free(hashtable_b);hashtable_b=0;}
}



/*===========================================================================*/
/* Initialization of board and game state                                    */
/*                                                                           */
/* will be done just once                                                    */
/*===========================================================================*/
inline void InitEngine(short level) {
    short i;

    already_mate   = FALSE;
    updatecounter  = 0;

    //-------------------------------------------------------------------------
    // reset move counter and copy initial board setup
    //-------------------------------------------------------------------------
    move_count = 0;

    for (i=0;i<BOARD_SIZE;i++) board[i] = board_setup[i];

    //-------------------------------------------------------------------------
    // reset positions of kings, reset enpassant state, reset rochade markers
    // and reset move indicators
    //-------------------------------------------------------------------------
    white_king_pos = E1;
    black_king_pos = E8;
    ep_field[0]    = ILLEGAL;

    //-------------------------------------------------------------------------
    // reset material sum, reset material balance, reset first stack range,
    // set standard depth, reset actual depth and set actual color is WHITE
    //-------------------------------------------------------------------------
    material_sum[0] = VALUE_MAX;
    material_bal[0] = 0;
    stack_ranges[0] = 0;
    std_depth       = level;
    act_depth       = 0;
    act_color       = WHITE;

    //-------------------------------------------------------------------------
    // calculate hashkey, initialize pawn structures and set stored moves to 0
    //-------------------------------------------------------------------------
    CalcHashKey();
    InitPawnVars();
    moves_stored     = 0;
    moves_forward    = 0;     // no moves to forward
    initial_position = act_hashkey;
    flags[0]         = INIT_SYSTEM_FLAGS;
    flags_0          = flags[0];
    ep_field_0       = ep_field[0];
    material_sum_0   = material_sum[0];
    material_bal_0   = material_bal[0];
}



/*===========================================================================*/
/* mapping of figure value to character                                      */
/*===========================================================================*/
/*
STATIC_FUNC char Figure2Char(char figure) {
    return fig_symbols[figure+6];
}
*/


/*===========================================================================*/
/* converts internal field number into field notation ("--" == invalid field)*/
/*===========================================================================*/
char* Field2Notation(short fieldnumber,char* fieldnotation) {
    //---------------------
    // validate given field
    //---------------------
    if (fieldnumber<A1 || fieldnumber>H8 || board[fieldnumber]==OUTSIDE) {
        strcpy(fieldnotation,"--");
    }
    else {
        fieldnotation[0] = 'A'- 1 + fieldnumber%10;
        fieldnotation[1] = '1'- 2 + (fieldnumber/10);
        fieldnotation[2] = 0;
    }
    return fieldnotation;
}



/*===========================================================================*/
/* converts field notation into internal field number                        */
/*===========================================================================*/
STATIC_FUNC short Notation2Field(char* fieldnotation) {
    //-----------------------------
    // validate given fieldnotation
    //-----------------------------
    if (fieldnotation[0]<'A' ||
        fieldnotation[0]>'H' ||
        fieldnotation[1]<'1' ||
        fieldnotation[1]>'8' )
    {
       return ILLEGAL;
    }
    return (fieldnotation[0]-'A'+1) + 10*(fieldnotation[1]-'1'+2);
}



/*===========================================================================*/
/* converts move to string representation                                    */
/*===========================================================================*/
const char* Move2Str(move_t *pmove,short fromboard) {
    short from,to;

    if (pmove->rochade_nr==ROCHADE_LONG)  return "O-O-O";
    if (pmove->rochade_nr==ROCHADE_SHORT) return "O-O    ";

    from = pmove->from;
    to   = pmove->to;

    if (fromboard) {
        movetext[0]=fig_symbols[board[from]+6];
    }
    else {
        if (pmove->promoted_fig != EMPTY) movetext[0] = fig_symbols[W_PAWN+6];
        else                              movetext[0] = fig_symbols[((store_t*)pmove)->figure+6];
    }

    Field2Notation(from,&movetext[1]);

    if (pmove->killed_fig==EMPTY) {
        movetext[3] = '-';
    }
    else {
        movetext[3] = 'x';
    }

    Field2Notation(to,&movetext[4]);

    if (pmove->promoted_fig != EMPTY) {
        movetext[6] = fig_symbols[pmove->promoted_fig+6];
        movetext[7] = 0;
    }
    else {
        movetext[6] = 0;
    }

    return movetext;
}



/*===========================================================================*/
/* intialize tree                                                            */
/*===========================================================================*/
STATIC_FUNC void InitTree(void) {
    if (!act_depth) return; // already initialized

    ep_field[0]     = ep_field[1];
    material_bal[0] = material_bal[1];
    material_sum[0] = material_sum[1];
    act_depth       = 0;
}



/*===========================================================================*/
/* returns next move not played until now (returns -1 if all are played)     */
/*===========================================================================*/
STATIC_FUNC short NextBestMove(void) {
    short i,bestval,bestmove;
    bestmove = -1;
    bestval  = -VALUE_MATE;

    //------------------------------------------------------------------------
    // loop through all moves of act_depth (range is stored in stack_ranges[])
    //------------------------------------------------------------------------
    for (i=stack_ranges[act_depth];i<stack_ranges[act_depth+1];i++) {
        if (move_stack[i].value > bestval) {
            bestmove = i;
            bestval  = move_stack[i].value;
        }
    }

    //------------------------------------------------------------------------
    // if we've found a best move, set its value to -VALUE_MATE.
    // This will prevent us from selecting the same move later.
    //------------------------------------------------------------------------
    if (bestmove >= 0) move_stack[bestmove].value = -VALUE_MATE;

    return bestmove;
}



/*===========================================================================*/
/* alpha/beta tree search: returns evaluation from actual player's sight     */
/*                                                                           */
/* alpha    ... lower border                                                 */
/* beta     ... upper border                                                 */
/* distance ... number of moves to the horizon                               */
/*                                                                           */
/* if distance is positive --> normal alpha beta searching                   */
/* otherwise               --> "Ruhesuche"                                   */
/*                                                                           */
/* returns NegaMax value from actual player's sight                          */
/*                                                                           */
/* (WARNING: recursive function)                                             */
/*===========================================================================*/

#define SKIP_NODEDISPLAY  200
#define SKIP_KEYPRESSES   (SKIP_NODEDISPLAY/10)
#define SKIP_TIMERCHECK   (SKIP_NODEDISPLAY/4)

STATIC_FUNC short AlphaBetaSearch(short alpha,short beta,short distance) {
    short i,val,bestvalue,chess;
    unsigned char c;

    nr_nodes++;       // increment node counter
    updatecounter++;

    //---------------------------------------
    // check for key presses and clock update
    //---------------------------------------
    if (!(updatecounter % SKIP_KEYPRESSES)) {
        //------------------------------------------
        // stop calculation if ESCAPE key is pressed
        //------------------------------------------
        short key = KeyPressed();
        if (key == KEY_ESCAPE) {
            GetUserInput(0); // remove pressed key ...
            if (RequestDialog(MSG_ABORT)) {
                abort_move = TRUE;
                return 0;
            }
        }
        else if (key == KEY_EXIT) {
            abort_move = TRUE;
            return 0;
        }
    }

    if (!(updatecounter % SKIP_TIMERCHECK)) {
        if (OSTimerExpired(USER_TIMER)) IncrementClock();
    }

    //-------------------------
    // update the nodes display
    //-------------------------
    if (!(updatecounter % SKIP_NODEDISPLAY)) {
        UpdateNodeDisplay(nr_nodes);
        updatecounter=0;
    }

    main_var[act_depth][act_depth].from = 0;   // deletes act. main variant

    //-------------------------------------------------------
    // evaluate active position using given alpha/beta window
    //-------------------------------------------------------
    val = Evaluate(act_color);

    if ((chess=chess_indicator)==TRUE && act_depth+distance<max_extend+1) {
        distance++;  // extend search
    }
    else if ( act_depth >= 2                                 &&
              act_depth+distance < max_extend                &&
              to_fields[act_depth] == to_fields[act_depth-1] &&
              val >= alpha-150                               &&
              val <= beta+150)
    {
        distance++;  // extend search
    }

    if (distance<-5 || val==VALUE_MATE-act_depth || act_depth>=MAX_DEPTH) {
        return val;
    }


    // if we'll force the 50ply rule, return zero (it's a draw)
    c = move_stack[last_move].count & 0x7f;
    if (c >= 100) return 0;

    if (val>=beta && distance+chess<=1) return val;

    //-------------------------------------------------------------------------
    // check if just one repetition is found if one is found, handle it like a
    // draw I know that's lazy, but prevent us from scanning the whole list of
    // stored moves
    //-------------------------------------------------------------------------
    if (CheckForRepetition(FALSE)!=NO_REPETITION) return 0;

    GenerateMoves(distance);

    bestvalue = (distance>0) ? -VALUE_MATE : val;

    //-------------------------------------------------------------------------
    // examine all moves in sorted order
    //-------------------------------------------------------------------------
    while ((i=NextBestMove())>=0) {
        ExecMove(i);
        //---------------------------------------------------------------------
        // NegaMax principle: change sign, swap alpha and beta
        //---------------------------------------------------------------------
        val = -AlphaBetaSearch(-beta,-alpha,distance-1);
        UndoMove(i);

        if (abort_move) return 0;
        if (val>bestvalue) {
            bestvalue=val;
            if (val>=beta) {
                if (distance>0) CopyMainVariant(i);
                goto done;
            }
            if (val>alpha) {
                if (distance>0) CopyMainVariant(i);
                alpha=val;
            }
        }
    }

done:
    //-------------------------------------------------------------------------
    // good move, generate cutoff, will be entered in killer table store
    // previous killer move as second best killer
    //-------------------------------------------------------------------------
    if (val>=beta && i>=0) {
        killer_tab[act_depth].killer2      = killer_tab[act_depth].killer1;
        killer_tab[act_depth].killer1.from = move_stack[i].from;
        killer_tab[act_depth].killer1.to   = move_stack[i].to;
    }

    if (bestvalue == -(VALUE_MATE-(act_depth+1)) && !chess) return 0;

    return bestvalue;
}



/*===========================================================================*/
/* stores actual move into main variant and copies continuation on the       */
/* next depth                                                                */
/*===========================================================================*/
STATIC_FUNC void CopyMainVariant(short idx) {
    short i;
    /* new main variant will continue this variant */
    main_var[act_depth][act_depth].from = move_stack[idx].from;
    main_var[act_depth][act_depth].to   = move_stack[idx].to;
    for (i=1;;i++) {
        if (!(main_var[act_depth+1][act_depth+i].from)) {
            main_var[act_depth][act_depth+i] = main_var[act_depth+1][act_depth+i];
            return;
        }
        main_var[act_depth][act_depth+i] = main_var[act_depth+1][act_depth+i];
    }
}


/*===========================================================================*/
/* treatment of move flags (used within ExecMove())                          */
/*===========================================================================*/
// Can this be optimized ?
STATIC_FUNC void HandleMoveFlags(short field,unsigned short* flags) {
    switch(field) {
        case A1: *flags |= A1_MOVE_MASK; break;
        case B1: *flags |= B1_MOVE_MASK; break;
        case C1: *flags |= C1_MOVE_MASK; break;
        case E1: *flags |= E1_MOVE_MASK; break;
        case F1: *flags |= F1_MOVE_MASK; break;
        case G1: *flags |= G1_MOVE_MASK; break;
        case H1: *flags |= H1_MOVE_MASK; break;
        case A8: *flags |= A8_MOVE_MASK; break;
        case B8: *flags |= B8_MOVE_MASK; break;
        case C8: *flags |= C8_MOVE_MASK; break;
        case E8: *flags |= E8_MOVE_MASK; break;
        case F8: *flags |= F8_MOVE_MASK; break;
        case G8: *flags |= G8_MOVE_MASK; break;
        case H8: *flags |= H8_MOVE_MASK; break;
    }
}



/*===========================================================================*/
/* treatment of a killed figure                                              */
/*                                                                           */
/* increment == -1 for ExecMove    increment == 1 for UndoMove               */
/*===========================================================================*/
STATIC_FUNC void HandleKilledFigure(char figure,short field,short increment) {
    // correct pawn variables depending on 'to' field contents
    switch(figure) {
        case W_PAWN:                    // killed white pawn
            p_controlled[field+9].white  += increment;
            p_controlled[field+11].white += increment;
            p_per_column[field%10].white += increment;
            break;

        case B_PAWN:                     // killed black pawn
            p_controlled[field-9].black  += increment;
            p_controlled[field-11].black += increment;
            p_per_column[field%10].black += increment;
            break;

        case B_ROOK:                     // killed black rook
            r_per_column[field%10].black += increment;
            break;

        case W_ROOK:                     // killed white rook
            r_per_column[field%10].white += increment;
            break;

        default:
            break;
    }
}



/*===========================================================================*/
/* treatment of the from field                                               */
/*                                                                           */
/* increment == -1 for ExecMove    increment == 1 for UndoMove               */
/*===========================================================================*/
STATIC_FUNC void HandleFromField(char figure,char promoted,short from,short to,short increment) {
    //----------------------------------------------
    // handle the from statement for pawn structures
    //----------------------------------------------
    switch(figure) {
        case W_PAWN:
            p_controlled[from+9].white  += increment;
            p_controlled[from+11].white += increment;
            p_per_column[from%10].white += increment;
            if (promoted == EMPTY) {
                p_controlled[to+9].white  -= increment;
                p_controlled[to+11].white -= increment;
                p_per_column[to%10].white -= increment;
            }
            else if (increment == 1 && promoted == W_ROOK) {
                r_per_column[to%10].white--;
            }
            break;

        case B_PAWN:
            p_controlled[from-9].black+=increment;
            p_controlled[from-11].black+=increment;
            p_per_column[from%10].black+=increment;
            if (promoted == EMPTY) {
                p_controlled[to-9].black-=increment;
                p_controlled[to-11].black-=increment;
                p_per_column[to%10].black-=increment;
            }
            else if (increment == 1 && promoted == W_ROOK) {     // NOTE: promoted figure is stored ABSOLUTE !
                r_per_column[to%10].black--;
            }
            break;

        case B_ROOK:
            r_per_column[from%10].black += increment;
            r_per_column[to%10].black   -= increment;
            break;

        case W_ROOK:
            r_per_column[from%10].white += increment;
            r_per_column[to%10].white   -= increment;
            break;

        default:
            break;
    }
}



/*===========================================================================*/
/* executes a move on the board and updates state and search depth           */
/*===========================================================================*/
STATIC_FUNC void ExecMove(short idx) {
    short from,to,epfield,matchange,promoted,tmp_to,figure;

    // increment move counter
    move_count++;

    // setup locals and update last_move global
    from      = move_stack[idx].from;
    to        = move_stack[idx].to;
    epfield   = move_stack[idx].ep_field;
    promoted  = move_stack[idx].promoted_fig;
    last_move = idx;

    XorHKey(board[from],from);  // remove from figure from hashcode

    // correct pawn variables depending on 'from' field contents
    HandleFromField(board[from],promoted,from,to,-1);

    if (epfield!=ILLEGAL && move_stack[idx].killed_fig==W_PAWN) {
        figure = -act_color;
        tmp_to = epfield;
    }
    else {
        figure = board[to];
        tmp_to = to;
    }

    //------------------------------------------------
    // handle the killed statement for pawn structures
    //------------------------------------------------
    HandleKilledFigure(figure,tmp_to,-1);

    //--------------------------------
    // one step deeper in the tree ...
    //--------------------------------
    act_depth++;
    to_fields[act_depth] = to;
    ep_field[act_depth]  = ILLEGAL;

    //--------------------------------------------------
    // get flags from previous level and correct
    // the move flags depending on the from and to field
    //--------------------------------------------------
    flags[act_depth] = flags[act_depth-1];

    HandleMoveFlags(from,&flags[act_depth]);
    HandleMoveFlags(to,&flags[act_depth]);

    //-------------------------------------------------------
    // invert material balance to see it from the actual side
    //-------------------------------------------------------
    material_bal[act_depth] = -material_bal[act_depth-1];
    material_sum[act_depth] = material_sum[act_depth-1];

    // figure is moving from the from-field to the to field
    if (epfield != ILLEGAL) {
        if (board[epfield] == EMPTY) {    // pawn moves from 2nd to 4th row
            ep_field[act_depth] = epfield;
        }
        else {  // foreign pawn will be killed "enpassant"
            XorHKey(board[epfield],epfield);  // killing enpassant for hashcode
            board[epfield] = EMPTY;
            material_bal[act_depth] -= VALUE_PAWN;
        }
    }

    else {
        // if a figure gets killed, change material balance
        if (move_stack[idx].killed_fig != EMPTY) {
            XorHKey(board[to],to);  // killing move for hashcode
            // a figure gets killed
            matchange = fig_values[(unsigned char)(move_stack[idx].killed_fig)];
            material_bal[act_depth] -= matchange;
            // only figure (no pawns) gets counted in sum
            if (matchange != VALUE_PAWN) {
                material_sum[act_depth] -= matchange;
            }
        }
    }

    // execute move on board
    board[to]   = board[from];
    board[from] = EMPTY;

    // handle pawn promotion
    if (promoted != EMPTY) {
        board[to] = act_color*promoted;
        matchange = (fig_values[promoted]-VALUE_PAWN);
        material_bal[act_depth] -= matchange;
        // pawns will not be counted in sum
        material_sum[act_depth] += matchange + VALUE_PAWN;
        // correct pawn variables for promotion
        if (promoted == W_ROOK) {
            if (act_color == WHITE) {
                r_per_column[to%10].white++;
            }
            else {
                r_per_column[to%10].black++;
            }
        }
        XorHKey(board[to],to);  // promotion
    }
    else {
        XorHKey(board[to],to);  // normal move
        // handle short rochade if necessary
        if (move_stack[idx].rochade_nr == ROCHADE_SHORT) {
            XorHKey(board[to+1],to+1);  // rochade short
            board[to+1] = EMPTY;
            board[to-1] = act_color*W_ROOK;
            XorHKey(board[to-1],to-1);  // rochade short
            // pawn variables correction for short rochade
            if (act_color == WHITE) {
                r_per_column[(to+1)%10].white--;
                r_per_column[(to-1)%10].white++;
                flags[act_depth] |= (H1_MOVE_MASK | E1_MOVE_MASK | W_ROCHADE_MASK);
            }
            else {
                r_per_column[(to+1)%10].black--;
                r_per_column[(to-1)%10].black++;
                flags[act_depth] |= (H8_MOVE_MASK | E8_MOVE_MASK | B_ROCHADE_MASK);
            }
        }
        // handle long rochade if necessary
        else if (move_stack[idx].rochade_nr == ROCHADE_LONG) {
            // pawn variables correction for long rochade
            if (act_color == WHITE) {
                r_per_column[(to-2)%10].white--;
                r_per_column[(to+1)%10].white++;
                flags[act_depth] |= (A1_MOVE_MASK | E1_MOVE_MASK | W_ROCHADE_MASK);
            }
            else {
                r_per_column[(to-2)%10].black--;
                r_per_column[(to+1)%10].black++;
                flags[act_depth] |= (A8_MOVE_MASK | E8_MOVE_MASK | B_ROCHADE_MASK);
            }
            XorHKey(board[to-2],to-2);  // rochade long
            board[to-2] = EMPTY;
            board[to+1] = act_color*W_ROOK;
            XorHKey(board[to+1],to+1);  // rochade long
        }
    }

    // update king positions if necessary
    if (board[to] == W_KING) white_king_pos=to;
    else if (board[to]==B_KING) black_king_pos=to;

    // change color (other side is up to draw )
    act_color = -act_color;
}



/*===========================================================================*/
/* takes back a move                                                         */
/*===========================================================================*/
STATIC_FUNC void UndoMove(short idx) {
    short from,to,epfield,promoted;
    short tmp_to,figure,rochade,fromfig;

    move_count--;
    from     = move_stack[idx].from;
    to       = move_stack[idx].to;
    epfield  = move_stack[idx].ep_field;
    promoted = move_stack[idx].promoted_fig;
    rochade  = move_stack[idx].rochade_nr;

    act_depth--;

    //if (act_depth >= 0) flags[act_depth] = flags[act_depth+1];

    act_color   = -act_color;

    XorHKey(board[to],to);     // remove the to figure

    board[from] = board[to];
    board[to]   = EMPTY;

    if (epfield!=ILLEGAL && move_stack[idx].killed_fig==W_PAWN) {
        board[epfield] = -act_color; /* W_PAWN==WHITE, B_PAWN==BLACK */
        XorHKey(board[epfield],epfield);  // set ep killed fig
    }

    // re-set killed figure
    else if (move_stack[idx].killed_fig != EMPTY) {
        board[to] = (-act_color)*move_stack[idx].killed_fig;
        XorHKey(board[to],to);  // set ep killed fig
    }

    // take back short rochade
    if (rochade == ROCHADE_SHORT) {
        board[to+1] = act_color*W_ROOK;
        XorHKey(board[to+1],to+1);
        XorHKey(board[to-1],to-1);
        board[to-1] = EMPTY;
        // correct pawn variables for short rochade
        if (act_color == WHITE) {
            r_per_column[(to-1)%10].white--;
            r_per_column[(to+1)%10].white++;
        }
        else {
            r_per_column[(to-1)%10].black--;
            r_per_column[(to+1)%10].black++;
        }
    }
    // take back long rochade
    else if(rochade == ROCHADE_LONG) {
        board[to-2] = act_color*W_ROOK;
        XorHKey(board[to-2],to-2);
        XorHKey(board[to+1],to+1);
        board[to+1] = EMPTY;
        // correct pawn variables for long rochade
        if (act_color == WHITE) {
            r_per_column[(to-2)%10].white++;
            r_per_column[(to+1)%10].white--;
        }
        else {
            r_per_column[(to-2)%10].black++;
            r_per_column[(to+1)%10].black--;
        }
    }

    // take back pawn promotion
    if (promoted != EMPTY) board[from]=act_color;

    fromfig = board[from];

    XorHKey(board[from],from);

    // update king position if necessary
    if (fromfig==W_KING)      white_king_pos=from;
    else if (fromfig==B_KING) black_king_pos=from;


    //----------------------------------------------
    // handle the from statement for pawn structures
    //----------------------------------------------
    HandleFromField(fromfig,promoted,from,to,1);

    if (epfield!=ILLEGAL && move_stack[idx].killed_fig==W_PAWN) {
        figure = -act_color;
        tmp_to = epfield;
    }
    else {
        figure = board[to];
        tmp_to = to;
    }

    //------------------------------------------------
    // handle the killed statement for pawn structures
    //------------------------------------------------
    HandleKilledFigure(figure,tmp_to,1);
}



/*===========================================================================*/
/* evaluation positional value of a black pawn                               */
/*                                                                           */
/* This is one of the most called functions at the beginning ...             */
/*===========================================================================*/
STATIC_FUNC inline short BlackPawnEvaluation(short field,short row, short column,short developed) {
    register short value;
    register short pctrl;
    register short pctrl10;
    register short rowX2;
    register short j;

    // invert row. higher row is better (equal to white)
    row = (ROW_8+ROW_1)-row;
    rowX2 = row << 1;

    // opening or middle game ?
    if (material_sum[act_depth]>VALUE_ENDGAME) {
        value = bp_fieldvalues[field];

        // development not finished. don't force border pawns
        if (developed<4  &&
            (column>=F_COLUMN || column<=B_COLUMN) &&
            row > ROW_3)
        {
            value -= 15;
        }
    }
    else {
        // if we are not in the endgame all lines are treated equally
        value = rowX2;
    }

    // malus for "isolanis"
    if (!(p_per_column[column-1].black) &&
        !(p_per_column[column+1].black))
    {
        value -= 12;
        // additional malus for isolated double pawns on a line
        if (p_per_column[column].black>1) value -= 12;
    }

    // malus for double pawns on a line
    if (p_per_column[column].black>1) value -= 15;

    pctrl   = p_controlled[field].black;
    pctrl10 = p_controlled[field+10].black;

    // bonus for "duos" (for example: e5/d5)
    if (pctrl>0 || pctrl10>0) {
        value += row ;
    }

    if (!(p_per_column[column].white)) {
        if (!pctrl &&
            p_controlled[field-10].white > pctrl10)
        {
            value -= 10;
            if (r_per_column[column].white>0) value -= 8;
        }
        else {
            for (j=field;j>H2;j-=10) {
                if (p_controlled[j].white>0) {
                    goto finished;
                }
            }
            // free pawn found. will be weighted higher in endgame
            if (material_sum[act_depth]<VALUE_ENDGAME) {
                value += row<<4; // bonus for wide processed pawn
                if (r_per_column[column].black>0) { // rook supports pawn on same line
                    value += rowX2;
                }
                if (r_per_column[column].white>0) { // foreign rook on same line
                    value -= rowX2;
                }

                if (!(material_sum[act_depth])) { // only pawns left
                    value += row<<3; // extra bonus for position
                }
                if (pctrl>0 || pctrl10>0) { // supported pawn bonus
                    value += rowX2;
                    value += rowX2;
                }
                // malus for blocked pawn
                if (!pctrl10 && board[field-10]<0) {
                    value -= rowX2;
                    value -= rowX2;
                }
            }
            else { // free pawn in middle game
                value += row<<3;
                if (pctrl>0 || pctrl10>0) { // supported pawn bonus
                    value += row<<2;
                }
            }
        }
    }

finished:
    return value;
}



/*===========================================================================*/
/* evaluation positional value of a white pawn                               */
/*                                                                           */
/* This is one of the most called functions at the beginning ...             */
/*===========================================================================*/
STATIC_FUNC inline short WhitePawnEvaluation(short field,short row, short column,short developed) {
    register short value;
    register short pctrl;
    register short pctrl10;
    register short rowX2;
    register short j;

    rowX2 = row << 1;

    if (material_sum[act_depth]>VALUE_ENDGAME) {
        value = wp_fieldvalues[field];
        if (developed<4 &&
            (column>=F_COLUMN || column<=B_COLUMN) &&
            row>ROW_3)
        {
            value -= 15;
        }
    }
    else {
        value = row<<2;
    }

    if (!(p_per_column[column-1].white) &&
        !(p_per_column[column+1].white))
    {
        value -= 12;  // Isolani
        if (p_per_column[column].white>1) { // isolated double pawn
            value -= 12;
        }
    }

    if (p_per_column[column].white>1) { // double pawn
        value -= 15;
    }

    pctrl   = p_controlled[field].white;
    pctrl10 = p_controlled[field+10].white;

    // duo or supporting pawn bonus
    if (pctrl>0 || pctrl10>0) {
        value += row;
    }

    if (!(p_per_column[column].black)) { // halfopen line
        // not much developed pawn on halfopen line
        if (!pctrl &&
            p_controlled[field+10].black>pctrl10)
        {
            value -= 10;
            if (r_per_column[column].black>0) {
                value -= 8; // rook "attacks" pawn
            }
        }
        else {
            for (j=field;j<A7;j+=10) { // check for free pawn
                if (p_controlled[j].black>0) {
                    goto finished2;
                }
            }
            // free pawn found

            if (material_sum[act_depth]<VALUE_ENDGAME) {
                value += row<<4;

                if (r_per_column[column].white>0) { // supporting rook
                    value += rowX2;
                }
                if (r_per_column[column].black>0) { // foreign rook
                    value -= rowX2;
                }

                if (!(material_sum[act_depth])) { // only pawns left
                    value += row<<3;
                }

                if (pctrl>0 || pctrl10>0) { // supporting free pawn
                    value += rowX2;
                    value += rowX2;
                }

                // blocked by black figure
                if (!pctrl10 && board[field+10]<0) {
                    value -= rowX2;
                    value -= rowX2;
                }
            }
            else { // free pawn in middle game
                value += row<<3;
                if (pctrl>0 || pctrl10>0) { // supporting free pawn
                    value += rowX2;
                }
            }
        }
    }

finished2:
    return value;
}



/*===========================================================================*/
/* board evaluation from the view of "side"                                  */
/*                                                                           */
/* if material value is too much out of alpha/beta window, just the material */
/* is value is returned                                                      */
/*                                                                           */
/* if other side is already check mate function returns VALUE_MATE-depth     */
/*===========================================================================*/
STATIC_FUNC short Evaluate(short side) {
    short matbal;          // material balance
    short posvalue;        // positional evaluation
    short i,j,k,field;
    short white_bishops;   // counts white bishops
    short black_bishops;   // counts black bishops
    short pawn_count;      // pawns on the board (white+black)
    short matsum;          // material sum short cut
    short white_rooks_on7; // white rooks on 7/6 row counter
    short black_rooks_on2; // black rooks on 1/2 row counter
    short white_developed; // development state of white (0..5)
    short black_developed; // development state of black (0..5)
    short sum_up;

    short my_king_pos,foreign_king_pos;

    unsigned short tmpflags = flags[act_depth];

    if (side==WHITE) {
        my_king_pos      = white_king_pos;
        foreign_king_pos = black_king_pos;
    }
    else {
        my_king_pos      = black_king_pos;
        foreign_king_pos = white_king_pos;
    }

    //------------------------------------------------------
    // return immediately if other side is already checkmate
    //------------------------------------------------------
    if (AttacksField(foreign_king_pos,side)) return VALUE_MATE-act_depth;

    //----------------------------------------
    // will be TRUE if actual side is in check
    //----------------------------------------
    chess_indicator=AttacksField(my_king_pos,side*(-1));

    //--------------------------------------------------------------------
    // positional factors won't count if material balance is too unequally
    // EXCEPTION: late endgame
    //--------------------------------------------------------------------
    matbal = material_bal[act_depth];
    matsum = material_sum[act_depth];

    if (RetrieveFromHash(&posvalue)) {
        return matbal + posvalue;
    }

    posvalue        = 0;
    black_bishops   = 0;
    white_bishops   = 0;
    pawn_count      = 0;
    white_rooks_on7 = 0;
    black_rooks_on2 = 0;

    //--------------------------------------------------------------
    // evaluate development state of white and black by checking
    // for rochade and light figure movement
    //
    // POSSIBLE IMPROVEMENT: make develop vars global and check only
    //                       if value < 5.
    //                       !! BUT BE AWARE OF TEMPORARY MOVES !!
    //--------------------------------------------------------------

    white_developed = WHITE_DEVELOPED(tmpflags);
    black_developed = BLACK_DEVELOPED(tmpflags);

    //------------------------------------------------------
    // loop through complete board and evaluate each figure.
    // evaluation is done from WHITE's sight
    //
    // posvalue > 0 ... better for white
    // posvalue < 0 ... better for black
    //------------------------------------------------------
    for (i=ROW_1,sum_up=ROW_1*10;i<=ROW_8;i++,sum_up+=10) {
        field = sum_up + A_COLUMN;
        for (j=A_COLUMN;j<=H_COLUMN;j++,field++) {
            switch(board[field]) {
                case B_KING:
                    //-----------------------------
                    // endgame evaluation
                    //-----------------------------
                    if (matsum<VALUE_ENDGAME) {
                        posvalue -= center_table[field];
                    }
                    else {
                        // malus for rochade right lost
                        if ((tmpflags & B_ROCHADE_MASK) == 0) {

                            if ((tmpflags & E8_MOVE_MASK) ||
                               ((tmpflags & (H8_MOVE_MASK | A8_MOVE_MASK))) )
                            {
                                posvalue += 35;
                            }
                        }
                        // king shouldn't be in the center
                        posvalue += (center_table[field]<<2);

                        for (k=-1;k<=1;k++) {
                            // bonus for pawns directly in front of king
                            if (board[field-10+k] == B_PAWN) posvalue -= 15;
                            // bonus for pawns 2 rows in front of king
                            if (board[field-20+k] == B_PAWN) posvalue -= 6;
                            // malus for half-open line with a foreign rook
                            if (!(p_per_column[j+k].white) && r_per_column[j+k].white>0) {
                                posvalue=posvalue+12;
                            }
                        }
                    }
                    break;

                case B_QUEEN:
                    // malus for queen excursations at the beginning
                    if (black_developed<4) {
                        if (field<A8) posvalue += 15;
                    }
                    // bonus if queen is near foreign king
                    else {
                        //posvalue += (abs((white_king_pos/10)-(field/10)) +
                        //             abs((white_king_pos%10)-(field%10)))<<1;
                        posvalue += (abs((white_king_pos/10)-i) +
                                     abs((white_king_pos%10)-j))<<1;
                    }
                    break;

                case B_KNIGHT:
                    // should be near the center
                    posvalue -= (center_table[field]>>1);
                    break;

                case B_BISHOP:
                    // shouldn't block d7/e7 pawns
                    if ((field==D6 || field==E6) &&
                        (board[field+10]==B_PAWN))
                    {
                        posvalue += 20;
                    }
                    black_bishops++;
                    break;

                case B_ROOK:
                    // bonus if it is on row 1 or 2
                    if (field<=H2) black_rooks_on2++;

                    // bonus if near center
                    if (j>=C_COLUMN && j<=E_COLUMN) posvalue -= 4;

                    // bonus if on halfopen or open line
                    if (!(p_per_column[j].white)) {
                        posvalue-=8;
                        if (!(p_per_column[j].black)) posvalue-=5;
                    }
                    break;

                case B_PAWN:
                    // will be done in own routine
                    posvalue -= BlackPawnEvaluation(field,i,j,black_developed);
                    pawn_count++;
                    break;

                case EMPTY:
                    break;

                case W_PAWN:
                    // will be done in own routine
                    posvalue += WhitePawnEvaluation(field,i,j,white_developed);
                    pawn_count++;
                    break;

                case W_ROOK:
                    // bonus if on row 7 or 8
                    if (field>=A7) white_rooks_on7++;

                    // bonus if near center
                    if (j>=C_COLUMN && j<=E_COLUMN) posvalue += 4;

                    // bonus if on halfopen or open line
                    if (!(p_per_column[j].black)) {
                        posvalue+=8;
                        if (!(p_per_column[j].white)) posvalue += 5;
                    }
                    break;

                case W_BISHOP:
                    // malus if blocking d3 or e3 pawn
                    if ((field==D3 || field==E3) &&
                        (board[field-10]==W_PAWN))
                    {
                        posvalue-=20;
                    }
                    white_bishops++;
                    break;

                case W_KNIGHT:
                    posvalue+=(center_table[field]>>1);
                    break;

                case W_QUEEN:
                    // malus for queen excursations at the beginning
                    if (white_developed<4) {
                        if (field>H1) posvalue-=15;
                    }
                    // queen should be near foreign king
                    else {
                        //posvalue -= (abs((black_king_pos/10)-(field/10)) +
                        //             abs((black_king_pos%10)-(field%10)))<<1;
                        posvalue -= (abs((black_king_pos/10)-i) +
                                     abs((black_king_pos%10)-j))<<1;
                    }
                    break;

                case W_KING:
                    // in endgame king should be in the center
                    if (matsum<VALUE_ENDGAME) {
                        posvalue+=center_table[field];

                        // handle near opposition of kings
                        if (abs(field-black_king_pos)==20 || abs(field-black_king_pos)==2) {
                            k=10;
                            if (!matsum) k=30;

                            if (act_color==WHITE) posvalue -= k;
                            else                  posvalue += k;
                        }
                    }
                    else {
                        if (!(tmpflags & W_ROCHADE_MASK)) {
                            if ((tmpflags & E1_MOVE_MASK) ||
                               ((tmpflags & (H1_MOVE_MASK | A1_MOVE_MASK))) )
                            {
                                posvalue -= 35;
                            }
                        }
                        // king shouldn't be in the center
                        posvalue -= (center_table[field]<<2);
                        for (k=-1;k<=1;k++) {
                            // bonus for own pawn directly in front of king
                            if (board[field+10+k]==W_PAWN) posvalue+=15;
                            // bonus for own pawn 2 rows in front of king
                            if (board[field+20+k]==W_PAWN)  posvalue+=6;
                            // malus for halfopened line with foreign rook
                            if (!(p_per_column[j+k].black) && r_per_column[j+k].black>0) {
                                posvalue -= 12;
                            }
                        }
                    }
                    break;
            }
        }
    }

    //------------------------------------------------------------
    // try to recognize insufficient material on board
    // will recognize: (K,K),(KB,K) (KN,K) (KNN,K) (KB,KB) (KB,KN)
    //
    // BUT NOT: (KNN,KB)  --- will this always be "stalemate" ???
    //------------------------------------------------------------
    if (!pawn_count) {
        if ((matsum<=VALUE_BISHOP) || (matsum==2*VALUE_KNIGHT) ||
            ( (abs(matbal)<100) && (matsum<=(2*VALUE_BISHOP))) )
        {
            return 0;
        }
    }

    // bonus for white if both bishops are living
    if (white_bishops>=2) posvalue+=15;

    // bonus for black if both bishops are living
    if (black_bishops>=2) posvalue-=15;

    // extra bonus for white rooks
    if (white_rooks_on7>0 && black_king_pos>=A7) {
        posvalue += 10;
        if (white_rooks_on7>1) posvalue+=25;
    }

    // extra bonus for black rooks
    if (black_rooks_on2>0 && white_king_pos<=H2) {
        posvalue -= 10;
        if (black_rooks_on2>1) posvalue-=25;
    }

    // if side is BLACK --> invert position evaluation value
    if (side==BLACK) posvalue = -posvalue;

    //------------------------------------------------------------
    // take mobility of knights and rooks into account
    // (will be calculated by move generator)
    //
    // mobility[act_depth]   .. mobility of other side
    // mobility[act_depth-1] .. mobility of my side
    //------------------------------------------------------------
    if (act_depth>1) {
        posvalue -= (mobility[act_depth]-mobility[act_depth-1])/16;
    }

    StoreInHash(posvalue);

    return matbal+posvalue;
}



/*===========================================================================*/
/* stores a move on the move stack                                           */
/*===========================================================================*/
STATIC_FUNC void PutMoveOnStack(short from,short to) {
    //------------------------------------------------------
    // increment mobility for bishops and rooks of own color
    // mobility near center will be weighted higher than
    // near the border
    //------------------------------------------------------
    register short     figure;
    register move_t* tmpmove;

    figure = board[from];

    if (act_color==WHITE) {
        if (figure == W_BISHOP || figure == W_ROOK) {
            mobility[act_depth] += center_table[to];
        }
    }
    else {
        if (figure == B_BISHOP || figure == B_ROOK) {
            mobility[act_depth] += center_table[to];
        }
    }

    tmpmove = &move_stack[act_index];

    //----------------------------------------
    // weighting of move for move sorting
    // bonus for main variant and killer moves
    //----------------------------------------
    if (main_var[0][act_depth].from==from &&
        main_var[0][act_depth].to==to)
    {
        tmpmove->value=HVARBONUS;
    }
    else if (killer_tab[act_depth].killer1.from==from &&
             killer_tab[act_depth].killer1.to==to)
    {
        tmpmove->value=KILLER1BONUS;
    }
    else if (killer_tab[act_depth].killer2.from==from &&
             killer_tab[act_depth].killer2.to==to)
    {
        tmpmove->value=KILLER2BONUS;
    }
    else {
        tmpmove->value=EMPTY;
    }

    tmpmove->from         = from;
    tmpmove->to           = to;
    tmpmove->killed_fig   = EMPTY;
    tmpmove->promoted_fig = EMPTY;
    tmpmove->rochade_nr   = ROCHADE_NONE;
    tmpmove->ep_field     = ILLEGAL;

    //-------------------------
    // !!!!!!!!!!!!!!!!!!!!!!!!
    // !!!! REPETITION_NEW !!!!
    // !!!!!!!!!!!!!!!!!!!!!!!!
    //-------------------------
    //--------------------------------------------
    // handle counting for 50ply rule and set flag
    // for repetition detection
    //--------------------------------------------
    if (figure == W_PAWN || figure == B_PAWN || moves_stored < 2) {
        tmpmove->count = 0;
    }
    else {
       unsigned char c = move_store[moves_stored-1].count & 0x7f;
       if (c < 127) c += act_depth + 1;
       tmpmove->count = c;
    }
    if (act_color == WHITE) tmpmove->count &= 0x7f;
    else                    tmpmove->count |= 0x80;



    // increment act_index and check for overflow
    if (act_index<STACK_SIZE) {
        act_index++;
    }
    else {
        LeavePrg("ERROR: Move Stack Overflow");
    }
}



/*===========================================================================*/
/* stores a killing move on the move stack                                   */
/*===========================================================================*/
STATIC_FUNC void PutKillMoveOnStack(short from,short to) {
    register short   figvalue;
    register move_t* tmpmove;

    figvalue = board[to];

    // cannot kill a king
    if (figvalue == W_KING || figvalue == B_KING) return;

    figvalue=fig_values[abs(figvalue)];

    tmpmove = &move_stack[act_index];

    tmpmove->from       = from;
    tmpmove->to         = to;
    tmpmove->killed_fig = abs(board[to]);

    // bonus for low value figures killing higher level figures
    tmpmove->value = figvalue-(fig_values[abs(board[from])]/8);

    // extra bonus for killing last moved figure
    if (act_depth>0 && to==to_fields[act_depth-1]) {
        tmpmove->value += 300;
    }

    // bonus for main variant and killer moves
    if (main_var[0][act_depth].from==from &&
        main_var[0][act_depth].to==to)
    {
        tmpmove->value += HVARBONUS;
    }
    else if (killer_tab[act_depth].killer1.from==from &&
             killer_tab[act_depth].killer1.to==to)
    {
        tmpmove->value += KILLER1BONUS;
    }
    else if (killer_tab[act_depth].killer2.from==from &&
             killer_tab[act_depth].killer2.to==to)
    {
        tmpmove->value += KILLER2BONUS;
    }
    tmpmove->promoted_fig = EMPTY;
    tmpmove->rochade_nr   = ROCHADE_NONE;
    tmpmove->ep_field     = ILLEGAL;


    //-------------------------
    // !!!!!!!!!!!!!!!!!!!!!!!!
    // !!!! REPETITION_NEW !!!!
    // !!!!!!!!!!!!!!!!!!!!!!!!
    //-------------------------
    //--------------------------------------------
    // handle counting for 50ply rule and set flag
    // for repetition detection
    //--------------------------------------------
    tmpmove->count = 0;
    if (act_color == WHITE) tmpmove->count &= 0x7f;
    else                    tmpmove->count |= 0x80;

    // increment act_index and check for overflow
    if (act_index<STACK_SIZE) {
        act_index++;
    }
    else {
        LeavePrg("ERROR: Move Stack Overflow");
    }
}



/*===========================================================================*/
/* stores enpassant move on the move_stack                                   */
/*===========================================================================*/
STATIC_FUNC void PutEpOnStack(short from,short to,short epfield) {
    register short   figure;
    register move_t* tmpmove;

    figure = board[to];

    // kings cannot be killed
    if (figure == W_KING || figure == B_KING) return;

    tmpmove = &move_stack[act_index];

    tmpmove->from         = from;
    tmpmove->to           = to;
    tmpmove->killed_fig   = W_PAWN;
    tmpmove->promoted_fig = EMPTY;
    tmpmove->rochade_nr   = ROCHADE_NONE;
    tmpmove->ep_field     = epfield;
    tmpmove->value        = VALUE_PAWN;

    //-------------------------
    // !!!!!!!!!!!!!!!!!!!!!!!!
    // !!!! REPETITION_NEW !!!!
    // !!!!!!!!!!!!!!!!!!!!!!!!
    //-------------------------
    //--------------------------------------------
    // handle counting for 50ply rule and set flag
    // for repetition detection
    //--------------------------------------------
    tmpmove->count = 0;
    if (act_color == WHITE) tmpmove->count &= 0x7f;
    else                    tmpmove->count |= 0x80;

    // increment act_index and check for move stack overflow (shouldn't happen)
    if (act_index<STACK_SIZE) {
        act_index++;
    }
    else {
        LeavePrg("ERROR: Move Stack Overflow");
    }
}



/*===========================================================================*/
/* stores all possible promotions on the move stack                          */
/*===========================================================================*/
STATIC_FUNC void PutPromotionOnStack(short from,short to) {
    short i;
    if (board[to]==EMPTY) {
        for (i=W_QUEEN;i>W_PAWN;i--) { // ordering: Q/N/B/R
            PutMoveOnStack(from,to);
            move_stack[act_index-1].promoted_fig = i;
        }
    }
    else {
        for (i=W_QUEEN;i>W_PAWN;i--) {
            PutKillMoveOnStack(from,to);
            move_stack[act_index-1].promoted_fig = i;
        }
    }
}



/*===========================================================================*/
/* checks if given side attacks given field                                  */
/*                                                                           */
/* returns TRUE if field is under attack, otherwise FALSE                    */
/*                                                                           */
/* method: simulates a king of metafigure which may attack in all directions */
/*===========================================================================*/
short AttacksField(short field, short side) {
    short i,direction,to,slide,figure;

    //-------------------
    // !!!! SPEED UP !!!!
    //-------------------
    if (side == WHITE) {
        // test for pawn attack ...
        if (board[field-9]==W_PAWN || board[field-11]==W_PAWN) return TRUE;
        // test for knight attack ...
        for (i=8;i<16;i++) {
            figure = board[field+offset_vals[i]];
            if (figure==W_KNIGHT) return TRUE;
        }
    }
    else {
        // test for pawn attack ...
        if (board[field+9]==B_PAWN || board[field+11]==B_PAWN) return TRUE;
        // test for knight attack ...
        for (i=8;i<16;i++) {
            figure = board[field+offset_vals[i]];
            if (figure==B_KNIGHT) return TRUE;
        }
    }

    //------------------------------------------------------
    // test for sliding figures and king in all 8 directions
    //------------------------------------------------------
    for (i=0;i<8;i++) {
        to        = field;
        direction = offset_vals[i];
        slide     = 0;
slideforward:
        slide++;
        to+=direction;

        figure = board[to];

        if (figure==EMPTY)   goto slideforward; // slide again
        if (figure==OUTSIDE) continue;          // oops, outside !

        if (side==WHITE) {
            if (figure>0) {
                if (figure==W_KING) {
                    if (slide<=1) return TRUE;
                }
                else {
                    if (figure_offsets[figure].start<=i &&
                        figure_offsets[figure].end>=i)
                    {
                        return TRUE;
                    }
                }
           }
        }
        else {  // for black
            if (figure<0) {
                if (figure==B_KING) {
                    if (slide<=1) return TRUE;
                }
                else {
                    if (figure_offsets[-figure].start<=i &&
                        figure_offsets[-figure].end>=i)
                    {
                        return TRUE;
                    }
                }
            }
        }
    }

    // everything checked. nothing found.
    return FALSE;
}



/*===========================================================================*/
/* generates moves and stores them on move_stack                             */
/*                                                                           */
/* if allmoves > 0 --> all pseudo legal moves are generated                  */
/* else            --> just generate promotion, enpassant, rochade and       */
/*                     killing moves                                         */
/*===========================================================================*/
STATIC_FUNC void GenerateMoves(short allmoves) {
    short from,to,figure;
    short i,longstep,direction;
    short epfield;

    act_index=stack_ranges[act_depth]; // set act_index to begin of act. range
    mobility[act_depth] = 0;

    // loop through complete board
    for (from=A1;from<=H8;from++) {
        figure = board[from];
        if (figure==EMPTY || figure==OUTSIDE) continue;

        // figure have to be of right color
        if((act_color==WHITE && figure<0) ||
           (act_color==BLACK && figure>0))
        {
            continue;
        }

        figure=abs(figure);   // kind of figure only matters with pawns

        if (figure==W_PAWN) {
            //----------------------------------------
            // treatment of white pawn ...
            //----------------------------------------
            if (act_color==WHITE) {
                if (board[from+10]==EMPTY) {
                    if (from>=A7) {
                        PutPromotionOnStack(from,from+10);
                    }
                    else if (allmoves>0) {
                        PutMoveOnStack(from,from+10);
                        // double step possible ?
                        if (from<=H2 && board[from+20]==EMPTY) {
                            PutMoveOnStack(from,from+20);
                            // put move on stack have already incremented idx
                            move_stack[act_index-1].ep_field=from+10;
                        }
                    }
                }
                if (board[from+11]<0) { // pawn may kill black figure
                    if (from>=A7) {
                        PutPromotionOnStack(from,from+11);
                    }
                    else {
                        PutKillMoveOnStack(from,from+11);
                    }
                }

                if (board[from+9]<0) {  // other direction, too
                    if (from>=A7) {
                        PutPromotionOnStack(from,from+9);
                    }
                    else {
                        PutKillMoveOnStack(from,from+9);
                    }
                }
            }

            //----------------------------------------
            // treatment of black pawn ...
            //----------------------------------------
            else if (act_color==BLACK) {
                if (board[from-10]==EMPTY) {
                    if (from<=H2) {
                        PutPromotionOnStack(from,from-10);
                    }
                    else if(allmoves>0) {
                        PutMoveOnStack(from,from-10);
                        // double step possible?
                        if ((from>=A7)&&(board[from-20]==EMPTY)) {
                            PutMoveOnStack(from,from-20);
                            // putting move on stack already incremented idx
                            move_stack[act_index-1].ep_field=from-10;
                        }
                    }
                }
                // have to check for border just for black pawns
                if (board[from-11]>0 && board[from-11]!=OUTSIDE) {
                    if (from<=H2) {
                        PutPromotionOnStack(from,from-11);
                    }
                    else {
                        PutKillMoveOnStack(from,from-11);
                    }
                }
                if (board[from-9]>0 && board[from-9]!=OUTSIDE) {
                    if (from<=H2) {
                        PutPromotionOnStack(from,from-9);
                    }
                    else {
                        PutKillMoveOnStack(from,from-9);
                    }
                }
            }
            continue;   // continue with next field
        }

        //------------------------------------------------
        // moves of all other figures are calculated using
        // the move offset table
        //------------------------------------------------
        longstep=figure_offsets[figure].longmove;
        for (i=figure_offsets[figure].start;i<=figure_offsets[figure].end;i++) {
            direction = offset_vals[i];
            to        = from;
slideforward:
            to += direction;
            if (board[to]==EMPTY) {
                if (allmoves>0) {
                    PutMoveOnStack(from,to);
                }
                if (longstep) { // bishop/rook/queen
                    goto slideforward;
                }
                else {  // knight/king
                    continue;
                }
            }
            if (board[to]==OUTSIDE) {
                continue;
            }

            // there is a figure. check for right color ...
            if ((act_color==WHITE && board[to]<0) ||
                (act_color==BLACK && board[to]>0))
            {
                PutKillMoveOnStack(from,to);
            }
            continue;
        }
    }

    //-------------------------------
    // enpassant
    //-------------------------------
    if (ep_field[act_depth] != ILLEGAL) {
        epfield=ep_field[act_depth];
        if (act_color==WHITE) {
            if (board[epfield-9]==W_PAWN) {
                PutEpOnStack(epfield-9,epfield,epfield-10);
            }
            if (board[epfield-11]==W_PAWN) {
                PutEpOnStack(epfield-11,epfield,epfield-10);
            }
        }
        else {
            if (board[epfield+9]==B_PAWN) {
                PutEpOnStack(epfield+9,epfield,epfield+10);
            }
            if (board[epfield+11]==B_PAWN) {
                PutEpOnStack(epfield+11,epfield,epfield+10);
            }
        }
    }

    //-------------------------------
    // rochade
    //-------------------------------
    if (act_color==WHITE) {
        if (white_king_pos==E1 && (flags[act_depth] & (E1_MOVE_MASK | W_ROCHADE_MASK)) == 0) {
            if (board[H1]==W_ROOK                      &&
                (flags[act_depth] & H1_MOVE_MASK) == 0 &&
                board[F1]==EMPTY                       &&
                board[G1]==EMPTY                       &&
                !AttacksField(E1,BLACK)                &&
                !AttacksField(F1,BLACK)                &&
                !AttacksField(G1,BLACK))
            {
                PutMoveOnStack(E1,G1); // put king move on stack
                move_stack[act_index-1].rochade_nr=ROCHADE_SHORT;
            }
            if (board[A1]==W_ROOK                      &&
                (flags[act_depth] & A1_MOVE_MASK) == 0 &&
                board[D1]==EMPTY                       &&
                board[C1]==EMPTY                       &&
                board[B1]==EMPTY                       &&
                !AttacksField(E1,BLACK)                &&
                !AttacksField(D1,BLACK)                &&
                !AttacksField(C1,BLACK))
            {
                PutMoveOnStack(E1,C1); // put king move on stack
                move_stack[act_index-1].rochade_nr=ROCHADE_LONG;
            }
        }
    }
    else {
        if (black_king_pos==E8 && (flags[act_depth] & (E8_MOVE_MASK | B_ROCHADE_MASK)) == 0) {
            if (board[H8]==B_ROOK                      &&
                (flags[act_depth] & H8_MOVE_MASK) == 0 &&
                board[F8]==EMPTY                       &&
                board[G8]==EMPTY                       &&
                !AttacksField(E8,WHITE)                &&
                !AttacksField(F8,WHITE)                &&
                !AttacksField(G8,WHITE))
            {
                PutMoveOnStack(E8,G8); // put king move on stack
                move_stack[act_index-1].rochade_nr=ROCHADE_SHORT;
            }
            if (board[A8]==B_ROOK                      &&
                (flags[act_depth] & A8_MOVE_MASK) == 0 &&
                board[D8]==EMPTY                       &&
                board[C8]==EMPTY                       &&
                board[B8]==EMPTY                       &&
                !AttacksField(E8,WHITE)                &&
                !AttacksField(D8,WHITE)                &&
                !AttacksField(C8,WHITE))
            {
                PutMoveOnStack(E8,C8); // put king move on stack
                move_stack[act_index-1].rochade_nr=ROCHADE_LONG;
            }
        }
    }
    stack_ranges[act_depth+1]=act_index; // store end of range
}



/*===========================================================================*/
/* fills up:                                                                 */
/*                                                                           */
/* (1) p_controlled ...  fields controlled by pawns                          */
/* (2) p_per_column   ...  number of pawns on a line                         */
/* (3) r_per_column   ...  number of rooks on a line                         */
/*                                                                           */
/* (will be called by Evaluate() to initialize)                              */
/*===========================================================================*/
void InitPawnVars(void) {
    short i;
    char  figure;

    // reset all counters to zero
    memset(&p_controlled[A1],0,(H8-A1+1)*sizeof(bicolor_t));
    memset(p_per_column,0,(H_COLUMN+2)*sizeof(bicolor_t));
    memset(r_per_column,0,(H_COLUMN+2)*sizeof(bicolor_t));

    // evaluate new values
    for (i=A1;i<=H8;i++) {
        figure = board[i];

        switch(figure) {
            case EMPTY:   // fall through !!!
            case OUTSIDE: continue;
            case W_PAWN:
                p_controlled[i+9].white++;
                p_controlled[i+11].white++;
                p_per_column[i%10].white++;
                break;

            case B_PAWN:
                p_controlled[i-9].black++;
                p_controlled[i-11].black++;
                p_per_column[i%10].black++;
                break;

            case B_ROOK:
                r_per_column[i%10].black++;
                break;

            case W_ROOK:
                r_per_column[i%10].white++;
                break;

            default:
                break;
        }
    }
}



/*===========================================================================*/
/* calculates computer move. searching will be done iterative until          */
/* std_depth is reached.                                                     */
/*===========================================================================*/
move_t* ComputerMove(void) {
    short  distance,beta,i,value,bestvalue,j;
    short  alpha = 0;  // make -Wall happy ...
    short  chess_tmp;
    move_t tmp;
    char   s[100];

    if (already_mate) return 0;

    nr_nodes = 0;  // IS THIS NEW???


    // if the opening book finds a move to play -> play it
    //if (defaults.usebooks == OPTION_ON) {
    //    if (GetOpening()==TRUE) goto DoMov;
    //}

    InitTree();
    updatecounter = 0;
    abort_move    = FALSE;

    // evaluate initial position. if already mate -> stop
    value = Evaluate(act_color);
    if (value == VALUE_MATE) {
        already_mate = TRUE;
        return 0;
    }

    // store chess_indicator for stalemate state detection at the end
    chess_tmp=chess_indicator;

    // generate all pseudo legal moves
    GenerateMoves(1);

    //------------------------------------------------------------------------
    // possible later speedup: remove all illegal moves from the move stack ??
    //------------------------------------------------------------------------

    // iterative stepping down until std_depth is reached
    for (distance=1;distance<=std_depth;distance++) {
        // at act_depth 1 the alpha/beta window is completely open
        if(distance==1) {
            alpha = -VALUE_MATE;
            beta  =  VALUE_MATE;
        }
        // otherwise modify window a little bit
        else {
            beta  = alpha+100;
            alpha = alpha-100;
        }
        // search will be extended for chess and killing moves
        max_extend = distance+3;

        // initialize main variant
        main_var[act_depth][act_depth].from=0;

        //---------------------------------------------
        // execute move, evaluate move and take it back
        //---------------------------------------------
        ExecMove(0);
        value = -AlphaBetaSearch(-beta,-alpha,distance-1);
        UndoMove(0);
        if (abort_move) {
            abort_move = FALSE;
            return 0;
        }

        //----------------------------------------------------
        // we'll need an EXACT value of the first move on this
        // depth, so we can compare the other ones to this one
        // (first one will be used as bestvalue so far)
        //-----------------------------------------------------
        if (value<alpha) { // below lower border -> search again
            alpha         = -VALUE_MATE;
            beta          = value;
            ExecMove(0);
            value = -AlphaBetaSearch(-beta,-alpha,distance-1);
            UndoMove(0);
            if (abort_move) {
                abort_move = FALSE;
                return 0;
            }
        }
        else if(value>=beta) {  // higher than upper border -> search again
            alpha         = value;
            beta          = VALUE_MATE;
            ExecMove(0);
            value = -AlphaBetaSearch(-beta,-alpha,distance-1);
            UndoMove(0);
            if (abort_move) {
                abort_move = FALSE;
                return 0;
            }
        }

        //----------------------------------------------
        // chance that next move is better is really low
        // Null window is used for speedup
        //----------------------------------------------
        alpha = value;
        beta  = alpha+1;

        UpdateMoveDisplay(&move_stack[0],TRUE);
        CopyMainVariant(0);

        //------------------------------------------
        //evaluate all other moves on for this depth
        //------------------------------------------
        for (i=1;i<stack_ranges[1];i++) {
            // initialize main variant
            main_var[act_depth][act_depth].from=0;

            // execute move, evaluate move and take it back
            ExecMove(i);
            value = -AlphaBetaSearch(-beta,-alpha,distance-1);
            UndoMove(i);
            if (abort_move) {
                abort_move = FALSE;
                return 0;
            }

            //-----------------------------------------------
            // new best move found. calculate its exact value
            //-----------------------------------------------
            if (value>alpha) {
                //---------------------------
                // extend BETA to be open ...
                //---------------------------
                bestvalue = alpha;
                alpha     = value;
                beta      = VALUE_MATE;
                ExecMove(i);
                value = -AlphaBetaSearch(-beta,-alpha,distance-1);
                UndoMove(i);
                if (abort_move) {
                    abort_move = FALSE;
                    return 0;
                }
                //-------------------------------------------------
                // is the value now better than the original alpha?
                //-------------------------------------------------
                if (value>bestvalue) {
                    // new value as NULL window
                    alpha = value;
                    beta  = alpha+1;
                    UpdateMoveDisplay(&move_stack[i],TRUE);
                    CopyMainVariant(i);
                    //----------------------
                    // move best move on top
                    //----------------------
                    tmp=move_stack[i];
                    for (j=i;j>0;j--) {
                        move_stack[j] = move_stack[j-1];
                    }
                    move_stack[0]=tmp;
                }
            }
        }

    }  // end of for-loop !!

    if (alpha > -(VALUE_MATE-1)) {
        UpdateMoveDisplay(&move_stack[0],TRUE);

        ExecMove(0);
        flags[0] = flags[1];
        ep_field[0] = ep_field[1]; // ep_fix!!

        StoreMove(0);

        {
            short rep = CheckForRepetition(TRUE);
            if (rep != NO_REPETITION) {
                already_mate = TRUE;
                if (rep == REPETITION_FOUND) {
                   OutputSpecial(MSG_DRAWREPEAT1,MSG_DRAWREPEAT2);
                }
                else {
                   OutputSpecial(MSG_DRAW50PLY1,MSG_DRAW50PLY2);
                }
                return 0;
            }
        }

        if (alpha >= VALUE_MATE-10) {
            if (((VALUE_MATE-2-alpha)>>1) == 0) {
                already_mate = TRUE;
                OutputSpecial(MSG_CHECKMATEIWIN1,MSG_CHECKMATEIWIN2);
            }
            else {
                sprintf(s,MSG_YOUWILLLOSE2,(VALUE_MATE-2-alpha)>>1);
                OutputSpecial(MSG_YOUWILLLOSE1,s);
            }
        }
        else {
            if(alpha <= -VALUE_MATE+10) {
                sprintf(s,MSG_IWILLLOSE2,(alpha + VALUE_MATE -1)>>1);
                OutputSpecial(MSG_IWILLLOSE1,s);
            }
        }

        return &move_stack[0];
    }


    if (chess_tmp) {
        already_mate = TRUE;
        OutputSpecial(MSG_CHECKMATEYOUWIN1,MSG_CHECKMATEYOUWIN2);
    }
    else {
        already_mate = TRUE;
        OutputSpecial(MSG_STALEMATE1,MSG_STALEMATE2);
    }

    return 0;
}



/*===========================================================================*/
/* executes an user move                                                     */
/*===========================================================================*/
short UserMove(char* input,short updateboards,short level) {
    short  from,to;
    short  i,tmp;

    SetActiveInfo(act_color,level,updateboards);

    if (strlen(input)<4) return FALSE;

    from = Notation2Field(input);
    to   = Notation2Field(&input[2]);

    InitTree();

    GenerateMoves(1);

    // loop through all generated moves
    for (i=stack_ranges[0];i<stack_ranges[1];i++) {
        //---------------------------------------
        // we've found the corresponding move ...
        //---------------------------------------
        if (move_stack[i].from == from && move_stack[i].to == to) {
            if (move_stack[i].promoted_fig != EMPTY) {
                //-------------------------------------------------------
                // promotions are generated in the following order:
                // queen/knight/bishop/rook -> if we are not promoting to
                // queen we have to increment i !!
                //-------------------------------------------------------
                if (input[4]=='N')     i++;
                else if(input[4]=='B') i+=2;
                else if(input[4]=='R') i+=3;
            }

            tmp = last_move;
            ExecMove(i); // WARNING: will change color !!!

            //------------------------------------------------------
            // check if our king is still being attacked. if king is
            // under attack -> undo given move
            // NOTE: the reverse checking is necessary, because
            //       ExecMove() has changed the color already
            //------------------------------------------------------

            if (AttacksField((act_color==BLACK)?white_king_pos:black_king_pos,act_color)) {
                UndoMove(i);
                last_move=tmp;
                return FALSE;
            }

            //--------------------------
            // stores move in move_store
            //--------------------------
            flags[0] = flags[1];
            ep_field[0] = ep_field[1]; // ep_fix!!
            StoreMove(i);
            if (updateboards) UpdateMoveDisplay((move_t*)&move_store[moves_stored-1],FALSE);

            {
                short rep = CheckForRepetition(TRUE);
                if (rep != NO_REPETITION) {
                    already_mate = TRUE;
                    if (rep == REPETITION_FOUND) {
                        if (updateboards) OutputSpecial(MSG_DRAWREPEAT1,MSG_DRAWREPEAT2);
                    }
                    else {
                        if (updateboards) OutputSpecial(MSG_DRAW50PLY1,MSG_DRAW50PLY2);
                    }
                    return TRUE;
                }
            }

            /*if (twoplayer_mode)*/ {
                short found = FALSE;
                short check;

                InitTree();
                Evaluate(act_color);

                check = chess_indicator;

                GenerateMoves(1);

                // loop through all generated moves
                for (i=stack_ranges[0];i<stack_ranges[1];i++) {
                    ExecMove(i); // WARNING: will change color !!!
                    if (!AttacksField((act_color==BLACK)?white_king_pos:black_king_pos,act_color)) {
                        found = TRUE;
                        UndoMove(i);
                        break;
                    }
                    UndoMove(i);
                }

                if (!found) {
                    already_mate = TRUE;
                    if (updateboards) {
                        if (check) OutputSpecial(MSG_CHECKMATEIWIN1,MSG_CHECKMATEIWIN2);
                        else       OutputSpecial(MSG_STALEMATE1,MSG_STALEMATE2);
                    }
                }
                else {
                    if (updateboards) {
                        if (check) OutputSpecial(MSG_CHECK,"");
                    }
                }
                ep_field[1] = ep_field[0]; // ep_fix!!

            }

            return TRUE;
        }
    }

    return FALSE;  // haven't found move in generated move list
}


//#############################################################################
//###################### NO MORE FAKES BEYOND THIS LINE #######################
//#############################################################################
//
//=============================================================================
// Revision History
//=============================================================================
//
// $Log: engine.c,v $
// Revision 1.16  2004/08/06 13:49:34  DEBROUX Lionel
// generic commit
//
// Revision 1.15  2002/10/21 12:19:48  tnussb
// see changes for v3.99b in history.txt
//
// Revision 1.14  2002/10/17 11:30:56  tnussb
// changes due to new font graphics data retrieving by Lionel Debroux
// (the sprite data is fetched from the AMS)
//
// Revision 1.13  2002/10/16 18:28:51  tnussb
// changes related to the complete new puzzle file support (see history.txt)
//
// Revision 1.12  2002/10/14 12:49:49  tnussb
// calls to InitializeFastDraw() and CleanupFastDraw() added to memory
// initialization and cleanup functions
//
// Revision 1.11  2002/10/14 12:07:27  tnussb
// no longer include opening.c, because engine.c is build with enrolled loops!
//
// Revision 1.10  2002/10/08 17:44:29  tnussb
// changes related to v3.90/v3.91
//
// Revision 1.9  2002/09/13 10:20:00  tnussb
// changes related to opening book support (3.80 Beta)
//
// Revision 1.8  2002/03/01 17:29:03  tnussb
// changes due to multilanguage support
//
// Revision 1.7  2002/02/11 16:38:11  tnussb
// many changes due to "separate file compiling" restructuring
//
// Revision 1.6  2002/02/07 21:32:57  tnussb
// critical bugs if memory is running low fixed
//
// Revision 1.5  2002/02/07 11:39:45  tnussb
// changes for v3.50beta and v3.50 (see history.txt)
//
// Revision 1.4  2001/02/17 15:00:11  Thomas Nussbaumer
// changes due to new TIGCC version
//
// Revision 1.3  2000/12/19 13:55:29  Thomas Nussbaumer
// warnings stated by compiling with option -Wall fixed
//
// Revision 1.2  2000/08/12 15:31:12  Thomas Nussbaumer
// substitution keywords added
//
//
