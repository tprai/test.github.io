/******************************************************************************
*
* project name:    TI-Chess
* file name:       msg_german.h
* initial date:    28/02/2002
* author:          thomas.nussbaumer@gmx.net
* description:     german messages
*
* $Id: msg_german.h,v 1.8 2004/08/06 13:57:06 DEBROUX Lionel Exp $
*
******************************************************************************/

#ifndef MSG_GERMAN_H
#define MSG_GERMAN_H

//-----------------------------------------------------------------------------
// strings and constants for main menu (file: menu.c)
//-----------------------------------------------------------------------------
//#define MAIN_MENU_TI89  "New  Load/Save  Train  Options  Help About Exit"
#define MAIN_MENU_TI89    "Neu  Datei   Ueben  Optionen   Hilfe  Ueber  Ende"
//#define MAIN_MENU_TI92P " New       Load/Save        Train        Options        Help        About        Exit"
#define MAIN_MENU_TI92P   " Neu        Datei        Training        Optionen        Hilfe         Ueber        Ende"

//-----------------------------------------------------------------------------
// The following number pairs are used for highlighting the entries of the main
// menu. Make sure to adapt them correctly (file: menu.c)
//-----------------------------------------------------------------------------
//#define MAIN_MENU_COORDS_TI89   0,15, 19,55, 59,77, 81,105, 109,124, 126,145, 147,159
#define MAIN_MENU_COORDS_TI89     0,13, 17,34, 40,60, 64, 93,  99,115, 119,139, 143,159
//#define MAIN_MENU_COORDS_TI92P  2,17, 31,67, 83,101, 117,141, 157,172, 188,207, 223,236
#define MAIN_MENU_COORDS_TI92P    2,15, 31,48, 64, 92, 108,137, 153,169, 187,207, 223,239

//-----------------------------------------------------------------------------
// strings and constants for load/save menu (file: menu.c)
//-----------------------------------------------------------------------------
//#define LS_MENU_LOAD         "LOAD ticsave0"
#define LS_MENU_LOAD           "LADE ticsave0"
//#define LS_MENU_LOAD_IDX     12               // index of 0 in above string
#define LS_MENU_LOAD_IDX       12               // index of 0 in above string
//#define LS_MENU_SAVE         "SAVE ticsave1"
#define LS_MENU_SAVE           "SPEICHERE ticsave1"
//#define LS_MENU_SAVE_IDX     12               // index of 1 in above string
#define LS_MENU_SAVE_IDX       17               // index of 1 in above string
//#define LS_MENU_EXPORT       "EXPORT Game"
#define LS_MENU_EXPORT         "EXPORTIERE Spiel"
//#define LS_MENU_DIALOGWIDTH  52               // width of load/save menu
#define LS_MENU_DIALOGWIDTH    (52+4*5-1)       // width of load/save menu


//-----------------------------------------------------------------------------
// strings and constants for option menu (file: menu.c)
//-----------------------------------------------------------------------------
//#define OPTION_MENU_STRENGTH "Strength"
#define OPTION_MENU_STRENGTH   "Staerke"
//#define OPTION_MENU_AUTOLOAD "AutoLoad"
#define OPTION_MENU_AUTOLOAD   "Auto-Laden"
//#define OPTION_MENU_AUTOSAVE "AutoSave"
#define OPTION_MENU_AUTOSAVE   "Auto-Speichern"
//#define OPTION_MENU_HASING   "Hashing"
#define OPTION_MENU_HASING     "Hashing"
//#define OPTION_MENU_REQUESTS "Requests"
#define OPTION_MENU_REQUESTS   "Rueckfragen"
//#define OPTION_MENU_SAVEMVS  "Save Mvs"
#define OPTION_MENU_SAVEMVS    "Zuege speichern"
//#define OPTION_MENU_PIECESET "PieceSet"
#define OPTION_MENU_PIECESET   "Figuren-Set"
//#define OPTION_MENU_USEBOOK  "Use Books"
#define OPTION_MENU_USEBOOK    "Buch-Support"

//#define OPTION_MENU_ON       "ON"
#define OPTION_MENU_ON         "EIN"
//#define OPTION_MENU_OFF      "OFF"
#define OPTION_MENU_OFF        "AUS"

//#define OPTION_MENU_TEXTSTART2   37
#define OPTION_MENU_TEXTSTART2     60
//#define OPTION_MENU_DIALOGWIDTH  52
#define OPTION_MENU_DIALOGWIDTH    75

//-----------------------------------------------------------------------------
// help page definition for both calculator types (file: menu.c)
//-----------------------------------------------------------------------------
//#define HELP_PAGE_TI89  "[STO]",     "Load/Save Game",
//                        "[CATALOG]", "Change Sides",
//                        "[(][)]",    "Level Down/Up",
//                        "[0]",       "Automatic Play",
//                        "[BACK]",    "Take Back a Move",
//                        "[CLEAR]",   "Undo Take Back",
//                        "[HOME]",    "Rotate Board",
//                        "[2]",       "2-Player Mode",
//                        "[ENTER]",   "==[2ND]==[Y]",
//                        "[ESC]",     "==[N] or Main Menu",
//                        "[.]",       "Show Moves so Far",
//                        "[x]",       "Show Opening Moves",
//                        "[F5]",      "Boss Key (EXIT)",
//                        0
#define HELP_PAGE_TI89  "[STO]",     "Datei Menue",\
                        "[CATALOG]", "Seite wechseln",\
                        "[(][)]",    "Spielstaerke aendern",\
                        "[0]",       "Automatik-Modus",\
                        "[BACK]",    "Zug zuruecknehmen",\
                        "[CLEAR]",   "Zug wieder spielen",\
                        "[HOME]",    "Brett rotieren",\
                        "[2]",       "Spieleranzahl aendern",\
                        "[ENTER]",   "==[2ND]==[Y] = Ja",\
                        "[ESC]",     "==[N] oder Menue",\
                        "[.]",       "Zuege anzeigen",\
                        "[x]",       "Buchzuege zeigen",\
                        "[F5]",      "Quick-EXIT",\
                        0

//#define HELP_PAGE_TI92P "[STO]",       "Load/Save Game",
//                        "[C]",         "Change Sides",
//                        "[(][)]",      "Level Down/Up",
//                        "[A]",         "Toggle Automatic Play",
//                        "[BACK][B]",   "Take Back a Move",
//                        "[F]",         "Undo Take Back",
//                        "[R]",         "Rotate Board",
//                        "[2]",         "Toggle 2-Player Mode",
//                        "[F1]",        "==[ENTER]==[Y]",
//                        "[ESC]",       "==[N] or Main Menu",
//                        "[S]",         "Show Moves so Far",
//                        "[O]",         "Show Opening Moves",
//                        "[F5]",        "Boss Key (EXIT)",
//                        0
#define HELP_PAGE_TI92P "[STO]",       "Datei-Menue",\
                        "[C]",         "Seite wechseln",\
                        "[(][)]",      "Spielstaerke aendern",\
                        "[A]",         "Automatik-Modus",\
                        "[BACK][B]",   "Zug zuruecknehmen",\
                        "[F]",         "Zug wieder spielen",\
                        "[R]",         "Brett rotieren",\
                        "[2]",         "Spieleranzahl aendern",\
                        "[F1]",        "==[ENTER]==[Y] = Ja",\
                        "[ESC]",       "==[N] oder Menue",\
                        "[S]",         "Zuege anzeigen",\
                        "[O]",         "Buchzuege zeigen",\
                        "[F5]",        "Quick-EXIT",\
                        0

//-----------------------------------------------------------------------------
// additionally help string displayed on TI-92p calculators
// (file: bg_ti92.c)
//-----------------------------------------------------------------------------
//#define ADDITIONAL_HELP    "[Press H for Help, ESC for Menu]"
#define ADDITIONAL_HELP      "[H -> Hilfe / Esc -> Hauptmenue]"
//#define ADDITIONAL_HELP_X  125
#define ADDITIONAL_HELP_X    125
//#define ADDITIONAL_HELP_Y  120
#define ADDITIONAL_HELP_Y    120

//-----------------------------------------------------------------------------
// letters used for symbols
// I know 'B' for "Bauer" is not standard, but otherwise the display gets
// somewhat "awksome"
// (file: engine.c)
//-----------------------------------------------------------------------------
//#define FIGURE_SYMBOLS 'K','Q','N','B','R','P','.','P','R','B','N','Q','K'
#define FIGURE_SYMBOLS   'K','D','S','L','T','B','.','B','T','L','S','D','K'

//-----------------------------------------------------------------------------
// translations for move list (file: menu.c)
//-----------------------------------------------------------------------------
//#define MOVELIST_NOMOVES    "No moves stored. Sorry."
#define MOVELIST_NOMOVES      "Keine Zuege verfuegbar."
//#define MOVELIST_CONTINUE   "--- Continue with Listing ? ---"
#define MOVELIST_CONTINUE     "--- Weiter zur naechsten Seite ? ---"
//#define MOVELIST_ENDOFLIST  "--- End Of List ---"
#define MOVELIST_ENDOFLIST    "--- Ende der Liste ---"

//-----------------------------------------------------------------------------
// translations for training menu (file: menu.c/train.c)
//-----------------------------------------------------------------------------
//#define TRAIN_MENU_NOPUZZLES   "No TICPUZ-File found."
#define TRAIN_MENU_NOPUZZLES     "Kein TICPUZ-File gefunden."
//#define TRAIN_MENU_TURNWHITE   "Turn: WHITE"
#define TRAIN_MENU_TURNWHITE     "Am Zug: WEISS"
//#define TRAIN_MENU_TURNBLACK   "Turn: BLACK"
#define TRAIN_MENU_TURNBLACK     "Am Zug: SCHWARZ"


//-----------------------------------------------------------------------------
// translations for infoboards (file: infoboards.c)
//-----------------------------------------------------------------------------
//#define INFOBOARD_PLAYER "Player:"
#define INFOBOARD_PLAYER   "spielt:"
//#define INFOBOARD_HUMAN  "Human"
#define INFOBOARD_HUMAN    "Mensch"
//#define INFOBOARD_LAST   "Last:"
#define INFOBOARD_LAST     "Letzt:"
//#define INFOBOARD_BEST   "Best:"
#define INFOBOARD_BEST     "Best:"
//#define INFOBOARD_NODES  "Nodes:"
#define INFOBOARD_NODES    "Nodes:"
//#define INFOBOARD_BOOK   "Book: %d/%d"
#define INFOBOARD_BOOK     "Buch: %d/%d"

//-----------------------------------------------------------------------------
// translations for misc. messages
//-----------------------------------------------------------------------------
//#define MSG_DRAWREPEAT1      "Draw due to"
#define MSG_DRAWREPEAT1        "Remis durch"
//#define MSG_DRAWREPEAT2      "Repetition!"
#define MSG_DRAWREPEAT2        "Wiederholung!"
//#define MSG_DRAW50PLY1       "Draw due to"
#define MSG_DRAW50PLY1         "Remis durch"
//#define MSG_DRAW50PLY2       "50 Ply Rule!"
#define MSG_DRAW50PLY2         "50-Zugregel!"
//#define MSG_CHECKMATEIWIN1   "Checkmate!"
#define MSG_CHECKMATEIWIN1     "Schachmatt!"
//#define MSG_CHECKMATEIWIN2   "I win!"
#define MSG_CHECKMATEIWIN2     "Ich gewinne!"
//#define MSG_CHECKMATEYOUWIN1 "Checkmate!"
#define MSG_CHECKMATEYOUWIN1   "Schachmatt!"
//#define MSG_CHECKMATEYOUWIN2 "You win!"
#define MSG_CHECKMATEYOUWIN2   "Du gewinnst!"
//#define MSG_YOUWILLLOSE1     "You will loose"
#define MSG_YOUWILLLOSE1       "Du verlierst"
//#define MSG_YOUWILLLOSE2     "in %d mvs"
#define MSG_YOUWILLLOSE2       "in %d Zuegen"
//#define MSG_IWILLLOSE1       "I will loose"
#define MSG_IWILLLOSE1         "Ich verliere"
//#define MSG_IWILLLOSE2       "in %d mvs"
#define MSG_IWILLLOSE2         "in %d Zuegen"
//#define MSG_STALEMATE1       "Draw due to"
#define MSG_STALEMATE1         "Remis durch"
//#define MSG_STALEMATE2       "Stalemate!"
#define MSG_STALEMATE2         "Patt!"
//#define MSG_CHECK            "CHECK !!!"
#define MSG_CHECK              "SCHACH !!!"
//#define MSG_ABORT            "Abort (Y/N)?"
#define MSG_ABORT              "Abbrechen (Y/N)?"
//#define MSG_STARTAUTOMATIC   "Start Automatic (Y/N)?"
#define MSG_STARTAUTOMATIC     "Starte Automatik (Y/N)?"
//#define MSG_CHANGESIDES      "Change Sides (Y/N)?"
#define MSG_CHANGESIDES        "Seite wechseln (Y/N)?"
//#define MSG_ONEPLAYER        "ONE Player (Y/N)?"
#define MSG_ONEPLAYER          "EIN Spieler (Y/N)?"
//#define MSG_TWOPLAYER        "TWO player (Y/N)?"
#define MSG_TWOPLAYER          "ZWEI Spieler (Y/N)?"
//#define MSG_PROMOTETO        "Promote to:"
#define MSG_PROMOTETO          "Umwandlen in:"
//#define PROMOTE_CORRECTX     0
#define PROMOTE_CORRECTX       -5


//-----------------------------------------------------------------------------
// translations for string used in exported textfile (file: loadsave.c)
//-----------------------------------------------------------------------------
//#define EXPORTED_GAME       "Game"
#define EXPORTED_GAME         "Spiel"


//-----------------------------------------------------------------------------
// about menu translations (file: menu.c)
//-----------------------------------------------------------------------------
#define ABOUT_STR1  "Eine TI-Chess Team Produktion"
#define ABOUT_STR2  "Programmierung und Artwork"
#define ABOUT_STR3  "Thomas Nussbaumer"
#define ABOUT_STR4  "(thomas.nussbaumer@gmx.net)"
#define ABOUT_STR5  "und"
#define ABOUT_STR6  "Marcos Lopez"
#define ABOUT_STR7  "(marcos.lopez@gmx.net)"

#define MSG_INVALIDMOVE  "!! Ungueltige Eingabe !!"
#define MSG_INVALIDBOOKMOVE "!! Invalid Book Entry !!"


#endif

//#############################################################################
//###################### NO MORE FAKES BEYOND THIS LINE #######################
//#############################################################################
//
//=============================================================================
// Revision History
//=============================================================================
//
// $Log: msg_german.h,v $
// Revision 1.8  2004/08/06 13:57:06  DEBROUX Lionel
// generic commit
//
// Revision 1.7  2002/10/28 09:11:25  tnussb
// unnecessary comments removed
//
// Revision 1.6  2002/10/17 09:56:42  tnussb
// generic commit for v3.97
//
// Revision 1.5  2002/10/16 18:28:52  tnussb
// changes related to the complete new puzzle file support (see history.txt)
//
// Revision 1.4  2002/10/14 12:09:18  tnussb
// help text extended by "opening moves" key
//
// Revision 1.3  2002/10/08 17:44:30  tnussb
// changes related to v3.90/v3.91
//
// Revision 1.2  2002/08/01 12:46:40  tnussb
// generic commit (I don't know anymore what I have changed ..)
//
// Revision 1.1  2002/03/01 17:28:41  tnussb
// initial check-in
//
//
