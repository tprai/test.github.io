/******************************************************************************
*
* project name:    TI-Chess
* file name:       infoboards.c
* initial date:    12/07/2000
* authors:         thomas.nussbaumer@gmx.net (coding)
*                  marcos.lopez@gmx.net      (design/graphics/beta testing)
* description:     contains data output routines for info boards
*
* $Id: infoboards.c,v 1.9 2004/08/06 13:52:40 DEBROUX Lionel Exp $
*
*******************************************************************************/

#include "hardware.h"   // MUST BE ALWAYS HERE ON THE FIRST LINE !!!!
#include <graph.h>
#include <gray.h>
#include <string.h>
#include "generic.h"
#include "routines.h"

//------------------------------------------------------
// calculator depended definition of infoboard positions
//------------------------------------------------------
#define IBOARD_START_X    C89_92(104,154)
#define IBOARD_START_Y0   C89_92(57,65)
#define IBOARD_START_Y1   C89_92(12,20)



#define INFOBOARD_WIDTH  53
#define INFOBOARD_HEIGHT 30
#define INFO_OFFSET      23

#define REAL_PLAYER      -1



//-------------------------------
// default settings of infoboards
//-------------------------------
infoboard_t infos[2] = {
    {IBOARD_START_X,IBOARD_START_Y0,-1, "", "", "", ""}, // white
    {IBOARD_START_X,IBOARD_START_Y1, 0, "", "", "", ""}  // black
};



//------------------------------------
// name lookup for calculator strength
//------------------------------------
const char* levelnames[MAX_USERLEVEL] = {
 "Calc-L1","Calc-L2","Calc-L3","Calc-L4","Calc-L5"
};

short active_board = 0;   // the active board



//-------------------------------------------
// some forward declarations from other files
//-------------------------------------------
extern short already_mate;


/*===========================================================================*/
/* draws info board                                                          */
/*===========================================================================*/
void DrawInfoBoard(short nr) {
    short x,y;

    x = infos[nr].x;
    y = infos[nr].y;

    //-----------------------------------------------------------------
    // fills background of infoboard with lightgray and draws separator
    //-----------------------------------------------------------------
    DrawColorRect(x,y,x+INFOBOARD_WIDTH,y+INFOBOARD_HEIGHT,COLOR_LIGHTGRAY,RECT_FILLED);
    SetPlane(LIGHT_PLANE);
    DrawLine(x,y-1,x+INFOBOARD_WIDTH,y-1,A_NORMAL);                                    // top
    DrawLine(x,y+INFOBOARD_HEIGHT+1,x+INFOBOARD_WIDTH,y+INFOBOARD_HEIGHT+1,A_NORMAL);  // bottom
    DrawLine(x-1,y,x-1,y+INFOBOARD_HEIGHT,A_NORMAL);                                   // left
    DrawLine(x+INFOBOARD_WIDTH+1,y,x+INFOBOARD_WIDTH+1,y+INFOBOARD_HEIGHT,A_NORMAL);   // right
    SetPlane(DARK_PLANE);
    DrawPix(x-1,y+5,A_NORMAL);
    DrawPix(x+INFOBOARD_WIDTH+1,y+5,A_NORMAL);
    DrawLine(x,y+6,x+INFOBOARD_WIDTH,y+6,A_NORMAL);


    //--------------------------------------------
    // output information depending on player type
    //--------------------------------------------
    FontSetSys(F_4x6);
    DrawStr(x,y,INFOBOARD_PLAYER,A_NORMAL);
    if (infos[nr].player == REAL_PLAYER) {
       DrawStr(x+INFO_OFFSET+3,y,INFOBOARD_HUMAN,A_NORMAL);
       if (infos[nr].move[0]) {
           DrawStr(x,y+8,INFOBOARD_LAST,A_NORMAL);
           DrawStr(x+INFO_OFFSET,y+8,infos[nr].move,A_NORMAL);
       }
    }
    else {
       DrawStr(x+INFO_OFFSET+3,y,levelnames[infos[nr].player],A_NORMAL);

       if (infos[nr].move[0]) {
           if (nr==active_board) DrawStr(x,y+8,INFOBOARD_BEST,A_NORMAL);
           else                  DrawStr(x,y+8,INFOBOARD_LAST,A_NORMAL);
           DrawStr(x+INFO_OFFSET,y+8,infos[nr].move,A_NORMAL);
       }
       if (infos[nr].nodes[0]) {
           DrawStr(x,y+14,INFOBOARD_NODES,A_NORMAL);
           DrawStr(x+INFO_OFFSET,y+14,infos[nr].nodes,A_NORMAL);
       }
    }
    DrawStr(x,y+20,infos[nr].special1,A_NORMAL);
    DrawStr(x,y+26,infos[nr].special2,A_NORMAL);
}



/*===========================================================================*/
/* update the "BEST MOVE SO FAR" display                                     */
/*===========================================================================*/
void UpdateMoveDisplay(move_t* pmove,short fromboard) {
    short x = infos[active_board].x;
    short y = infos[active_board].y+8;

    sprintf(&(infos[active_board].move[0]),"%s",Move2Str(pmove,fromboard));

    //-------------------------------------------------------------------
    // fills background of movedisplay with lightgray and draws separator
    //-------------------------------------------------------------------
    DrawColorRect(x,y,x+INFOBOARD_WIDTH+1,y+5,COLOR_LIGHTGRAY,RECT_FILLED);

    SetPlane(DARK_PLANE);
    FontSetSys(F_4x6);
    DrawStr(x,y,INFOBOARD_BEST,A_NORMAL);
    DrawStr(x+INFO_OFFSET,y,infos[active_board].move,A_NORMAL);
}



/*===========================================================================*/
/* misuse the node display                                                   */
/*===========================================================================*/
void MisuseNodeDisplay(char* s) {
    short x,y;

    x = infos[active_board].x;
    y = infos[active_board].y+14;

    //-------------------------------------------------------------------
    // fills background of nodedisplay with lightgray and draws separator
    //-------------------------------------------------------------------
    DrawColorRect(x,y,x+INFOBOARD_WIDTH+1,y+5,COLOR_LIGHTGRAY,RECT_FILLED);

    SetPlane(DARK_PLANE);
    FontSetSys(F_4x6);
    DrawStr(x,y,s,A_NORMAL);
}


/*===========================================================================*/
/* updates node information                                                  */
/*===========================================================================*/
void UpdateNodeDisplay(long nodes) {
    short x,y;

    x = infos[active_board].x;
    y = infos[active_board].y+14;

    //-------------------------------------------------------------------
    // fills background of nodedisplay with lightgray and draws separator
    //-------------------------------------------------------------------
    DrawColorRect(x,y,x+INFOBOARD_WIDTH+1,y+5,COLOR_LIGHTGRAY,RECT_FILLED);

    sprintf(&(infos[active_board].nodes[0]),"%06ld",nodes);

    SetPlane(DARK_PLANE);
    FontSetSys(F_4x6);
    DrawStr(x,y,INFOBOARD_NODES,A_NORMAL);
    DrawStr(x+INFO_OFFSET,y,infos[active_board].nodes,A_NORMAL);
}



/*===========================================================================*/
/* sets data of active infoboard                                             */
/*===========================================================================*/
void SetActiveInfo(short color,short level,short redraw) {
    if (infos[0].player == REAL_PLAYER) infos[0].nodes[0] = 0;
    if (infos[1].player == REAL_PLAYER) infos[1].nodes[0] = 0;


    if (color == WHITE) active_board = 0;
    else                active_board = 1;

    if (level>=0) {
        infos[active_board].player = level-1;
    }
    else {
        infos[active_board].player   = REAL_PLAYER;
        infos[active_board].nodes[0] = 0;
    }

    if (!already_mate) {
        infos[active_board].special1[0] = 0;
        infos[active_board].special2[0] = 0;
    }

    if (redraw) {
        DrawInfoBoard(0);
        DrawInfoBoard(1);
    }
}



/*===========================================================================*/
/* output special text on active infoboard                                   */
/*===========================================================================*/
void OutputSpecial(const char* s1,const char* s2) {
    short x,y;

    x = infos[active_board].x;
    y = infos[active_board].y+20;

    if (s1) sprintf(&(infos[active_board].special1[0]),"%s",s1);
    if (s2) sprintf(&(infos[active_board].special2[0]),"%s",s2);

    //-------------------------------------------------------------------
    // fills background of movedisplay with lightgray and draws separator
    //-------------------------------------------------------------------
    DrawColorRect(x,y,x+INFOBOARD_WIDTH+1,y+5,COLOR_LIGHTGRAY,RECT_FILLED);
    SetPlane(DARK_PLANE);
    FontSetSys(F_4x6);
    DrawStr(x,y,infos[active_board].special1,A_NORMAL);
    y+=6;
    DrawColorRect(x,y,x+INFOBOARD_WIDTH,y+5,COLOR_LIGHTGRAY,RECT_FILLED);
    SetPlane(DARK_PLANE);
    DrawStr(x,y,infos[active_board].special2,A_NORMAL);
}



/*===========================================================================*/
/* switches positions of infoboards                                          */
/*===========================================================================*/
void SwitchInfoBoards(void) {
    short y = infos[0].y;

    infos[0].y = infos[1].y;
    infos[1].y = y;
    DrawInfoBoard(0);
    DrawInfoBoard(1);
}



/*===========================================================================*/
/* clears active infobard data                                               */
/*===========================================================================*/
void ClearActiveInfoBoardData(void) {
    infos[active_board].nodes[0]    = 0;
    infos[active_board].move[0]     = 0;
    infos[active_board].special1[0] = 0;
    infos[active_board].special2[0] = 0;
}



/*===========================================================================*/
/* clears move and node data                                                 */
/*===========================================================================*/
void ClearActiveMoveAndNodeInfoBoardData(void) {
    infos[active_board].nodes[0] = 0;
    infos[active_board].move[0]  = 0;
}



/*===========================================================================*/
/* clears data of infoboard                                                  */
/*===========================================================================*/
void ClearInfoBoardData(void) {
    short nr;

    for (nr=0;nr<2;nr++) {
        infos[nr].nodes[0]    = 0;
        infos[nr].move[0]     = 0;
        infos[nr].special1[0] = 0;
        infos[nr].special2[0] = 0;
    }
}



/*===========================================================================*/
/* initialize both infoboards                                                */
/*===========================================================================*/
void InitInfo(short color,short level1,short level2,short inverted) {
    if (infos[0].player == REAL_PLAYER) infos[0].nodes[0] = 0;
    if (infos[1].player == REAL_PLAYER) infos[1].nodes[0] = 0;

    if (color == WHITE) active_board = 0;
    else                active_board = 1;

    if (level1>=0) infos[0].player = level1-1;
    else {
        infos[0].player = REAL_PLAYER;
        infos[0].nodes[0] = 0;
    }

    if (level2>=0) infos[1].player = level2-1;
    else {
        infos[1].player = REAL_PLAYER;
        infos[1].nodes[0] = 0;
    }


    if (!already_mate) {
        infos[0].special1[0] = 0;
        infos[0].special2[0] = 0;
        infos[1].special1[0] = 0;
        infos[1].special2[0] = 0;
    }

    if (infos[inverted].y != IBOARD_START_Y0) {
        SwitchInfoBoards();
    }
    else {
        DrawInfoBoard(0);
        DrawInfoBoard(1);
    }
}


//#############################################################################
//###################### NO MORE FAKES BEYOND THIS LINE #######################
//#############################################################################
//
//=============================================================================
// Revision History
//=============================================================================
//
// $Log: infoboards.c,v $
// Revision 1.9  2004/08/06 13:52:40  DEBROUX Lionel
// generic commit
//
// Revision 1.8  2002/10/17 09:56:41  tnussb
// generic commit for v3.97
//
// Revision 1.7  2002/10/08 17:44:29  tnussb
// changes related to v3.90/v3.91
//
// Revision 1.6  2002/03/01 17:29:03  tnussb
// changes due to multilanguage support
//
// Revision 1.5  2002/02/11 16:38:11  tnussb
// many changes due to "separate file compiling" restructuring
//
// Revision 1.4  2001/02/17 15:00:11  Thomas Nussbaumer
// changes due to new TIGCC version
//
// Revision 1.3  2000/12/19 13:55:29  Thomas Nussbaumer
// warnings stated by compiling with option -Wall fixed
//
// Revision 1.2  2000/08/12 15:31:12  Thomas Nussbaumer
// substitution keywords added
//
