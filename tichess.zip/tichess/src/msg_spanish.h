/******************************************************************************
*
* project name:    TI-Chess
* file name:       msg_spanish.h
* initial date:    23/10/2002
* author:          marcos.lopez@gmx.net
* description:     spanish messages
*
* $Id: msg_spanish.h,v 1.2 2004/08/06 13:57:18 DEBROUX Lionel Exp $
*
******************************************************************************/

#ifndef MSG_SPANISH_H
#define MSG_SPANISH_H

//-----------------------------------------------------------------------------
// strings and constants for main menu (file: menu.c)
//-----------------------------------------------------------------------------
//#define MAIN_MENU_TI89  "New  Load/Save  Train  Options  Help About Exit"
#define MAIN_MENU_TI89    "Nuevo Guardar Probl Opciones Ayuda Info Salir"
//#define MAIN_MENU_TI92P " New       Load/Save        Train        Options        Help        About        Exit"
#define MAIN_MENU_TI92P   "   Nuevo   Cargar/Guardar   Problemas   Opciones   Ayuda   Info   Salir"

//-----------------------------------------------------------------------------
// The following number pairs are used for highlighting the entries of the main
// menu. Make sure to adapt them correctly (file: menu.c)
//-----------------------------------------------------------------------------
//#define MAIN_MENU_COORDS_TI89   0,15, 19,55,  59,77,  81,105, 109,124, 126,145, 147,159
#define MAIN_MENU_COORDS_TI89     0,21, 23,52,  54,73,  75,104, 106,126, 128,141, 143,159
//#define MAIN_MENU_COORDS_TI92P  2,17, 31,67, 83,101, 117,141, 157,172, 188,207, 223,236
#define MAIN_MENU_COORDS_TI92P    5,28, 32,91, 95,133, 137,168, 172,194, 198,213, 217,236

//-----------------------------------------------------------------------------
// strings and constants for load/save menu (file: menu.c)
//-----------------------------------------------------------------------------
//#define LS_MENU_LOAD         "LOAD ticsave0"
#define LS_MENU_LOAD           "CARGAR ticsave0"
//#define LS_MENU_LOAD_IDX     12               // index of 0 in above string
#define LS_MENU_LOAD_IDX       14               // index of 0 in above string
//#define LS_MENU_SAVE         "SAVE ticsave1"
#define LS_MENU_SAVE           "GUARDAR ticsave1"
//#define LS_MENU_SAVE_IDX     12               // index of 1 in above string
#define LS_MENU_SAVE_IDX       15               // index of 1 in above string
//#define LS_MENU_EXPORT       "EXPORT Game"
#define LS_MENU_EXPORT         "EXPORTAR Partida"
//#define LS_MENU_DIALOGWIDTH  52               // width of load/save menu
#define LS_MENU_DIALOGWIDTH    65               // width of load/save menu

//-----------------------------------------------------------------------------
// strings and constants for option menu (file: menu.c)
//-----------------------------------------------------------------------------
//#define OPTION_MENU_STRENGTH "Strength"
#define OPTION_MENU_STRENGTH   "Nivel"
//#define OPTION_MENU_AUTOLOAD "AutoLoad"
#define OPTION_MENU_AUTOLOAD   "AutoCargar"
//#define OPTION_MENU_AUTOSAVE "AutoSave"
#define OPTION_MENU_AUTOSAVE   "AutoGuardar"
//#define OPTION_MENU_HASING   "Hashing"
#define OPTION_MENU_HASING     "Usar Hashing"
//#define OPTION_MENU_REQUESTS "Requests"
#define OPTION_MENU_REQUESTS   "Confirmar"
//#define OPTION_MENU_SAVEMVS  "Save Mvs"
#define OPTION_MENU_SAVEMVS    "Guardar Movs"
//#define OPTION_MENU_PIECESET "PieceSet"
#define OPTION_MENU_PIECESET   "Graf Piezas"
//#define OPTION_MENU_USEBOOK  "Use Books"
#define OPTION_MENU_USEBOOK    "Usar Libros"
//#define OPTION_MENU_ON       "ON"
#define OPTION_MENU_ON         "SI"
//#define OPTION_MENU_OFF      "OFF"
#define OPTION_MENU_OFF        "NO"

//#define OPTION_MENU_TEXTSTART2   37
#define OPTION_MENU_TEXTSTART2     52
//#define OPTION_MENU_DIALOGWIDTH  52
#define OPTION_MENU_DIALOGWIDTH    64

//-----------------------------------------------------------------------------
// help page definition for both calculator types (file: menu.c)
//-----------------------------------------------------------------------------
//#define HELP_PAGE_TI89  "[STO]",     "Load/Save Game",
//                        "[CATALOG]", "Change Sides",
//                        "[(][)]",    "Level Down/Up",
//                        "[0]",       "Automatic Play",
//                        "[BACK]",    "Take Back a Move",
//                        "[CLEAR]",   "Undo Take Back",
//                        "[HOME]",    "Rotate Board",
//                        "[2]",       "2-Player Mode",
//                        "[ENTER]",   "==[2ND]==[Y]",
//                        "[ESC]",     "==[N] or Main Menu",
//                        "[.]",       "Show Moves so Far",
//                        "[x]",       "Show Opening Moves",
//                        "[F5]",      "Boss Key (EXIT)",
//                        0
#define HELP_PAGE_TI89  "[STO]",     "Cargar/Guardar Juego",\
                        "[CATALOG]", "Cambiar de Lado",\
                        "[(][)]",    "Nivel -/+",\
                        "[0]",       "Juego Automatico",\
                        "[BACK]",    "Movimiento Atras",\
                        "[CLEAR]",   "Anular Mov Atras",\
                        "[HOME]",    "Rotar Tablero",\
                        "[2]",       "Modo 2 Jugadores",\
                        "[ENTER]",   "==[2ND]==[Y]",\
                        "[ESC]",     "==[N] en Menu",\
                        "[.]",       "Mostrar Movimientos",\
                        "[x]",       "Mostrar Mov de Salida",\
                        "[F5]",      "Salir Inmediatamente",\
                        0

//#define HELP_PAGE_TI92P "[STO]",       "Load/Save Game",
//                        "[C]",         "Change Sides",
//                        "[(][)]",      "Level Down/Up",
//                        "[A]",         "Toggle Automatic Play",
//                        "[BACK][B]",   "Take Back a Move",
//                        "[F]",         "Undo Take Back",
//                        "[R]",         "Rotate Board",
//                        "[2]",         "Toggle 2-Player Mode",
//                        "[F1]",        "==[ENTER]==[Y]",
//                        "[ESC]",       "==[N] or Main Menu",
//                        "[S]",         "Show Moves so Far",
//                        "[O]",         "Show Opening Moves",
//                        "[F5]",        "Boss Key (EXIT)",
//                        0
#define HELP_PAGE_TI92P "[STO]",       "Cargar/Guardar Juego",\
                        "[C]",         "Cambiar de Lado",\
                        "[(][)]",      "Nivel -/+",\
                        "[A]",         "Juego Automatico",\
                        "[BACK][B]",   "Movimiento Atras",\
                        "[F]",         "Anular Mov Atras",\
                        "[R]",         "Rotar Tablero",\
                        "[2]",         "Modo 2 Jugadores",\
                        "[F1]",        "==[ENTER]==[Y]",\
                        "[ESC]",       "==[N] en Menu",\
                        "[S]",         "Mostrar Movimientos",\
                        "[O]",         "Mostrar Mov de Salida",\
                        "[F5]",        "Salir Inmediatamente",\
                        0

//-----------------------------------------------------------------------------
// additionally help string displayed on TI-92p calculators (on main screen)
// (file: bg_ti92.c)
//-----------------------------------------------------------------------------
//#define ADDITIONAL_HELP    "[Press H for Help, ESC for Menu]"
#define ADDITIONAL_HELP      "[ H para Ayuda, ESC para Menu ]"
//#define ADDITIONAL_HELP_X  125
#define ADDITIONAL_HELP_X    125
//#define ADDITIONAL_HELP_Y  120
#define ADDITIONAL_HELP_Y    120

//-----------------------------------------------------------------------------
// letters used for figures (don't replace the '.')
// (file: engine.c)
//-----------------------------------------------------------------------------
//#define FIGURE_SYMBOLS 'K','Q','N','B','R','P','.','P','R','B','N','Q','K'
#define FIGURE_SYMBOLS   'R','D','C','A','T','P','.','P','T','A','C','D','R'

//-----------------------------------------------------------------------------
// translations for move list (file: menu.c)
//-----------------------------------------------------------------------------
//#define MOVELIST_NOMOVES    "No moves stored. Sorry."
#define MOVELIST_NOMOVES    "Ningun movimiento almacenado"
//#define MOVELIST_CONTINUE   "--- Continue with Listing ? ---"
#define MOVELIST_CONTINUE   "--- Continuar Listado ? ---"
//#define MOVELIST_ENDOFLIST  "--- End Of List ---"
#define MOVELIST_ENDOFLIST  "--- Final de Lista ---"

//-----------------------------------------------------------------------------
// translations for training menu (file: menu.c)
//-----------------------------------------------------------------------------
//#define TRAIN_MENU_NOPUZZLES   "No TICPUZ-File found."
#define TRAIN_MENU_NOPUZZLES     "Ningun fichero TICPUZ."
//#define TRAIN_MENU_TURNWHITE   "Turn: WHITE"
#define TRAIN_MENU_TURNWHITE     "Juegan: BLANCAS"
//#define TRAIN_MENU_TURNBLACK   "Turn: BLACK"
#define TRAIN_MENU_TURNBLACK     "Juegan: NEGRAS"

//-----------------------------------------------------------------------------
// translations for infoboards (file: infoboards.c)
//-----------------------------------------------------------------------------
//#define INFOBOARD_PLAYER "Player:"
#define INFOBOARD_PLAYER   "Juega:"
//#define INFOBOARD_HUMAN  "Human"
#define INFOBOARD_HUMAN    "Humano"
//#define INFOBOARD_LAST   "Last:"
#define INFOBOARD_LAST     "Ult:"
//#define INFOBOARD_BEST   "Best:"
#define INFOBOARD_BEST     "Mejor"
//#define INFOBOARD_NODES  "Nodes:"
#define INFOBOARD_NODES    "Nodos:"
//#define INFOBOARD_BOOK   "Book: %d/%d"
#define INFOBOARD_BOOK     "Libro: %d/%d"

//-----------------------------------------------------------------------------
// translations for misc. messages
//-----------------------------------------------------------------------------
//#define MSG_DRAWREPEAT1      "Draw due to"
#define MSG_DRAWREPEAT1        "Empate por"
//#define MSG_DRAWREPEAT2      "Repetition!"
#define MSG_DRAWREPEAT2        "Repeticion!"
//#define MSG_DRAW50PLY1       "Draw due to"
#define MSG_DRAW50PLY1         "Empate por"
//#define MSG_DRAW50PLY2       "50 Ply Rule!"
#define MSG_DRAW50PLY2         "50 movs!"
//#define MSG_CHECKMATEIWIN1   "Checkmate!"
#define MSG_CHECKMATEIWIN1     "Jaque Mate!"
//#define MSG_CHECKMATEIWIN2   "I win!"
#define MSG_CHECKMATEIWIN2     "He ganado!"
//#define MSG_CHECKMATEYOUWIN1 "Checkmate!"
#define MSG_CHECKMATEYOUWIN1   "Jaque Mate!"
//#define MSG_CHECKMATEYOUWIN2 "You win!"
#define MSG_CHECKMATEYOUWIN2   "Ganaste!!"
//#define MSG_YOUWILLLOSE1     "You will loose"
#define MSG_YOUWILLLOSE1       "Vas a perder"
//#define MSG_YOUWILLLOSE2     "in %d mvs"
#define MSG_YOUWILLLOSE2       "en %d movs"
//#define MSG_IWILLLOSE1       "I will loose"
#define MSG_IWILLLOSE1         "VOy a perder"
//#define MSG_IWILLLOSE2       "in %d mvs"
#define MSG_IWILLLOSE2         "en %d movs"
//#define MSG_STALEMATE1       "Draw due to"
#define MSG_STALEMATE1         "Empate por"
//#define MSG_STALEMATE2       "Stalemate!"
#define MSG_STALEMATE2         "Tablas !!!"
//#define MSG_CHECK            "CHECK !!!"
#define MSG_CHECK              "JAQUE !!!"
//#define MSG_ABORT            "Abort (Y/N)?"
#define MSG_ABORT              "Cancelar (Y/N)?"
//#define MSG_STARTAUTOMATIC   "Start Automatic (Y/N)?"
#define MSG_STARTAUTOMATIC     "Juego Automatico (Y/N)?"
//#define MSG_CHANGESIDES      "Change Sides (Y/N)?"
#define MSG_CHANGESIDES        "Cambiar Lado (Y/N)?"
//#define MSG_ONEPLAYER        "ONE Player (Y/N)?"
#define MSG_ONEPLAYER          "UN Jugador (Y/N)?"
//#define MSG_TWOPLAYER        "TWO player (Y/N)?"
#define MSG_TWOPLAYER          "DOS Jugadores (Y/N)?"
//#define MSG_PROMOTETO        "Promote to:"
#define MSG_PROMOTETO          "Promocion:"
//#define PROMOTE_CORRECTX     0
#define PROMOTE_CORRECTX       0

//-----------------------------------------------------------------------------
// translations for string used in exported textfile (file: loadsave.c)
//-----------------------------------------------------------------------------
//#define EXPORTED_GAME       "Game"
#define EXPORTED_GAME         "Juego"


//-----------------------------------------------------------------------------
// about menu translations (file: menu.c)
//-----------------------------------------------------------------------------
//#define ABOUT_STR1  "A TI-Chess Team Production"
#define ABOUT_STR1  "Una Produccion del TI-Chess Team"
//#define ABOUT_STR2  "Programming and Artwork By"
#define ABOUT_STR2  "Programacion y Graficos Por"
#define ABOUT_STR3  "Thomas Nussbaumer"
#define ABOUT_STR4  "(thomas.nussbaumer@gmx.net)"
//#define ABOUT_STR5  "And"
#define ABOUT_STR5  "Y"
#define ABOUT_STR6  "Marcos Lopez"
#define ABOUT_STR7  "(marcos.lopez@gmx.net)"

//#define MSG_INVALIDMOVE "!! Invalid Move !!"
#define MSG_INVALIDMOVE "Movimiento Incorrecto !"
//#define MSG_INVALIDBOOKMOVE "!! Invalid Book Entry !!"
#define MSG_INVALIDBOOKMOVE "Mov Incorrecto en Libro !"

#endif

//#############################################################################
//###################### NO MORE FAKES BEYOND THIS LINE #######################
//#############################################################################
//
//=============================================================================
// Revision History
//=============================================================================
//
// $Log: msg_spanish.h,v $
// Revision 1.2  2004/08/06 13:57:18  DEBROUX Lionel
// generic commit
//
// Revision 1.1  2002/10/28 09:10:03  tnussb
// initial version (thanx Marcos!!)
//
//
//
