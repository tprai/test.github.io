/******************************************************************************
*
* project name:    TI-Chess
* file name:       defines.h
* initial date:    08/02/2002
* author:          thomas.nussbaumer@gmx.net
* description:     definitions and types used by TI-Chess
*
* $Id: defines.h,v 1.10 2004/08/06 13:48:50 DEBROUX Lionel Exp $
*
******************************************************************************/

#ifndef TICDEFINES_H
#define TICDEFINES_H

#include <vat.h> // for HANDLE typedef

//-----------------------------------------------------------------------------
// converts 4 character into an unsigned long (nice macro for magic markers)
//-----------------------------------------------------------------------------
#define C4UL(a,b,c,d)   ((((unsigned long)(a)) << 24) | \
                         (((unsigned long)(b)) << 16) | \
                         (((unsigned long)(c)) <<  8) | \
                         (((unsigned long)(d))))




//-----------------------------------------------------------------------------
// We need some additionally memory for grayscale planes and for our configfile
//-----------------------------------------------------------------------------
#define SIZE_OF_RESERVED_MEMORY (1024+(2*LCD_SIZE+8))


//-----------------------------------------------------------------------------
// calculator strength setting (don't modify this !!)
//-----------------------------------------------------------------------------
#define MAX_USERLEVEL 5       // external level 4
#define STD_USERLEVEL 1       // external level 0
#define MIN_USERLEVEL 1       // external level 0

#define HUMAN_LEVEL   -1      // side to play is a human


//-----------------------------------------------------------------------------
// generic constants
//-----------------------------------------------------------------------------
#define BOARD_SIZE   120     // dimension of extended chess board
#define MAX_DEPTH     20     // maximum search depth
#define NR_DIRS       16     // number of directions of all figures
#define NR_FIGS        7     // number of different figures (including NONE)
#define STACK_SIZE  1000     // size of move stack


//-----------------------------------------------------------------------------
// figure constants
//-----------------------------------------------------------------------------
#define B_KING     -6   // black figures (negative values)
#define B_QUEEN    -5
#define B_KNIGHT   -4
#define B_BISHOP   -3
#define B_ROOK     -2
#define B_PAWN     -1
#define EMPTY       0   // empty field
#define W_PAWN      1   // white figures (positive values)
#define W_ROOK      2
#define W_BISHOP    3
#define W_KNIGHT    4
#define W_QUEEN     5
#define W_KING      6
#define OUTSIDE   100   // outside real board


//-----------------------------------------------------------------------------
// figure values
//-----------------------------------------------------------------------------
#define VALUE_PAWN        100
#define VALUE_ROOK        500
#define VALUE_BISHOP      350
#define VALUE_KNIGHT      325
#define VALUE_QUEEN       900
#define VALUE_KING          0
#define VALUE_MATE      32000
#define MAX_POS         32000


//-----------------------------------------------------------------------------
// bonus values for main variant and killer moves
//-----------------------------------------------------------------------------
#define HVARBONUS         500
#define KILLER1BONUS      250
#define KILLER2BONUS      150


//-----------------------------------------------------------------------------
// maximum value of materials
//-----------------------------------------------------------------------------
#define VALUE_MAX     ((4*(VALUE_ROOK+VALUE_BISHOP+VALUE_KNIGHT))+(2*VALUE_QUEEN))
#define VALUE_ENDGAME (4*VALUE_ROOK+(2*VALUE_BISHOP))


//-----------------------------------------------------------------------------
// field names (increasing readability)
//-----------------------------------------------------------------------------
#define  A1    21
#define  B1    22
#define  C1    23
#define  D1    24
#define  E1    25
#define  F1    26
#define  G1    27
#define  H1    28
#define  A2    31
#define  B2    32
#define  C2    33
#define  D2    34
#define  E2    35
#define  F2    36
#define  G2    37
#define  H2    38
#define  A3    41
#define  B3    42
#define  C3    43
#define  D3    44
#define  E3    45
#define  F3    46
#define  G3    47
#define  H3    48
#define  A4    51
#define  B4    52
#define  C4    53
#define  D4    54
#define  E4    55
#define  F4    56
#define  G4    57
#define  H4    58
#define  A5    61
#define  B5    62
#define  C5    63
#define  D5    64
#define  E5    65
#define  F5    66
#define  G5    67
#define  H5    68
#define  A6    71
#define  B6    72
#define  C6    73
#define  D6    74
#define  E6    75
#define  F6    76
#define  G6    77
#define  H6    78
#define  A7    81
#define  B7    82
#define  C7    83
#define  D7    84
#define  E7    85
#define  F7    86
#define  G7    87
#define  H7    88
#define  A8    91
#define  B8    92
#define  C8    93
#define  D8    94
#define  E8    95
#define  F8    96
#define  G8    97
#define  H8    98


//-----------------------------------------------------------------------------
// line and column names
//-----------------------------------------------------------------------------
#define A_COLUMN   1
#define B_COLUMN   2
#define C_COLUMN   3
#define D_COLUMN   4
#define E_COLUMN   5
#define F_COLUMN   6
#define G_COLUMN   7
#define H_COLUMN   8
#define ROW_1      2
#define ROW_2      3
#define ROW_3      4
#define ROW_4      5
#define ROW_5      6
#define ROW_6      7
#define ROW_7      8
#define ROW_8      9


//-----------------------------------------------------------------------------
// castling defines
//-----------------------------------------------------------------------------
#define ROCHADE_NONE  0
#define ROCHADE_SHORT 1
#define ROCHADE_LONG  2


//-----------------------------------------------------------------------------
// color defines
//-----------------------------------------------------------------------------
#define WHITE    1
#define BLACK   -1


//-----------------------------------------------------------------------------
// logic values
//-----------------------------------------------------------------------------
#define TRUE           1
#define FALSE          0
#define LEGAL          1
#define ILLEGAL        0
#define OK             1


//-----------------------------------------------------------------------------
// data type for hashcodes (unsigned 64-bit)
//-----------------------------------------------------------------------------
typedef unsigned long long hash_t;


//-----------------------------------------------------------------------------
// data type for move stack
//-----------------------------------------------------------------------------
typedef struct {
   char  from;           // from field
   char  to;             // to field
   char  killed_fig;     // killed figure
   char  promoted_fig;   // promoted figure
   char  rochade_nr;     // kind of rochade
   char  ep_field;       // enpassant field
   short value;          // value for move sorting
   unsigned char count;  // count for 50 ply rule
                         // No pawn moved or figure
                         // captured
                         // NOTE: 0x80 will be used
                         // for side marking
   unsigned char unused; // unused - but for padding
} move_t;


//-----------------------------------------------------------------------------
// data type for stored moves (extended move_t)
//-----------------------------------------------------------------------------
typedef struct {
   char  from;           // from field
   char  to;             // to field
   char  killed_fig;     // killed figure
   char  promoted_fig;   // promoted figure
   char  rochade_nr;     // kind of rochade
   char  ep_field;       // enpassant field
   short value;          // value for move sorting
   unsigned char count;  // count for 50 ply rule
                         // No pawn moved or figure
                         // captured
                         // NOTE: 0x80 will be used
                         // for side marking
   char figure;          // for display moves
                         // OVERLAPS WITH UNUSED
   unsigned short flags; // system flags
   short  sum;           // stores material sum
   short  bal;           // stores material balance
   short  epfield;       // stores epfield
   hash_t key;           // for repetition checking
} store_t;


//-----------------------------------------------------------------------------
// index of figures in offset list and long/short marker (used by move gen.)
//-----------------------------------------------------------------------------
typedef struct {
   char start;
   char end;
   char longmove;
} figoffset_t;


//-----------------------------------------------------------------------------
// information about pawn/figure constellation
//-----------------------------------------------------------------------------
typedef struct {
   char white;
   char black;
} bicolor_t;


//-----------------------------------------------------------------------------
// information about from/to field
//-----------------------------------------------------------------------------
typedef struct {
   char from;
   char to;
} fromto_t;


//-----------------------------------------------------------------------------
// data structure for killer moves
//-----------------------------------------------------------------------------
typedef struct {
   fromto_t killer1;
   fromto_t killer2;
} killer_t;



//-----------------------------------------------------------------------------
// data structure of an hashtable entry
//-----------------------------------------------------------------------------
typedef struct {
    hash_t        key;    // hashcode of position (64bit)
    short         val;    // calculated value (16bit)
} hentry_t;

#define MAX_MOVES_STORED    330   // size of move store
                                  // this have to be a minimum of
                                  // 101 + MAX_MOVES_REMOVED to make sure the
                                  // that the 50 ply (100 moves) rule may
                                  // work correctly
#define MAX_MOVES_REMOVED    30   // size of removed moves if too much moves

#define HASHSIZE 1024  // size of a hashtable (2 are used)
                       // MUST BE A POWER OF 2 !!!

#define B1_MOVE_MASK      0x0001
#define C1_MOVE_MASK      0x0002
#define F1_MOVE_MASK      0x0004
#define G1_MOVE_MASK      0x0008
#define W_ROCHADE_MASK    0x0010

#define B8_MOVE_MASK      0x0020
#define C8_MOVE_MASK      0x0040
#define F8_MOVE_MASK      0x0080
#define G8_MOVE_MASK      0x0100
#define B_ROCHADE_MASK    0x0200

#define E1_MOVE_MASK      0x0400
#define E8_MOVE_MASK      0x0800

#define A1_MOVE_MASK      0x1000
#define H1_MOVE_MASK      0x2000
#define A8_MOVE_MASK      0x4000
#define H8_MOVE_MASK      0x8000

#define INIT_SYSTEM_FLAGS 0x0000


//-----------------------------------------------------------------------------
// data type for default settings and displayed menus
//-----------------------------------------------------------------------------
typedef struct {
    unsigned long  magic;
    unsigned char  strength;   // default strength
    unsigned char  autoload;   // autoload feature
    unsigned char  autosave;   // autosave feature
    unsigned char  hashtables; // hashtable usage
    unsigned char  firsttime;  // PREVIOUSLY saved?
    unsigned char  requests;
    unsigned char  savemoves;
    unsigned char  pieceset;
    unsigned char  usebooks;
    unsigned char  not_used;
    unsigned short active_puzzle;
} defaults_t;


#define OPTION_ON  0
#define OPTION_OFF 1


//-----------------------------------------------------------------------------
// defines for main menu entries
//-----------------------------------------------------------------------------
#define MENU_NONE        -1  // not a real index !!
#define MENU_NEW          0
#define MENU_LOADSAVE     1
#define MENU_TRAIN        2
#define MENU_SETTINGS     3
#define MENU_HELP         4
#define MENU_ABOUT        5
#define MENU_EXIT         6
#define MENU_CMD_LOAD    98  // not a real index !!
#define MENU_CMD_SAVE    99  // not a real index !!
#define MENU_CMD_EXPORT 100  // not a real index !!
#define MENU_SHOWMOVES  101  // not a real index !!



//-----------------------------------------------------------------------------
// defines for chess puzzles
//-----------------------------------------------------------------------------
#define SIZE_PUZZLETEXT 32
#define SIZE_PUZZLE     (22+7*2)


//-----------------------------------------------------------------------------
// structure for an infoboard
//-----------------------------------------------------------------------------
typedef struct {
    short x;            // x position of infoboard
    short y;            // y position of infoboard
    short player;       // type of player information
    char  nodes[10];    // node counter information
    char  move[20];     // best/last move
    char  special1[25]; // special text1
    char  special2[25]; // special text2
} infoboard_t;


//-----------------------------------------------------------------------------
// structure for file
//-----------------------------------------------------------------------------
typedef struct {
    unsigned short flags;
    char           name[9];
    char           folder[9];
    unsigned char* start; // pointer to start (first byte of length)
    unsigned long  magic; // magic to check for ...
    HANDLE         handle;
} ticfile_t;

#define TICFILE_NOTUSED     0
#define TICFILE_OPEN        1
#define TICFILE_LOCKEDBYME  2
#define TICFILE_ISARCHIVED  4

#define MAGIC_NOMAGIC        0
#define MAGIC_CONFIGFILE     C4UL('C','F','G','1')
#define MAGIC_BOOK_WHITE     C4UL('B','K','W','0')
#define MAGIC_BOOK_BLACK     C4UL('B','K','B','0')
#define MAGIC_SAVEFILE       C4UL('S','A','V','1')
#define MAGIC_PUZZLEFILE     C4UL('P','U','Z','1')

#define TICFILE_NAME_FOLDER   "tict"
#define TICFILE_NAME_CONFIG   "ticcfg"
#define TICFILE_NAME_EXPORT   "ticexpt"
#define TICFILE_NAME_SAVE0    "ticsave0"
#define TICFILE_NAME_SAVE1    "ticsave1"
#define TICFILE_NAME_SAVE2    "ticsave2"
#define TICFILE_NAME_SAVE3    "ticsave3"


//-----------------------------------------------------------------------------
// structure for opening books
//-----------------------------------------------------------------------------
typedef struct {
    unsigned short  nr_pos;         // number of positions in opening book
    unsigned short  nr_moves;       // number of continuation moves in book
    hash_t          first_hashcode; // first hashcode in opening book
    hash_t          last_hashcode;  // last hashcode in opening book
} openingbook_t;

#define MAX_BOOKS_USED 10   // each side may have that much books!
#define WHITEBOOK      0    // type of opening book (a white book)
#define BLACKBOOK      1    // type of opening book (a black book)

#define MAX_PUZZLES_USED 10

#endif


//#############################################################################
//###################### NO MORE FAKES BEYOND THIS LINE #######################
//#############################################################################
//
//=============================================================================
// Revision History
//=============================================================================
//
// $Log: defines.h,v $
// Revision 1.10  2004/08/06 13:48:50  DEBROUX Lionel
// generic commit
//
// Revision 1.9  2002/10/28 09:10:59  tnussb
// magic of savefiles changed, because now also the side to move gets stored
//
// Revision 1.8  2002/10/21 18:06:18  tnussb
// commenting style changed
//
// Revision 1.7  2002/10/18 16:03:54  tnussb
// see history.txt for v3.98b
//
// Revision 1.6  2002/10/16 18:28:51  tnussb
// changes related to the complete new puzzle file support (see history.txt)
//
// Revision 1.5  2002/10/11 13:22:09  tnussb
// magic markers of opening books changed
//
// Revision 1.4  2002/10/10 13:19:30  tnussb
// changes related to new chess puzzle format
//
// Revision 1.3  2002/10/08 17:44:29  tnussb
// changes related to v3.90/v3.91
//
// Revision 1.2  2002/09/13 10:20:00  tnussb
// changes related to opening book support (3.80 Beta)
//
// Revision 1.1  2002/02/11 16:34:07  tnussb
// initial version
//
//
