/******************************************************************************
*
* project name:    TI-Chess
* file name:       waitms.c
* initial date:    27/07/2000
* authors:         thomas.nussbaumer@gmx.net (coding)
*                  marcos.lopez@gmx.net      (design/graphics/beta testing)
* description:     utility function which "waits" a given number of
*                  milliseconds
*
* $Id: waitms.c,v 1.6 2004/08/06 14:01:23 DEBROUX Lionel Exp $
*
*******************************************************************************/

#ifndef WAIT_FOR_MILLIS_C
#define WAIT_FOR_MILLIS_C

/*===========================================================================*/
/* "waits" a given number of milliseconds (dummy looping)                    */
/* NOTE: this wait loop is parametrized to fit on HW1 calculators            */
/*===========================================================================*/

void WaitForMillis(register unsigned short asm("%d2"));

asm("xdef WaitForMillis\n"
"WaitForMillis:  move.l %d3,-(%sp)\n"
"           moveq  #31,%d1\n"
"           moveq  #31,%d3\n"
"_wl2_:     move.w #120,%d0    /* modify this value for exact timing !!! */\n"
"_wl1_:     rol.l  %d3,%d1\n"
"           dbf    %d0,_wl1_\n"
"           dbf    %d2,_wl2_\n"
"           move.l (%sp)+,%d3\n"
"           rts");


#endif

//#############################################################################
//###################### NO MORE FAKES BEYOND THIS LINE #######################
//#############################################################################
//
//=============================================================================
// Revision History
//=============================================================================
//
// $Log: waitms.c,v $
// Revision 1.6  2004/08/06 14:01:23  DEBROUX Lionel
// switched to __regparm__
//
// Revision 1.5  2002/02/11 16:38:12  tnussb
// many changes due to "separate file compiling" restructuring
//
// Revision 1.4  2002/02/07 11:39:46  tnussb
// changes for v3.50beta and v3.50 (see history.txt)
//
// Revision 1.3  2001/02/17 15:00:11  Thomas Nussbaumer
// changes due to new TIGCC version
//
// Revision 1.2  2000/08/12 15:31:13  Thomas Nussbaumer
// substitution keywords added
//
//
