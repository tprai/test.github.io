/******************************************************************************
*
* project name:    TI-Chess
* file name:       loadsave.c
* initial date:    19/03/2000
* authors:         thomas.nussbaumer@gmx.net (coding)
*                  marcos.lopez@gmx.net      (design/graphics/beta testing)
* description:     contains load/save routines
*
* $Id: loadsave.c,v 1.16 2004/08/06 13:55:01 DEBROUX Lionel Exp $
*
******************************************************************************/

// TODO: rewrite all this working but poor code with VAT functions ?

#include "hardware.h"  // MUST BE ALWAYS HERE ON THE FIRST LINE !!!!
#include <vat.h>
#include <math.h>
#include <alloc.h>
#include <stdio.h>
#include <string.h>
#include "version.h"
#include "routines.h"


//-----------------------------------------------------------------------------
// declarations of the necessary "external" variables
//-----------------------------------------------------------------------------
extern short          updatecounter;
extern short          already_mate;
extern char*          board;
extern short*         ep_field;
extern short*         stack_ranges;
extern short*         material_bal;
extern short*         material_sum;
extern short          white_king_pos;
extern short          black_king_pos;
extern short          act_color;
extern short          act_depth;
extern long           nr_nodes;
extern unsigned short move_count;
extern short          moves_stored;
extern short          moves_forward;
extern unsigned short flags[MAX_DEPTH];
extern defaults_t     defaults;
extern store_t*       move_store;
extern const char     fig_symbols[NR_FIGS*2-1];
extern const short    fig_values[NR_FIGS];
extern short          loadsave_idx;
extern short          twoplayer_mode;


/*===========================================================================*/
/* sets various engine parameters (used for game/puzzle loading)             */
/*===========================================================================*/
void SetupVariousEngineParams(void) {
    short i;
    short          content;
    unsigned short abs_val;

    material_sum[0] = 0;
    material_bal[0] = 0;

    for (i=A1;i<=H8;i++) {
       content = board[i];

       if (content == OUTSIDE || content == EMPTY) continue;

       if (content == W_KING) white_king_pos = i;
       if (content == B_KING) black_king_pos = i;

       abs_val = abs(content);
       if (content < 0) material_bal[0] -= fig_values[abs_val];
       else             material_bal[0] += fig_values[abs_val];

       if (abs_val == W_PAWN) continue;
       material_sum[0] += fig_values[abs_val];
    }

    if (act_color == BLACK) material_bal[0] = -material_bal[0];

    already_mate    = FALSE;
    updatecounter   = 0;
    moves_stored    = 0;
    moves_forward   = 0;
    act_depth       = 0;
    stack_ranges[0] = 0;
    nr_nodes        = 0;

    CalcHashKey();
    InitPawnVars();
    ResetHashCounters();
}


#include "train.c"


/*===========================================================================*/
/* generates TIOS filename from C string                                     */
/* returns pointer to end of TIOS filename                                   */
/*===========================================================================*/
char* GenerateTIOSName(const char* cname,char* buffer) {
    buffer[0] = 0;
    return (strcpy(buffer + 1, cname) + strlen(cname));
}


/*===========================================================================*/
/* returns SYM_ENTRY pointer of symbol specified by given name               */
/* NOTE: name can be of any kind (C or TIOS). if name[0] is 0 this routine   */
/*       believes its a tios name otherwise its a C name.                    */
/*===========================================================================*/
static SYM_ENTRY* GetSymByName(const char* name) {
    char buf[50];
    HSym hs;

    if (*name) hs = SymFind(GenerateTIOSName(name,buf));  /* cname    */
    else       hs = SymFind(name);                        /* tiosname */

    if (!hs.folder) return NULL;
    else            return DerefSym(hs);
}


/*===========================================================================*/
/* check if folder TICT folder exists. otherwise try to create it            */
/*===========================================================================*/
short CheckAndCreateTICFolder(void) {
    char  buf[50];
    char* tiosname = GenerateTIOSName(TICFILE_NAME_FOLDER,buf);

    if (SymFindHome(tiosname).folder) return 1; // ok - already exists

    if (!FolderAdd(tiosname)) return 0; // creation failed
    return 1;
}


/*===========================================================================*/
/* close a TICFile                                                           */
/*===========================================================================*/
void CloseTICFile(ticfile_t* f) {
    if (f->flags & TICFILE_OPEN) {
        if (f->flags & TICFILE_LOCKEDBYME) HeapUnlock(f->handle);
    }
    f->flags  = TICFILE_NOTUSED;
    f->handle = 0;
    f->start  = 0;
}


/*===========================================================================*/
/* opens TICFile. return 1 if successfully opened                            */
/*===========================================================================*/
short OpenTICFile(ticfile_t* f) {
    SYM_ENTRY*     symptr;
    unsigned char* tmp;
    unsigned char  buffer[50];

    sprintf(buffer,"%s\\%s",f->folder,f->name);
    symptr = GetSymByName(buffer);

    f->flags = TICFILE_NOTUSED;

    if (!symptr || !(symptr->handle) || symptr->flags.bits.twin) return 0;

    f->flags = TICFILE_OPEN;
    if (symptr->flags.bits.archived) f->flags |= TICFILE_ISARCHIVED;

    f->handle = symptr->handle;

    if (HeapGetLock(f->handle)) {
        f->start = HeapDeref(f->handle);
    }
    else {
        f->start = HLock(f->handle);
        f->flags |= TICFILE_LOCKEDBYME;
    }

    // check magic if wanted
    if (f->magic != MAGIC_NOMAGIC) {
        if (*(unsigned long*)(f->start+2) != f->magic) {
            CloseTICFile(f);
            return 0;
        }
    }

    tmp = f->start + *(unsigned short*)(f->start) + 1;

    if (*tmp     == 0xF8 &&
        *(tmp-5) == 't'  &&
        *(tmp-4) == 'i'  &&
        *(tmp-3) == 'c'  &&
        *(tmp-2) == 't')
    {
        return 1;
    }

    CloseTICFile(f);
    return 0;
}


/*===========================================================================*/
/* Find and open a list of TIC-Files (traverses the complete VAT)            */
/*                                                                           */
/* returns number of found files (up to maxfiles)                            */
/*===========================================================================*/
short FindAndOpenTICFiles(ticfile_t* f,short maxfiles,unsigned long magic) {
    SYM_ENTRY*      symptr;
    unsigned char*  start;
    unsigned char*  tmp;
    short           found = 0;

    //-------------------------------------------------------------------------
    // traverse complete VAT to find specified files
    //-------------------------------------------------------------------------
    symptr = SymFindFirst(NULL,2);
    while (symptr) {
        if (symptr->handle) {
            start = HeapDeref(symptr->handle);
            if (start) {
                tmp = start + *(unsigned short*)(start) + 1;
                // check for OTH-Type and extension 'tict'
                if (*tmp     == 0xF8 &&
                    *(tmp-5) == 't'  &&
                    *(tmp-4) == 'i'  &&
                    *(tmp-3) == 'c'  &&
                    *(tmp-2) == 't')
                {
                    // check magic if wanted
                    if (magic != MAGIC_NOMAGIC) {
                        if (*(unsigned long*)(start+2) != magic) {
                            symptr = SymFindNext();
                            continue;
                        }
                    }

                    // set flags and open
                    f->flags = TICFILE_OPEN;
                    f->handle = symptr->handle;
                    f->magic  = magic;

                    if (symptr->flags.bits.archived) f->flags |= TICFILE_ISARCHIVED;

                    if (HeapGetLock(f->handle)) {
                        f->start = HeapDeref(f->handle);
                    }
                    else {
                        f->start = HLock(f->handle);
                        f->flags |= TICFILE_LOCKEDBYME;
                    }

                    strncpy(f->name,symptr->name,8);
                    strncpy(f->folder,SymFindFolderName(),8);
                    f->name[8]   = 0;
                    f->folder[8] = 0;
                    found++;
                    f++;
                    if (found == maxfiles) return found;
                }
            }
        }
        symptr = SymFindNext();
    }

    return found;
}


/*===========================================================================*/
/* writes extension "tict" to file                                           */
/*===========================================================================*/
static unsigned short WriteTICTExtension(FILE* fp) {
    unsigned char ext[7] = { 0,'t','i','c','t',0,0xf8 };

    return fwrite(ext,7,1,fp);
}


/*===========================================================================*/
/* converts a compressed move to a string for UserMove() (buffer .. char[6]) */
/*===========================================================================*/
void CompressedMove2String(unsigned short move,char* buffer) {
   unsigned short from  = move & 0x3f;
   unsigned short to    = (move >> 6) & 0x3f;
   unsigned short prom  = (move >> 12) & 0x7;

   buffer[0] = (from%8) + 'A';
   buffer[1] = (from/8) + '1';
   buffer[2] = (to%8)   + 'A';
   buffer[3] = (to/8)   + '1';
   buffer[5] = 0;

   switch(prom) {
       case 1:  buffer[4] = 'Q'; break;
       case 2:  buffer[4] = 'R'; break;
       case 3:  buffer[4] = 'B'; break;
       case 4:  buffer[4] = 'N'; break;
       default: buffer[4] = 0;   break;
   }
}


/*===========================================================================*/
/* generates compressed move                                                 */
/*===========================================================================*/
unsigned short GenerateCompressedMove(char from,char to, char promote) {
   unsigned short result;

   from -= 21;
   from = (from/10)*8 + (from%10);
   to   -= 21;
   to   = (to/10)*8 + (to%10);

   result = from;
   result |= ((unsigned short)to)<<6;

   switch(promote) {
       case W_QUEEN:  result |= 0x1 << 12; break;
       case W_ROOK:   result |= 0x2 << 12; break;
       case W_BISHOP: result |= 0x3 << 12; break;
       case W_KNIGHT: result |= 0x4 << 12; break;
       default:       break;
   }

   return result;
}


/*===========================================================================*/
/* if automatic == TRUE: uses ticsave0 for loading                           */
/* else                  uses name from load/save menu                       */
/*===========================================================================*/
short HandleLoad(short automatic) {
    ticfile_t      file;
    unsigned char  use      = 0;
    unsigned short nr_moves = 0;
    unsigned char* varptr;
    unsigned short i;
    short          idx;
    unsigned char  lo;
    unsigned char  hi;
    unsigned char* name;

    file.flags = TICFILE_NOTUSED;

    if (!automatic) use = loadsave_idx;

    switch(use) {
        case 1:  name = (char*)TICFILE_NAME_SAVE1; break;
        case 2:  name = (char*)TICFILE_NAME_SAVE2; break;
        case 3:  name = (char*)TICFILE_NAME_SAVE3; break;
        default: name = (char*)TICFILE_NAME_SAVE0; break;
    }

    strcpy(file.name,name);
    strcpy(file.folder,TICFILE_NAME_FOLDER);

    file.magic = MAGIC_SAVEFILE;

    if (!OpenTICFile(&file)) return FALSE;

    varptr = file.start+6;  // skip length and magic marker

    nr_moves = *(unsigned short*)varptr;
    varptr+=2;

    // read in the position ...
    idx = A1;
    for (i=0;i<32;i++,varptr++) {
        hi = (*varptr & 0xf0) >> 4;
        lo = (*varptr & 0x0f);

        if (hi > 6) board[idx] = ((char)hi) - 13;
        else        board[idx] = ((char)hi);
        idx++;
        if (lo > 6) board[idx] = ((char)lo) - 13;
        else        board[idx] = ((char)lo);
        idx++;
        if (idx%10==9) idx+=2;
    }

    move_count  = *(unsigned short*)varptr;
    varptr+=2;
    flags[0]    = *(unsigned short*)varptr;
    varptr+=2;
    ep_field[0] = ep_field[1] = *(unsigned short*)varptr;
    varptr+=2;

    // side to move is stored as most significant bit in move count
    if (move_count & 0x8000) act_color = BLACK;
    else                     act_color = WHITE;

    // delete the most significant bit if set
    move_count &= 0x7fff;

    SetupVariousEngineParams();

    if (nr_moves > 0) {
        char m_t[6];
        for (i=0;i<nr_moves;i++) {
            unsigned short compressed = *(unsigned short*)varptr;
            CompressedMove2String(compressed,m_t);
            varptr+=2;
            if (i < nr_moves-1) UserMove(m_t,FALSE,HUMAN_LEVEL);
            else {
                twoplayer_mode = TRUE;
                UserMove(m_t,TRUE,HUMAN_LEVEL);
                twoplayer_mode = FALSE;
            }
        }
    }

    CloseTICFile(&file);
    return TRUE;
}



/*===========================================================================*/
/* if auto == TRUE: uses ticsave0 for saving                                 */
/* else             uses savename from loadsave menu                         */
/*===========================================================================*/
short HandleSave(short automatic) {
    FILE*         fp;
    char*         filename;
    char          use = 3;
    unsigned long magic = MAGIC_SAVEFILE;
    short         moves;
    short         i;
    char          lo,hi;

    if (!automatic) use = loadsave_idx - 4;

    switch(use) {
        case 0:  filename = (char*)TICFILE_NAME_FOLDER"\\"TICFILE_NAME_SAVE1; break;
        case 1:  filename = (char*)TICFILE_NAME_FOLDER"\\"TICFILE_NAME_SAVE2; break;
        case 2:  filename = (char*)TICFILE_NAME_FOLDER"\\"TICFILE_NAME_SAVE3; break;
        default: filename = (char*)TICFILE_NAME_FOLDER"\\"TICFILE_NAME_SAVE0; break;
    }

    if (!CheckAndCreateTICFolder()) return FALSE;
    if (!(fp = fopen(filename,"wb"))) return FALSE;

    fwrite(&magic,4,1,fp);

    if (defaults.savemoves == OPTION_ON) {
        moves = moves_stored;
    }
    else {
        moves = 0;
    }

    fputc(moves >> 8,fp);
    fputc(moves & 0xff,fp);

    if (defaults.savemoves == OPTION_ON) {
        // take back all stored moves and save initial position
        while (moves_stored > 0) TakeBackMove(TRUE);
    }

    for (i=A1;i<H8;i+=2) {
        if (board[i] == OUTSIDE) continue;
        hi = board[i];
        lo = board[i+1];
        if (lo<0) lo += 13;
        if (hi<0) hi += 13;
        fputc(((hi & 0x0f) << 4) | (lo & 0x0f),fp);
    }

    // store the side to move as most significant bit in move count
    if (act_color == WHITE) move_count &= 0x7fff;
    else                    move_count |= 0x8000;

    fputc(move_count >> 8,fp);
    fputc(move_count & 0xff,fp);
    fputc(flags[0] >> 8,fp);
    fputc(flags[0] & 0xff,fp);
    fputc(ep_field[0] >> 8,fp);
    fputc(ep_field[0] & 0xff,fp);

    if (defaults.savemoves == OPTION_ON) {
        while (moves > 0) {
            UndoTakeBackMove(TRUE);
            moves--;
        }

        for (i=0;i<moves_stored;i++) {
            unsigned short compressed = GenerateCompressedMove(move_store[i].from,
                                                               move_store[i].to,
                                                               move_store[i].promoted_fig);
            fputc(compressed >> 8,fp);
            fputc(compressed & 0xff,fp);
        }
    }

    WriteTICTExtension(fp);

    if (fp->flags & _F_ERR) {
        fclose(fp);
        remove(filename);
        ForceRequestDialog("FATAL: saving failed!");
    }
    else {
        fclose(fp);
    }

    return TRUE;
}


/*===========================================================================*/
/* ConfigFile HANDLING                                                       */
/*===========================================================================*/

defaults_t default_defaults = { MAGIC_CONFIGFILE, // magic marker
                                STD_USERLEVEL-1,  // strength
                                OPTION_ON,        // autoload
                                OPTION_ON,        // autosave
                                OPTION_ON,        // hashtables
                                OPTION_ON,        // firsttime
                                OPTION_ON,        // requests
                                OPTION_ON,        // save moves
                                OPTION_ON,        // default pieceset
                                OPTION_ON,        // use book
                                0,                // not used
                                1};               // active_book


ticfile_t cfgfile = {TICFILE_NOTUSED,{0},{0},0,MAGIC_CONFIGFILE,0};


/*===========================================================================*/
/* load defaults from String variable "ticcfg"                               */
/*===========================================================================*/
short LoadDefaults(void) {
    strcpy(cfgfile.name,TICFILE_NAME_CONFIG);
    strcpy(cfgfile.folder,TICFILE_NAME_FOLDER);
    if (OpenTICFile(&cfgfile)) {
        memcpy(&defaults,cfgfile.start+2,sizeof(defaults_t));
        CloseTICFile(&cfgfile);
        return TRUE;
    }

    memcpy(&defaults,&default_defaults,sizeof(defaults_t));
    SaveDefaults();
    return FALSE;
}


/*===========================================================================*/
/* save defaults to String variable "ticcfg"                                 */
/*===========================================================================*/
void SaveDefaults(void) {
    FILE* fp;

    strcpy(cfgfile.name,TICFILE_NAME_CONFIG);
    strcpy(cfgfile.folder,TICFILE_NAME_FOLDER);

    defaults.active_puzzle = puzzle_active;

    if (OpenTICFile(&cfgfile)) {
        if (!(cfgfile.flags & TICFILE_ISARCHIVED)) {
            memcpy(cfgfile.start+2,&defaults,sizeof(defaults_t));
        }
        CloseTICFile(&cfgfile);
        return;
    }

    if (!CheckAndCreateTICFolder()) return;
    if (!(fp = fopen(TICFILE_NAME_FOLDER"\\"TICFILE_NAME_CONFIG,"wb"))) return;

    fwrite(&defaults,sizeof(defaults_t),1,fp);
    WriteTICTExtension(fp);
    fclose(fp);
}


/*===========================================================================*/
/* list all stored moves so far                                              */
/*===========================================================================*/
void HandleExport(void) {
    short i  = 0;
    short mv = move_count-moves_stored;
    FILE* fp;

    //if (isArchived($(ticexpt))) return;   // <-- TIGCC 0.7 won't guess LOCK mode !!


    // check if there are any moves to export -> otherwise return immediately
    if (moves_stored == 0) return;

    // try to open export file for writing

    if (!CheckAndCreateTICFolder()) return;
    if (!(fp = fopen(TICFILE_NAME_FOLDER"\\"TICFILE_NAME_EXPORT,"w"))) return;

    fputs("[TI-Chess "TIC_VERSION_MAIN" "EXPORTED_GAME"\n",fp);

    if (mv % 2 == 1) {
        fprintf(fp,"[%03d] ...... %s\n",mv+1,Move2Str((move_t*)&move_store[0],FALSE));
        i = 1;
    }

    for (;i<moves_stored;i+=2) {
        fprintf(fp,"[%03d] %s  ",mv+i+1,Move2Str((move_t*)&move_store[i],FALSE));
        if (i+1 < moves_stored) {
            fputs(Move2Str((move_t*)&move_store[i+1],FALSE),fp);
        }
        fputc('\n',fp);
    }

    fclose(fp);
}



//#############################################################################
//###################### NO MORE FAKES BEYOND THIS LINE #######################
//#############################################################################
//
//=============================================================================
// Revision History
//=============================================================================
//
// $Log: loadsave.c,v $
// Revision 1.16  2004/08/06 13:55:01  DEBROUX Lionel
// generic commit
//
// Revision 1.15  2002/10/28 09:13:01  tnussb
// load and save side to move in savefiles now
//
// Revision 1.14  2002/10/21 18:07:01  tnussb
// perform_checks removed from OpenTICFile()
//
// Revision 1.13  2002/10/18 16:03:54  tnussb
// see history.txt for v3.98b
//
// Revision 1.12  2002/10/16 20:42:03  tnussb
// missing white_king_pos and black_king_pos initialization after reading
// a puzzle added
//
// Revision 1.11  2002/10/16 18:28:51  tnussb
// changes related to the complete new puzzle file support (see history.txt)
//
// Revision 1.10  2002/10/10 13:19:30  tnussb
// changes related to new chess puzzle format
//
// Revision 1.9  2002/10/08 17:44:29  tnussb
// changes related to v3.90/v3.91
//
// Revision 1.8  2002/03/01 17:29:04  tnussb
// changes due to multilanguage support
//
// Revision 1.7  2002/02/11 16:38:12  tnussb
// many changes due to "separate file compiling" restructuring
//
// Revision 1.6  2002/02/07 21:32:58  tnussb
// critical bugs if memory is running low fixed
//
// Revision 1.5  2001/02/17 15:00:11  Thomas Nussbaumer
// changes due to new TIGCC version
//
// Revision 1.4  2000/12/19 13:55:29  Thomas Nussbaumer
// warnings stated by compiling with option -Wall fixed
//
// Revision 1.3  2000/12/09 15:37:23  Thomas Nussbaumer
// defaults loading and saving completely rewritten
//
// Revision 1.2  2000/08/12 15:31:13  Thomas Nussbaumer
// substitution keywords added
//
//
