/******************************************************************************
*
* project name:    TI-Chess
* file name:       input.c
* initial date:    12/07/2000
* authors:         thomas.nussbaumer@gmx.net (coding)
*                  marcos.lopez@gmx.net      (design/graphics/beta testing)
* description:     input handling routine
*
* $Id: input.c,v 1.13 2004/08/06 13:53:23 DEBROUX Lionel Exp $
*
******************************************************************************/

//-----------------------------------------------------------------------------
// One major problem is that the keyboard of the TI calculators is NOT
// unbounced! So don't believe in short transitions !!
//
// We fix this by reducing the maximum user input rate. A short delay at the
// end of GetUserInput should work fine.
//-----------------------------------------------------------------------------

#include "hardware.h"    // MUST BE ALWAYS HERE ON THE FIRST LINE !!!!
#include <gray.h>
#include <system.h>

#include "tichess.h"
#include "interrupt.h"
#include "input.h"

#include "routines.h"

extern short already_mate;
extern short is_hw1_calc;
extern volatile unsigned short do_reset;

#include "waitms.c"

//------------------------------------------------
// this value is used to delay the user input rate
//------------------------------------------------
#define ECHO_PREVENTION_DELAY 150


#if defined(USE_TI89)

/*===========================================================================*/
/* returns own keycode or 0 (TI89 version)                                   */
/*                                                                           */
/* used keys:                                                                */
/*                                                                           */
/* ESC/N         ... NO on dialogs                                           */
/*                   deselect piece                                          */
/*                   open and close menu                                     */
/*                   stop computer move                                      */
/*                   break autoplay                                          */
/* ENTER/2ND/Y   ... YES on dialogs                                          */
/*                   select piece                                            */
/*                   open and close menu                                     */
/* ON            ... turn off calculator                                     */
/* CLEAR         ... forward again one move                                  */
/* BACKSPACE     ... back one move                                           */
/* CATALOG       ... change sides                                            */
/* HOME          ... rotate board                                            */
/* STO           ... open load/save menu                                     */
/* F5            ... exit program immediately without any further requests   */
/*                   this can be seen as "boss" or "teacher" key             */
/* 2             ... 2 player mode on/off                                    */
/* 0             ... automatic mode                                          */
/* F1            ... help screen                                             */
/* PLUS          ... contrast up                                             */
/* MINUS         ... contrast down                                           */
/* (             ... level down                                              */
/* )             ... level up                                                */
/* DOT           ... show stored moves                                       */
/*                                                                           */
/*===========================================================================*/
short KeyPressed(void) {
    //-----------------------------------------------------------
    // immediately return if F5 is pressed (MUST BE TESTED FIRST)
    //-----------------------------------------------------------
    if (KEYPRESS_F5) return KEY_EXIT;

    // test for KEY_ESCAPE (== NO to questions)
    if (KEYPRESS_ESC || KEYPRESS_N) return KEY_ESCAPE;

    // contrast keys (before we test 2ND alone !!!)
    if (KEYPRESS_CONTRASTUP) return KEY_CONTRASTUP;
    if (KEYPRESS_CONTRASTDN) return KEY_CONTRASTDN;

    // test for KEY_ENTER (== YES to questions)
    if (KEYPRESS_ENTER || KEYPRESS_2ND || KEYPRESS_Y) return KEY_ENTER;

    // cursor keys
    if (KEYPRESS_LEFT)  return KEY_MLEFT;
    if (KEYPRESS_RIGHT) return KEY_MRIGHT;
    if (KEYPRESS_UP)    return KEY_MUP;
    if (KEYPRESS_DOWN)  return KEY_MDOWN;

    // test for KEY_OFF
    if (KEYPRESS_OFF)  return KEY_OFF;

    // test for KEY_BACK
    if (KEYPRESS_BACK) return KEY_BACK;

    // test for KEY_FORWARD
    if (KEYPRESS_CLEAR) return KEY_FORWARD;

    // test for KEY_CHANGESIDE
    if (KEYPRESS_CAT) return KEY_CHANGESIDE;

    // test for KEY_ROTATE
    if (KEYPRESS_HOME) return KEY_ROTATE;

    // test for KEY_LOADSAVE
    if (KEYPRESS_STO) return KEY_LOADSAVE;

    // test for KEY_LEVELUP
    if (KEYPRESS_CBRACKET) return KEY_LEVELUP;

    // test for KEY_LEVELDOWN
    if (KEYPRESS_OBRACKET) return KEY_LEVELDOWN;

    // test for KEY_TWOPLAYER
    if (KEYPRESS_2) return KEY_TWOPLAYER;

    // test for KEY_HELP
    if (KEYPRESS_F1) return KEY_HELP;

    // test for KEY_AUTOMATIC
    if (KEYPRESS_0) return KEY_AUTOMATIC;

    // test for KEY_SHOWMOVES
    if  (KEYPRESS_DOT) return KEY_SHOWMOVES;

    if (KEYPRESS_X) return KEY_OPENINGMOVES;

#if ENABLE_TESTKEY
    if (KEYPRESS_EQUAL) return KEY_TESTING;
#endif

    return 0;
}

#else

/*===========================================================================*/
/* returns own keycode or 0 (TI92p version)                                  */
/*                                                                           */
/* used keys:                                                                */
/*                                                                           */
/* ESC/N         ... NO on dialogs                                           */
/*                   deselect piece                                          */
/*                   open and close menu                                     */
/*                   stop computer move                                      */
/*                   break autoplay                                          */
/* F1/ENTER/Y    ... YES on dialogs                                          */
/*                   select piece                                            */
/*                   open and close menu                                     */
/* ON            ... turn off calculator                                     */
/* F             ... forward again one move                                  */
/* BACKSPACE/B   ... back one move                                           */
/* C             ... change sides                                            */
/* R             ... rotate board                                            */
/* STO           ... open load/save menu                                     */
/* F5            ... exit program immediately without any further requests   */
/*                   this can be seen as "boss" or "teacher" key             */
/* 2             ... 2 player mode on/off                                    */
/* A             ... automatic mode                                          */
/* H             ... help screen                                             */
/* PLUS          ... contrast up                                             */
/* MINUS         ... contrast down                                           */
/* (             ... level down                                              */
/* )             ... level up                                                */
/* S             ... show stored moves                                       */
/*                                                                           */
/*===========================================================================*/
short KeyPressed(void) {
    //-----------------------------------------------------------
    // immediately return if F5 is pressed (MUST BE TESTED FIRST)
    //-----------------------------------------------------------
    if (KEYPRESS_F5) return KEY_EXIT;

    // test for KEY_ESCAPE (== NO to questions)
    if (KEYPRESS_ESC || KEYPRESS_N) return KEY_ESCAPE;

    // test for KEY_OFF
    if (KEYPRESS_OFF)  return KEY_OFF;

    // contrast keys (before we test 2ND alone !!!)
    if (KEYPRESS_CONTRASTUP) return KEY_CONTRASTUP;
    if (KEYPRESS_CONTRASTDN) return KEY_CONTRASTDN;

    // test for KEY_ENTER (== YES to questions)
    if (KEYPRESS_ENTER1 || KEYPRESS_ENTER2 || KEYPRESS_F1 || KEYPRESS_Y) return KEY_ENTER;

    // cursor keys
    if (KEYPRESS_LEFT)  return KEY_MLEFT;
    if (KEYPRESS_RIGHT) return KEY_MRIGHT;
    if (KEYPRESS_UP)    return KEY_MUP;
    if (KEYPRESS_DOWN)  return KEY_MDOWN;

    // test for KEY_BACK
    if (KEYPRESS_BACK || KEYPRESS_B) return KEY_BACK;

    // test for KEY_FORWARD
    if (KEYPRESS_F) return KEY_FORWARD;

    // test for KEY_CHANGESIDE
    if (KEYPRESS_C) return KEY_CHANGESIDE;

    // test for KEY_ROTATE
    if (KEYPRESS_R) return KEY_ROTATE;

    // test for KEY_LOADSAVE
    if (KEYPRESS_STO) return KEY_LOADSAVE;

    // test for KEY_LEVELUP
    if (KEYPRESS_CBRACKET) return KEY_LEVELUP;

    // test for KEY_LEVELDOWN
    if (KEYPRESS_OBRACKET) return KEY_LEVELDOWN;

    // test for KEY_TWOPLAYER
    if (KEYPRESS_2) return KEY_TWOPLAYER;

    // test for KEY_HELP
    if (KEYPRESS_H || KEYPRESS_F2) return KEY_HELP;

    // test for KEY_AUTOMATIC
    if (KEYPRESS_A) return KEY_AUTOMATIC;

    // test for KEY_SHOWMOVES
    if (KEYPRESS_S) return KEY_SHOWMOVES;

    if (KEYPRESS_O) return KEY_OPENINGMOVES;

#if ENABLE_TESTKEY
    if (KEYPRESS_EQUAL) return KEY_TESTING;
#endif

    return 0;
}
#endif



/*===========================================================================*/
/* get input key pressed by user                                             */
/*                                                                           */
/* replacement for ngetchx() and/or GKeyIn(), because:                       */
/*                                                                           */
/* (1) ngetchx() won't check the APD timer value                             */
/* (2) GKeyIn() destroys the display due to setting the status display       */
/*                                                                           */
/* This routine depends on an own keyboard handler which can be found in     */
/* file interrupt.c.                                                         */
/* This handler just detects transitions from "not pressed" to "pressed" and */
/* stores them in a global array.                                            */
/*                                                                           */
/* Due to the fact that the keyboard of the TI calculators is NOT unbounced  */
/* (especially on HW2 calculators) we will delay the return of this function */
/* about a small amount to get rid of keypress echos.                        */
/*===========================================================================*/
short GetUserInput(short inc_clock) {
    short key;

    //-------------------------------------------
    // restart the APD timer now
    //-------------------------------------------
    OSTimerRestart(APD_TIMER);

    while (1) {
        //---------------------------------------
        // wait until we get a key
        // if the APD timer expires -> turn
        // calculator off
        //---------------------------------------
        while (!(key = KeyPressed())) {
            if (OSTimerExpired(APD_TIMER)) {
                off();
                OSTimerRestart(APD_TIMER);
            }

            //--------------------------------------
            // handling of clock increment if wanted
            //--------------------------------------
            if (inc_clock && !already_mate) {
                if (OSTimerExpired(USER_TIMER)) IncrementClock();
            }
        }

        //-------------------------------------------------
        // only do the echo prevention delay on HW versions
        // larger than 1
        //-------------------------------------------------
        if (!is_hw1_calc) WaitForMillis(ECHO_PREVENTION_DELAY);

        //------------------------------------------
        // handle boss key first - dont remove it !!
        //------------------------------------------
        if (key == KEY_EXIT) return KEY_EXIT;

        ClearKeyBuffer();

        //---------------------------------------
        // handle calculator-off key combinations
        // if the APD timer expires -> turn
        // calculator off
        //---------------------------------------
        if (key == KEY_OFF) {
            off();
            OSTimerRestart(APD_TIMER);
        }

        //---------------------------------------
        // handle contrast up and down key combos
        //---------------------------------------
        else if (key == KEY_CONTRASTUP) {
            OSContrastUp();
            WaitForMillis(250);
        }
        else if (key == KEY_CONTRASTDN) {
            OSContrastDn();
            WaitForMillis(250);
        }
        else {
            return key;
        }
    }
}


//#############################################################################
//###################### NO MORE FAKES BEYOND THIS LINE #######################
//#############################################################################
//
//=============================================================================
// Revision History
//=============================================================================
//
// $Log: input.c,v $
// Revision 1.13  2004/08/06 13:53:23  DEBROUX Lionel
// generic commit
//
// Revision 1.12  2002/10/21 12:19:48  tnussb
// see changes for v3.99b in history.txt
//
// Revision 1.11  2002/10/16 18:28:51  tnussb
// changes related to the complete new puzzle file support (see history.txt)
//
// Revision 1.10  2002/10/14 12:08:15  tnussb
// handling of KEY_OPENINGMOVES added
//
// Revision 1.9  2002/10/08 17:44:29  tnussb
// changes related to v3.90/v3.91
//
// Revision 1.8  2002/08/01 12:46:39  tnussb
// generic commit (I don't know anymore what I have changed ..)
//
// Revision 1.7  2002/03/01 17:29:03  tnussb
// changes due to multilanguage support
//
// Revision 1.6  2002/02/11 16:38:11  tnussb
// many changes due to "separate file compiling" restructuring
//
// Revision 1.5  2001/02/17 15:00:11  Thomas Nussbaumer
// changes due to new TIGCC version
//
// Revision 1.4  2000/12/09 15:35:51  Thomas Nussbaumer
// re-initialize grayscale adjustment after and calc is turned on again
//
// Revision 1.3  2000/12/02 15:19:08  Thomas Nussbaumer
// (1) mapping of F2/F3 to KEY_ADJUSTPLUS and MINUS added
// (2) handling of GrayAdjust added
//
// Revision 1.2  2000/08/12 15:31:12  Thomas Nussbaumer
// substitution keywords added
//
//
