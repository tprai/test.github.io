/******************************************************************************
*
* project name:    TI-Chess
* file name:       logo.c
* initial date:    12/07/2000
* authors:         thomas.nussbaumer@gmx.net (coding)
*                  marcos.lopez@gmx.net      (design/graphics/beta testing)
* description:     contains the splashscreen data and output routine
*
* graphics converted using Image Studio v1.1 (Matt Johnson)
*
* $Id: logo.c,v 1.10 2004/08/06 13:55:26 DEBROUX Lionel Exp $
*
******************************************************************************/

#include "hardware.h"    // MUST BE ALWAYS HERE ON THE FIRST LINE !!!!
#include <graph.h>
#include <gray.h>
#include <mem.h>

#include "version.h"
#include "generic.h"
#include "routines.h"



//-----------------------------------------------------------------------------
// LOGO "TICT PROUDLY PRESENTS" light plane data
//-----------------------------------------------------------------------------
unsigned long logo_light[]={
0xFFFFFFFF,0xFFFFFC00,0xE0001C1F,0xE4009C03,0xE7039C07,0xFFFFFFFF,0xFFFFFFE7,0xFF03FC67,
0xFF03FC67,0xFF3BFC67,0xFF7BFE67,0xFF7BFE67,0xFFFBFFE7,0xFFFBFFE7,0xFFFBFFE7,0xFFFBFFE7,
0xFFFBFFE7,0xFFFBFFE7,0xFEF9FFE7,0xFAF97FF7,0xFC00FFEF,0xFFFFFFE0,0x87F81FFF,0x87BE0FFF,
0x877F57E0,0x83E973D0,0x83CF3FDC,0x8FE033FF,0x8F8013FF,0x9FC3FBFC,0x8FCF03FC,0x9FDE03FC,
0x9FFE03FD,0x9FFC03FD,0x9FFC03FF,0x8FFC03FF,0x9FFC03FF,0x8FBC03FF,0x8FDC23FF,0x83DC73FF,
0x81F4E3FB,0x85F943EB,0x846303F0,0x843E03FF,0xFFFFFFFF,0x040F021F,0x0403C81F,0x0400001F,
0x0401801F,0xC71EFFFC,0xE6706C6C,0xE7063C68,0xE70E3C68,0xE6063C68,0xE4006CEC,0xE401626D,
0xC1000000,0xF8C72D91,0x1C0E0D90,0x1CE0FE47,0x1CE1817C,0x1CC0C03E,0x1C000030,0x1C8068B3,
0x1C000000,0x1C000000,0x00000000,0xFFF00000,0x00100000,0xF8100000,0xF0100000,0xE0100000,
0xEFFF8000,0xE0108000,0xEFD08000,0xEF908000,0xEF108000,0xEF108000,0xEF108000,0xEF108000,
0xEF108000,0xEF108000,0xEF108000,0xEF108000,0xEF108000,0xF7108000,0xF7108000,0xFF108000,
0x1F108000,0xFFF08000,0xFFF08000,0x3FF08000,0x02708000,0x0E708000,0xFFFF8000,0xFFFF8000,
0x0FF18000,0x0FF18000,0xEFF18000,0xEFF98000,0xEFF98000,0xEFFF8000,0xEFFF8000,0xEFFF8000,
0xEFFF8000,0xEFFF8000,0xEFFF8000,0xE7FF8000,0xE5FF8000,0x03FF8000,0xFFFF8000,0xFFFF8000,
0xC03F8000,0xDC1F8000,0xDC0F8000,0xFFFF8000,0xFCFF8000,0xDF300000,0xDD800000,0xDDB00000,
0xDCA00000,0x5C600000,0x5CCC0000,0x010C0000,0x628F4800,0x65CCC800,0xF0EC0000,0x00ECB000,
0x00EC1800,0x00EC9800,0x40ED5800,0x00000000,0x00000000,0x00000000};



//-----------------------------------------------------------------------------
// LOGO "TICT PROUDLY PRESENTS" dark plane data
//-----------------------------------------------------------------------------
unsigned long logo_dark[]={
0xFFFFFFFF,0xFFFFFC00,0xC0000C0F,0xC3030C07,0xCF03CC03,0xCF03CC03,0xCF03CC03,0xFF03FC03,
0xFF03FC03,0xFF03FC03,0xFF03FC03,0xFF03FC03,0xFF03FC03,0xFF03FC03,0xFF03FC03,0xFF03FC03,
0xFF03FC03,0xFF03FC03,0xFF03FC03,0xFC00FC0F,0xFFFFFC00,0xFFFFFC00,0x800003FF,0x800003FF,
0x80FFA300,0x81F0E30C,0x87E0633C,0x87C0233C,0x8FC0233C,0x8F8003FC,0x9F8003FC,0x9F8003FC,
0x9F8003FC,0x9F8003FC,0x9F8003FC,0x9F8003FC,0x8F8003FC,0x8FC003FC,0x87C013FC,0x87E023FC,
0x83E043FC,0x80FF83F0,0x801C03FF,0x800003FF,0xFFFFFFFF,0x00000000,0x00000000,0x00000000,
0x00000000,0x7CF3C447,0x42C62448,0x42C42448,0x42C42448,0x42C42448,0x42C62448,0x7CC3C7C7,
0x40000000,0x4F9A78F3,0x08D8C506,0x08588584,0x0858FCE7,0x08588014,0x08D8C016,0x0F987DE3,
0x08000000,0x08000000,0x00000000,0xFFF00000,0x00100000,0xFC100000,0xF0100000,0xF0100000,
0xF0100000,0xF0100000,0xF0100000,0xF0100000,0xF0100000,0xF0100000,0xF0100000,0xF0100000,
0xF0100000,0xF0100000,0xF0100000,0xF0100000,0xF0100000,0xF0100000,0xF8100000,0x00100000,
0x00100000,0xFFF00000,0xFFF00000,0x00300000,0x0C300000,0x0F300000,0x0F300000,0x0F300000,
0x0FF00000,0x0FF00000,0x0FF00000,0x0FF00000,0x0FF00000,0x0FF00000,0x0FF00000,0x0FF00000,
0x0FF00000,0x0FF00000,0x0FF00000,0x0FF00000,0x03F00000,0xFFF00000,0xFFF00000,0xFFF00000,
0x00000000,0x48000000,0x48000000,0x48000000,0xCB100000,0x49100000,0x49300000,0x48A00000,
0x48E00000,0xC8C00000,0xC8480000,0x00C80000,0xCFDE7800,0x2C488000,0x2C48C000,0xEC487000,
0x0C480800,0x0C480800,0xEC46F000,0x00000000,0x00000000,0x00000000};



/*===========================================================================*/
/* outputs logo to screen and waits for keypress                             */
/*===========================================================================*/
void Logo(void) {
    short          offsetx = (STATIC_LCD_WIDTH-48)>>1;
    short          offsety = (STATIC_LCD_HEIGHT-67)>>1;
    unsigned char* plane_light = GetPlane(LIGHT_PLANE);
    unsigned char* plane_dark  = GetPlane(DARK_PLANE);
    short          x;
    short          y;
    short          byteoffset;
    unsigned char  pixmask;
    unsigned short seq          = 1;
    unsigned long  is_set_light = 0;
    unsigned long  is_set_dark  = 0;
    short          maxy         = STATIC_LCD_HEIGHT-1;
    short          py1,py2;

    memset(plane_light,0,LCD_SIZE);
    memset(plane_dark, 0,LCD_SIZE);

    //-----------------------------------------
    // first fade in the logo ...
    //-----------------------------------------
    do {
        x = seq & 0x3f;
        y = seq >> 6;

        if (y<67) {
            if (x<32) {
                is_set_light = logo_light[y] & (0x80000000 >> x);
                is_set_dark  = logo_dark[y]  & (0x80000000 >> x);
            }
            else {
                is_set_light = logo_light[y+67] & (0x80000000 >> (x-32));
                is_set_dark  = logo_dark[y+67]  & (0x80000000 >> (x-32));
            }
        }

        x += offsetx;
        y += offsety;

        byteoffset = y * 30 + (x >> 3);
        pixmask = 0x80 >> (x & 0x07);

        if (y>=offsety && y<offsety+67) {
            if (is_set_light) *(plane_light + byteoffset) |= pixmask;
            if (is_set_dark)  *(plane_dark  + byteoffset) |= pixmask;
        }

        if (seq & 1) seq = (seq>>1)^0x3500;
        else         seq = seq>>1;
    }
    while (seq != 1);

    byteoffset = offsety * 30 + (offsetx >> 3);
    pixmask = 0x80 >> (offsetx & 0x07);

    *(plane_light + byteoffset) |= pixmask;
    *(plane_dark  + byteoffset) |= pixmask;

    py1 = maxy-16;
    py2 = maxy-5;

    DrawString(0,py1,(char*)"TI-Chess v"TIC_VERSION_COMPLETE,
               F_8x10,A_REPLACE | A_CENTERED | A_SHADOWED);
    FastDrawCentered(py2,(char*)"http://tict.ticalc.org");

    //-----------------------------------------
    // wait until user presses a key ...
    //-----------------------------------------
    GetUserInput(0);

    //-----------------------------------------
    // ... and fade it out again
    //-----------------------------------------
    seq = 1;

    do {
        x = seq & 0x3f;
        y = seq >> 6;

        x += offsetx;
        y += offsety;

        byteoffset = y * 30 + (x >> 3);
        pixmask = 0x80 >> (x & 0x07);

        if (y>=offsety && y<offsety+67) {
            *(plane_light + byteoffset) &= ~pixmask;
            *(plane_dark  + byteoffset) &= ~pixmask;
        }

        if (seq & 1) seq = (seq>>1)^0x6000;
        else         seq = seq>>1;
    }
    while (seq != 1);
}


//#############################################################################
//###################### NO MORE FAKES BEYOND THIS LINE #######################
//#############################################################################
//
//=============================================================================
// Revision History
//=============================================================================
//
// $Log: logo.c,v $
// Revision 1.10  2004/08/06 13:55:26  DEBROUX Lionel
// generic commit
//
// Revision 1.9  2002/10/22 08:40:37  tnussb
// using now define TIC_VERSION_COMPLETE
//
// Revision 1.8  2002/10/17 11:40:09  tnussb
// minor size optimizations
//
// Revision 1.7  2002/02/11 16:38:12  tnussb
// many changes due to "separate file compiling" restructuring
//
// Revision 1.6  2002/02/07 11:39:45  tnussb
// changes for v3.50beta and v3.50 (see history.txt)
//
// Revision 1.5  2001/02/17 15:00:11  Thomas Nussbaumer
// changes due to new TIGCC version
//
// Revision 1.4  2000/12/19 13:55:29  Thomas Nussbaumer
// warnings stated by compiling with option -Wall fixed
//
// Revision 1.3  2000/12/02 15:21:19  Thomas Nussbaumer
// (1) using now LIGHT_PLANE/DARK_PLANE constants which makes code more readable
// (2) web address changed to http://tict.ticalc.org
//
// Revision 1.2  2000/08/12 15:31:13  Thomas Nussbaumer
// substitution keywords added
//
//
