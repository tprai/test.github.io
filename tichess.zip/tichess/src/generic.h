/******************************************************************************
*
* project name:    TI-Chess
* file name:       generic.h
* initial date:    13/07/2000
* authors:         thomas.nussbaumer@gmx.net (coding)
*                  marcos.lopez@gmx.net      (design/graphics/beta testing)
* description:     defines some graphics related constants and
*                  contains prototypes for functions of generic.c
*
* $Id: generic.h,v 1.6 2004/08/06 13:50:43 DEBROUX Lionel Exp $
*
******************************************************************************/

#ifndef __GENERIC_H__
#define __GENERIC_H__

extern SCR_RECT fullscreen;


/*---------------------------------------------------------------------------*/
/* some defines used in DrawColorLine() and DrawColorRect() functions        */
/*---------------------------------------------------------------------------*/
#define COLOR_WHITE      0
#define COLOR_LIGHTGRAY  1
#define COLOR_DARKGRAY   2
#define COLOR_BLACK      3


/*---------------------------------------------------------------------------*/
/* styles for DrawColorRect functions                                        */
/*---------------------------------------------------------------------------*/
#define RECT_EMPTY       0
#define RECT_FILLED      1


/*---------------------------------------------------------------------------*/
/* these definitions extends the normal draw style attributes for strings    */
/*---------------------------------------------------------------------------*/
#define A_CENTERED       0x40
#define A_SHADOWED       0x80

#endif

//#############################################################################
//###################### NO MORE FAKES BEYOND THIS LINE #######################
//#############################################################################
//
//=============================================================================
// Revision History
//=============================================================================
//
// $Log: generic.h,v $
// Revision 1.6  2004/08/06 13:50:43  DEBROUX Lionel
// generic commit
//
// Revision 1.5  2002/02/11 16:38:11  tnussb
// many changes due to "separate file compiling" restructuring
//
// Revision 1.4  2001/06/20 20:24:15  Thomas Nussbaumer
// size optimizations
//
// Revision 1.3  2001/02/17 15:00:11  Thomas Nussbaumer
// changes due to new TIGCC version
//
// Revision 1.2  2000/08/12 15:31:12  Thomas Nussbaumer
// substitution keywords added
//
//
