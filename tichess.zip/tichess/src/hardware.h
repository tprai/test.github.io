/******************************************************************************
*
* project name:    TI-Chess
* file name:       hardware.h
* initial date:    08/02/2002
* author:          thomas.nussbaumer@gmx.net
* description:     contains hardware related definitions
*
* $Id: hardware.h,v 1.3 2004/08/06 13:51:39 DEBROUX Lionel Exp $
*
******************************************************************************/

#ifndef TICHARDWARE_H
#define TICHARDWARE_H

//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// NOTE: AT LEAST OPTIMIZE_ROM_CALLS HAVE TO BE DEFINED HERE !!!!
//
// BEWARE! ONLY PUT MACROS IN THIS FILE, BECAUSE IT WILL BE INCLUDED FIRST
// IN TICHESS.C
//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

//#define OPTIMIZE_ROM_CALLS // makes ROM calls smaller and faster
//#define NO_EXIT_SUPPORT    // new directive from TIGCCLIB 2.4SP1 (we need no
                           // exit support so code becomes smalles this way)
#define USE_FLINE_ROM_CALLS
#define USE_INTERNAL_FLINE_EMULATOR
#define MIN_AMS 100
//-----------------------------------------------------------------------------
// check for -DUSE_TI89 commandline flag (for TI-89 version)
// *** or ***
// check for -DUSE_TI92P commandline flag (for TI-92p version)
//
// ONLY ONE IS ALLOWED PER COMPILE RUN
//-----------------------------------------------------------------------------
#if defined(USE_TI89) && defined(USE_TI92P)
#error cannot produce both versions at once
#elif defined(USE_TI89)
#define C89_92(x,y) (x)        // useful macro to write calc-dependent defines
#elif defined(USE_TI92P)
#define C89_92(x,y) (y)        // useful macro to write calc-dependent defines
#else
#error Please specify either -DUSE_TI89 or -DUSE_TI92P on commandline
#endif

//-----------------------------------------------------------------------------
// "useful" macros (most of them are also defined in compat.h, but the
// definitions from compat.h are evaluated during runtime and produces
// therefore larger code)
//-----------------------------------------------------------------------------
#define STATIC_LCD_WIDTH   C89_92(160,240)
#define STATIC_LCD_HEIGHT  C89_92(100,128)

#define SIZE_X             C89_92(12,14)  // x-size of one square
#define SIZE_Y             C89_92(12,14)  // y-size of one square

#define OFFSET_X  2      // x offset of board display
#define OFFSET_Y  2      // y offset of board display


#define STATIC_FUNC static

#include "messages.h"

#endif


//#############################################################################
//###################### NO MORE FAKES BEYOND THIS LINE #######################
//#############################################################################
//
//=============================================================================
// Revision History
//=============================================================================
//
// $Log: hardware.h,v $
// Revision 1.3  2004/08/06 13:51:39  DEBROUX Lionel
// Changes for TIGCC 0.95
//
// Revision 1.2  2002/03/01 17:29:03  tnussb
// changes due to multilanguage support
//
// Revision 1.1  2002/02/11 16:34:23  tnussb
// initial version
//
//
