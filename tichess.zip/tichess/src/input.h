/******************************************************************************
*
* project name:    TI-Chess
* file name:       input.h
* initial date:    13/07/2000
* authors:         thomas.nussbaumer@gmx.net (coding)
*                  marcos.lopez@gmx.net      (design/graphics/beta testing)
* description:     key definitions
*
* $Id: input.h,v 1.8 2004/08/06 13:53:54 DEBROUX Lionel Exp $
*
******************************************************************************/

#ifndef __INPUT_H__
#define __INPUT_H__

#include "tichess.h"

//=============================================================================
// NOTE: due to our own keyhandler the following keycodes are NOT equal to the
//       real ones, but this way the TI89 and the TI92 can be treated
//       equally !!!
//=============================================================================

//-----------------------------------------------------------------------------
// cursor keys
//-----------------------------------------------------------------------------
#define KEY_MLEFT        337
#define KEY_MRIGHT       340
#define KEY_MUP          338
#define KEY_MDOWN        344



//-----------------------------------------------------------------------------
// other keys
//-----------------------------------------------------------------------------
#define KEY_ESCAPE       264
#define KEY_ENTER         13
#define KEY_OFF         4363
#define KEY_BACK         257
#define KEY_LOADSAVE     258
#define KEY_LEVELUP      ')'
#define KEY_LEVELDOWN    '('
#define KEY_EXIT         'x'
#define KEY_SHOWMOVES    's'
#define KEY_OPENINGMOVES 'o'
#define KEY_CHANGESIDE   'c'
#define KEY_TWOPLAYER    '2'
#define KEY_ROTATE       'r'
#define KEY_HELP         'h'
#define KEY_FORWARD      'f'
#define KEY_AUTOMATIC    'a'
#define KEY_MLEFT        337
#define KEY_MRIGHT       340
#define KEY_MUP          338
#define KEY_MDOWN        344
#define KEY_CONTRASTUP   900
#define KEY_CONTRASTDN   901

#if ENABLE_TESTKEY
#define KEY_TESTING '='
#endif

#endif


//#############################################################################
//###################### NO MORE FAKES BEYOND THIS LINE #######################
//#############################################################################
//
//=============================================================================
// Revision History
//=============================================================================
//
// $Log: input.h,v $
// Revision 1.8  2004/08/06 13:53:54  DEBROUX Lionel
// generic commit
//
// Revision 1.7  2002/10/14 12:08:36  tnussb
// define for KEY_OPENINGMOVES added
//
// Revision 1.6  2002/10/08 17:44:29  tnussb
// changes related to v3.90/v3.91
//
// Revision 1.5  2002/08/01 12:46:39  tnussb
// generic commit (I don't know anymore what I have changed ..)
//
// Revision 1.4  2001/02/17 15:00:11  Thomas Nussbaumer
// changes due to new TIGCC version
//
// Revision 1.3  2000/12/02 15:18:21  Thomas Nussbaumer
// definitions KEY_ADJUSTPLUS and KEY_ADJUSTMINUS added
//
// Revision 1.2  2000/08/12 15:31:13  Thomas Nussbaumer
// substitution keywords added
//
//
