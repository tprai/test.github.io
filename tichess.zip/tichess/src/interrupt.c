/******************************************************************************
*
* project name:    TI-Chess
* file name:       interrupt.c
* initial date:    12/07/2000
* authors:         thomas.nussbaumer@gmx.net (coding)
*                  marcos.lopez@gmx.net      (design/graphics/beta testing)
*
* description:     keyboard handler routines for INT1 and INT5
*
* !!! Thanx to Zeljko Juric to help me out with informations !!!
*
* $Id: interrupt.c,v 1.9 2004/08/06 13:54:22 DEBROUX Lionel Exp $
*
******************************************************************************/

//-----------------------------------------------------------------------------
// One major problem is that the keyboard of the TI calculators is NOT
// unbounced! So don't believe in short transitions !!
//-----------------------------------------------------------------------------

#include "hardware.h"   // MUST BE ALWAYS HERE ON THE FIRST LINE !!!!
#include <mem.h>
#include <intr.h>
#include <kbd.h>
#include "interrupt.h"

volatile unsigned char  onkey     = 0;  // may used to detect [ON] key pressed for break
volatile unsigned short do_reset  = 0;  // may be used to clear transition buffer
volatile unsigned char  o_onkey   = 0;  // previous on key state
volatile unsigned char  n_onkey   = 0;  // new on key state
volatile unsigned short row2scan  = 0;  // current row to scan
unsigned char           trow[10]  = {}; // may be used to detect key-down transitions
unsigned char           orow[10]  = {}; // previous key states
unsigned char           nrow[10]  = {}; // current key states

INT_HANDLER             old_int1_handler = (void*)0; // backup variable for old int1 handler
INT_HANDLER             old_int5_handler = (void*)0; // backup variable for old int5 handler
volatile unsigned short call_old_int5    = 1;
short                   is_hw1_calc      = 0;  // will be set to 1 if calculator is HW1
                                               // by InstallInterruptHandlers()


/*===========================================================================*/
/* INT5 handler which can switch the calling of the default INT5 handler     */
/*===========================================================================*/
DEFINE_INT_HANDLER (SwitchableINT5Handler) {
    if (call_old_int5) ExecuteHandler(old_int5_handler);
}


/*===========================================================================*/
/* our new keyboard handler detects and stores key down transitions          */
/* (used internally)                                                         */
/*                                                                           */
/* this handler uses a round robin-like method, which means that at each     */
/* call just one row is scanned to keep the time effort for each call small  */
/*===========================================================================*/
DEFINE_INT_HANDLER (KeyboardHandler) {
    if (do_reset) {
        unsigned long *ptr = (unsigned long *)trow;
        *ptr++ = 0;
        *ptr++ = 0;
        *(unsigned short *)ptr++ = 0;
        //memset(trow,0,10);
        do_reset = 0;
        onkey    = 0;
    }

    call_old_int5 = 0;

    nrow[row2scan] = _rowread(~(1<<row2scan));
    trow[row2scan] |= (~orow[row2scan]) & nrow[row2scan];
    orow[row2scan] = nrow[row2scan];

    row2scan++;

#if defined(USE_TI89)
    if (row2scan == 7)  row2scan = 0;
#else
    if (row2scan == 10) row2scan = 0;
#endif

    //-------------------------------------
    // get state of [ON] key
    //-------------------------------------
    n_onkey = ~(*(volatile unsigned char*)0x60001a) & 0x2;

    if (!o_onkey && n_onkey) onkey = 1;
    o_onkey = n_onkey;

    call_old_int5 = 1;
}



/*===========================================================================*/
/* installs new INT handlers                                                 */
/*                                                                           */
/* INT1 handler == own keyboard handler                                      */
/* INT2 handler == dummy handler to increase performance (doesn't matter)    */
/*===========================================================================*/
void InstallInterruptHandlers() {
    unsigned long hwpb, *rombase,result;

    rombase = (unsigned long *)((*(unsigned long *)0xC8) & 0xE00000);
    hwpb = rombase[65];
    result = (hwpb - (unsigned long)rombase < 0x10000 &&
    *(unsigned short *)hwpb > 22 ? *(unsigned long *)(hwpb + 22) : 1);

    if (result == 1) is_hw1_calc = 1;
    else             is_hw1_calc = 0;

    //---------------------------------------
    // initialize globals of keyboard handler
    //---------------------------------------
    onkey    = 0;
    o_onkey  = 0;
    n_onkey  = 0;
    do_reset = 0;
    row2scan = 0;
    unsigned long *ptr = (unsigned long *)orow;
    *ptr++ = 0;
    *ptr++ = 0;
    *(unsigned short *)ptr++ = 0;
    ptr = (unsigned long *)nrow;
    *ptr++ = 0;
    *ptr++ = 0;
    *(unsigned short *)ptr++ = 0;
    ptr = (unsigned long *)trow;
    *ptr++ = 0;
    *ptr++ = 0;
    *(unsigned short *)ptr++ = 0;
/*
    memset(orow,0,10);
    memset(nrow,0,10);
    memset(trow,0,10);
*/

    call_old_int5 = 0;
    //---------------------------------------
    // install handler for INT1 and INT5
    //---------------------------------------
    old_int1_handler = GetIntVec(AUTO_INT_1);
    old_int5_handler = GetIntVec(AUTO_INT_5);

    SetIntVec(AUTO_INT_1,KeyboardHandler);
    SetIntVec(AUTO_INT_5,SwitchableINT5Handler);
    call_old_int5 = 1;
}



/*===========================================================================*/
/* restores old INT handlers                                                 */
/*===========================================================================*/
void RestoreInterruptHandlers() {
    call_old_int5 = 0;
    SetIntVec(AUTO_INT_1,old_int1_handler);
    SetIntVec(AUTO_INT_5,old_int5_handler);
}



//#############################################################################
//###################### NO MORE FAKES BEYOND THIS LINE #######################
//#############################################################################
//
//=============================================================================
// Revision History
//=============================================================================
//
// $Log: interrupt.c,v $
// Revision 1.9  2004/08/06 13:54:22  DEBROUX Lionel
// optimizations
//
// Revision 1.8  2002/10/08 17:44:29  tnussb
// changes related to v3.90/v3.91
//
// Revision 1.7  2002/03/01 17:29:04  tnussb
// changes due to multilanguage support
//
// Revision 1.6  2002/02/11 16:38:12  tnussb
// many changes due to "separate file compiling" restructuring
//
// Revision 1.5  2001/02/17 15:00:11  Thomas Nussbaumer
// changes due to new TIGCC version
//
// Revision 1.4  2000/12/09 15:36:38  Thomas Nussbaumer
// using now an volatile pointer to fetch on key state
//
// Revision 1.3  2000/12/02 15:20:24  Thomas Nussbaumer
// using now interrupt support routines from TIGCC Library 2.22
//
// Revision 1.2  2000/08/12 15:31:13  Thomas Nussbaumer
// substitution keywords added
//
//
