/******************************************************************************
*
* project name:    TI-Chess
* file name:       messages.h
* initial date:    28/02/2002
* author:          thomas.nussbaumer@gmx.net
* description:     multilanguage support
*
* $Id: messages.h,v 1.4 2004/08/06 13:56:27 DEBROUX Lionel Exp $
*
******************************************************************************/

#ifndef MESSAGES_H
#define MESSAGES_H


#if defined(LANG_ENGLISH) || defined(LANG_english)
//=============================================================================
// include ENGLISH messages
//=============================================================================
#define TIC_VERSION_LANG  "/e"
#include "msg_english.h"

#elif defined(LANG_GERMAN) || defined(LANG_german)
//=============================================================================
// include GERMAN messages
//=============================================================================
#define TIC_VERSION_LANG  "/d"
#include "msg_german.h"

#elif defined(LANG_FRENCH) || defined(LANG_french)
//=============================================================================
// include FRENCH messages
//=============================================================================
#define TIC_VERSION_LANG  "/f"
#include "msg_french.h"

#elif defined(LANG_SPANISH) || defined(LANG_spanish)
//=============================================================================
// include SPANISH messages
//=============================================================================
#define TIC_VERSION_LANG  "/h"
#include "msg_spanish.h"

#else
//=============================================================================
// ERROR: no valid language defined
//=============================================================================
#error Please specify either ENGLISH, GERMAN, FRENCH or SPANISH on commandline

#endif

#endif

//#############################################################################
//###################### NO MORE FAKES BEYOND THIS LINE #######################
//#############################################################################
//
//=============================================================================
// Revision History
//=============================================================================
//
// $Log: messages.h,v $
// Revision 1.4  2004/08/06 13:56:27  DEBROUX Lionel
// generic commit
//
// Revision 1.3  2002/10/28 09:11:59  tnussb
// extensions for spanish version
//
// Revision 1.2  2002/08/01 12:46:39  tnussb
// generic commit (I don't know anymore what I have changed ..)
//
// Revision 1.1  2002/03/01 17:28:41  tnussb
// initial check-in
//
//
