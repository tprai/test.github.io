/******************************************************************************
*
* project name:    TI-Chess
* file name:       train.c
* initial date:    16/10/2002
* author:          thomas.nussbaumer@gmx.net
* description:     contains puzzle file handling
*
******************************************************************************/

#include "hardware.h"    // MUST BE ALWAYS HERE ON THE FIRST LINE !!!!
#include <stdio.h>
#include <stdlib.h>
#include <vat.h>
#include <graph.h>
#include <gray.h>

#include "defines.h"

//-----------------------------------------------------------------------------
// internal INFO on PUZZLE structures:
//
// tichess may use up to 10 puzzle files (ticpuz0 ... ticpuz9)
//
//
// a puzzle may contain 3 lines of normal description
// (puzzle_text[0] ... puzzle_text[2])
// and 4 lines of solution
// (puzzle_text[4] ... puzzle_text[7])
//
// puzzle_text[3] is automatically filled with "TURN: WHITE/BLACK"
//
// each puzzle text line may be up to SIZE_PUZZLETEXT (32) characters long
// otherwise it will be truncated
//-----------------------------------------------------------------------------
char puzzle_text[8][SIZE_PUZZLETEXT+1];


ticfile_t      puzzle_files[MAX_PUZZLES_USED];
unsigned short puzzle_counts[MAX_PUZZLES_USED];
short          nr_puzzle_files;

unsigned short puzzle_active = 1;
unsigned short puzzle_max    = 0;


/*===========================================================================*/
/*  initializes global puzzlefiles list                                      */
/*===========================================================================*/
void InitPuzzles() {
    short i;

    puzzle_active = 1;
    puzzle_max    = 0;

    nr_puzzle_files = FindAndOpenTICFiles(puzzle_files,MAX_PUZZLES_USED,MAGIC_PUZZLEFILE);

    for (i=0;i<nr_puzzle_files;i++) {
        puzzle_counts[i] = *(unsigned short*)(puzzle_files[i].start+6);
        puzzle_max += puzzle_counts[i];
    }

    if (defaults.active_puzzle <= puzzle_max) {
        puzzle_active = defaults.active_puzzle;
    }
}


/*===========================================================================*/
/* cleanup training files                                                    */
/*===========================================================================*/
void CleanupPuzzles() {
    short i;
    for (i=0;i<nr_puzzle_files;i++) {
        CloseTICFile(&(puzzle_files[i]));
    }
}

typedef struct {
    unsigned short texts[7];
    unsigned char  others[22];
} puzzle_t;


/*===========================================================================*/
/* retrieve puzzle_t structure of active puzzle                              */
/*===========================================================================*/
puzzle_t* GetActivePuzzle(short* index) {
    short act_counter = 0;
    short i;

    *index = 0;

    for (i=0;i<nr_puzzle_files;i++) {
        if ((act_counter + puzzle_counts[i])>=puzzle_active) {
            *index = i;
            return (puzzle_t*)(puzzle_files[i].start + 2 + 4 + 2 + SIZE_PUZZLE * (puzzle_active - 1 - act_counter));
        }
        else {
            act_counter += puzzle_counts[i];
        }
    }
    return 0; // should never happen
}


/*===========================================================================*/
/* will load description of a puzzle                                         */
/*===========================================================================*/
void LoadPuzzleDesc(void) {
    short          j;
    short          index;
    puzzle_t*      puzzleptr = GetActivePuzzle(&index);

    for (j=0;j<3;j++) {
        strncpy(puzzle_text[j],puzzle_files[index].start+puzzleptr->texts[j],32);
    }

    if (puzzleptr->others[21] & 0x1) strcpy(puzzle_text[3],TRAIN_MENU_TURNBLACK);
    else                             strcpy(puzzle_text[3],TRAIN_MENU_TURNWHITE);

    for (j=0;j<4;j++) {
        strncpy(puzzle_text[j+4],puzzle_files[index].start+puzzleptr->texts[j+3],32);
    }
}


#define CORRECT_POSITION() ({ bitpos>>=1;     \
                             if (!bitpos) {   \
                                 bitpos=0x80; \
                                 input++;     \
                             }})



//=============================================================================
// decompresses a huffman encoded chess position
//
// input is a 21-byte long buffer holding a compressed chess position
// output is a 64-byte buffer for decompressed chess position
//=============================================================================
void LoadActivePuzzle() {
    short          index;
    puzzle_t*      puzzle = GetActivePuzzle(&index);
    unsigned char* input  = puzzle->others;
    short          i;
    unsigned char  bitpos = 0x80;
    unsigned char* orig   = input;
    short          ef     = ILLEGAL;
    char           fig;

    for (i=0;i<BOARD_SIZE;i++) {
        if (board[i] == OUTSIDE) continue;

        if (!(*input & bitpos)) {
            fig = EMPTY;
            goto correct_and_continue;
        }

        CORRECT_POSITION();

        if (!(*input & bitpos)) {
            CORRECT_POSITION();
            if (!(*input & bitpos)) fig = W_PAWN;
            else                    fig = B_PAWN;
            goto correct_and_continue;
        }

        CORRECT_POSITION();

        if (!(*input & bitpos)) {
            CORRECT_POSITION();
            if (!(*input & bitpos)) {
                 CORRECT_POSITION();
                 if (!(*input & bitpos)) fig = W_BISHOP;
                 else                    fig = B_BISHOP;
                 goto correct_and_continue;
            }
            CORRECT_POSITION();
            if (!(*input & bitpos)) fig = W_KNIGHT;
            else                    fig = B_KNIGHT;
            goto correct_and_continue;
        }

        CORRECT_POSITION();

        if (!(*input & bitpos)) {
            CORRECT_POSITION();
            if (!(*input & bitpos)) fig = W_ROOK;
            else                    fig = B_ROOK;
            goto correct_and_continue;
        }

        CORRECT_POSITION();

        if (!(*input & bitpos)) {
            CORRECT_POSITION();
            if (!(*input & bitpos)) fig = W_QUEEN;
            else                    fig = B_QUEEN;
            goto correct_and_continue;
        }

        CORRECT_POSITION();

        if (!(*input & bitpos)) fig = W_KING;
        else                    fig = B_KING;

    correct_and_continue:
        board[i] = fig;
        CORRECT_POSITION();
    }


    if (orig[21] & 0x1) {
        // color BLACK
        act_color  = BLACK;
        move_count = 1;
    }
    else {
        // color WHITE
        act_color  = WHITE;
        move_count = 0;
    }

    if (orig[20] & 0x08) {
        ef = orig[20] & 0x7;
        if (act_color == BLACK) ef += 20 + 21;
        else                    ef += 50 + 21;
    }

    ep_field[0] = ep_field[1] = ef;
    move_count = 0;

    flags[0] = 0xffff;

    if (orig[21] & 0x2) {   // white long castling
        flags[0] &= ~(unsigned short)W_ROCHADE_MASK;
        flags[0] &= ~(unsigned short)E1_MOVE_MASK;
        flags[0] &= ~(unsigned short)A1_MOVE_MASK;
    }
    if (orig[21] & 0x4) {   // white short castling
        flags[0] &= ~(unsigned short)W_ROCHADE_MASK;
        flags[0] &= ~(unsigned short)E1_MOVE_MASK;
        flags[0] &= ~(unsigned short)H1_MOVE_MASK;
    }
    if (orig[21] & 0x8) {   // black long castling
        flags[0] &= ~(unsigned short)B_ROCHADE_MASK;
        flags[0] &= ~(unsigned short)E8_MOVE_MASK;
        flags[0] &= ~(unsigned short)A8_MOVE_MASK;
    }
    if (orig[21] & 0x10) {   // black short castling
        flags[0] &= ~(unsigned short)B_ROCHADE_MASK;
        flags[0] &= ~(unsigned short)E8_MOVE_MASK;
        flags[0] &= ~(unsigned short)H8_MOVE_MASK;
    }

    SetupVariousEngineParams();
    ClearInfoBoardData();
}


//#############################################################################
//###################### NO MORE FAKES BEYOND THIS LINE #######################
//#############################################################################
//
//=============================================================================
// Revision History
//=============================================================================
//
// $Log: train.c,v $
// Revision 1.6  2004/08/06 14:00:56  DEBROUX Lionel
// generic commit
//
// Revision 1.5  2002/10/18 16:03:54  tnussb
// see history.txt for v3.98b
//
// Revision 1.4  2002/10/17 09:56:42  tnussb
// generic commit for v3.97
//
// Revision 1.3  2002/10/16 20:43:43  tnussb
// treating of position flags like castling rights when setup a puzzle
// position added
//
// Revision 1.2  2002/10/16 18:28:52  tnussb
// changes related to the complete new puzzle file support (see history.txt)
//
// Revision 1.1  2002/10/16 17:58:03  tnussb
// initial version
//
//
