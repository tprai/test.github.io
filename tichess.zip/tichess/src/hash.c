/******************************************************************************
*
* project name:    TI-Chess
* file name:       hash.c
* initial date:    10/03/2000
* authors:         thomas.nussbaumer@gmx.net (coding)
*                  marcos.lopez@gmx.net      (design/graphics/beta testing)
* description:     contains the hashing stuff
*
* $Id: hash.c,v 1.6 2004/08/06 13:52:16 DEBROUX Lionel Exp $
*
******************************************************************************/

//=============================================================================
//
// The following define controls the style of hashing. If it is set to 1
// simple hashing is used, where each key maps only to one entry and replaces
// it.
//
// If is set to 0 a more sophisticated mapping is used where each key maps
// to 2 entries: it's normal entry and the entry which is resolved if each bit
// of the key is inverted.
// If both entries matches to the same position the best of them will be
// restored. If storing a move the worst of both entries gets overwritten.
//
//=============================================================================

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
//
// NOTE: This file is NOT built STANDALONE, but it is included from engine.c
//       to give the inlining a chance!
//
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

#define SIMPLE_HASH 0

hash_t        act_hashkey      = 0;
short         hashmode         = TRUE;  // state of hashing usage
short         hashprint        = FALSE; // state of hash statistics
unsigned long used_hash        = 0;
unsigned long hash_sum         = 0;
unsigned long node_sum         = 0;
char          default_hashmode = 0;



/*===========================================================================*/
/* is used to toggle hash table usage                                        */
/*===========================================================================*/
void ResetHashCounters(void) {
    used_hash = hash_sum = node_sum = 0;
}



/*===========================================================================*/
/* try to retrieve a value for this position from hash                       */
/* returns TRUE if value could be retrieved                                  */
/*===========================================================================*/
#if SIMPLE_HASH
STATIC_FUNC inline short RetrieveFromHash(short *value) {
    unsigned short  key;
    hentry_t*       entry;

    if (!hashmode) return FALSE;

    key = (unsigned short)(act_hashkey & (HASHSIZE-1));

    if (act_color == WHITE) entry = &hashtable_w[key];
    else                    entry = &hashtable_b[key];

    if (entry->key != act_hashkey) return FALSE;

    used_hash++;
    *value = entry->val;

    return TRUE;
}

#else

// We could add a size optimization here, the code snippets
// are very similar.
STATIC_FUNC inline short RetrieveFromHash(short *value) {
    unsigned short key1;
    unsigned short key2;
    hentry_t*      entry1;
    hentry_t*      entry2;

    if (!hashmode) return FALSE;

    key1 = (unsigned short)(act_hashkey & (HASHSIZE-1));
    key2 = ~key1 & (HASHSIZE-1);

    if (act_color == WHITE) {
        entry1 = &hashtable_w[key1];

        if (entry1->key != act_hashkey) {
            entry2 = &hashtable_w[key2];
            if (entry2->key != act_hashkey) return FALSE;
            *value = entry2->val;
            used_hash++;
            return TRUE;
        }
        else {
            entry2 = &hashtable_w[key2];
            if (entry2->key != act_hashkey) {
                *value = entry1->val;
                used_hash++;
                return TRUE;
            }
            if (entry2->val > entry1->val) {
                *value = entry2->val;
            }
            else {
                *value = entry1->val;
            }
            used_hash++;
            return TRUE;
        }
    }
    else {
        entry1 = &hashtable_b[key1];

        if (entry1->key != act_hashkey) {
            entry2 = &hashtable_b[key2];
            if (entry2->key != act_hashkey) return FALSE;
            *value = entry2->val;
            used_hash++;
            return TRUE;
        }
        else {
            entry2 = &hashtable_b[key2];
            if (entry2->key != act_hashkey) {
                *value = entry1->val;
                used_hash++;
                return TRUE;
            }
            if (entry2->val < entry1->val) {
                *value = entry2->val;
            }
            else {
                *value = entry1->val;
            }
            used_hash++;
            return TRUE;
        }
    }
}
#endif



/*===========================================================================*/
/* stores a value in the hash                                                */
/*===========================================================================*/
#if SIMPLE_HASH
STATIC_FUNC inline void StoreInHash(short value) {
    unsigned short key;
    hentry_t*      entry;

    if (!hashmode) return;

    key = (unsigned short)(act_hashkey & (HASHSIZE-1));

    if (act_color == WHITE) entry = &hashtable_w[key];
    else                    entry = &hashtable_b[key];

    entry->key = act_hashkey;
    entry->val = value;
}

#else

STATIC_FUNC inline void StoreInHash(short value) {
    unsigned short key1;
    unsigned short key2;
    hentry_t*      entry1;
    hentry_t*      entry2;

    if (!hashmode) return;

    key1 = (unsigned short)(act_hashkey & (HASHSIZE-1));
    key2 = ~key1 & (HASHSIZE-1);

    if (act_color == WHITE) {
        entry1 = &hashtable_w[key1];
        entry2 = &hashtable_w[key2];

        if (entry1->val < entry2->val) {
            entry1->key = act_hashkey;
            entry1->val = value;
        }
        else {
            entry2->key = act_hashkey;
            entry2->val = value;
        }
    }
    else {
        entry1 = &hashtable_b[key1];
        entry2 = &hashtable_b[key2];

        if (entry1->val > entry2->val) {
            entry1->key = act_hashkey;
            entry1->val = value;
        }
        else {
            entry2->key = act_hashkey;
            entry2->val = value;
        }
    }
}
#endif


short init_random = 1;


unsigned long x[55] = {
       1410651636UL, 3012776752UL, 3497475623UL, 2892145026UL, 1571949714UL,
       3253082284UL, 3489895018UL,  387949491UL, 2597396737UL, 1981903553UL,
       3160251843UL,  129444464UL, 1851443344UL, 4156445905UL,  224604922UL,
       1455067070UL, 3953493484UL, 1460937157UL, 2528362617UL,  317430674UL,
       3229354360UL,  117491133UL,  832845075UL, 1961600170UL, 1321557429UL,
        747750121UL,  545747446UL,  810476036UL,  503334515UL, 4088144633UL,
       2824216555UL, 3738252341UL, 3493754131UL, 3672533954UL,   29494241UL,
       1180928407UL, 4213624418UL,   33062851UL, 3221315737UL, 1145213552UL,
       2957984897UL, 4078668503UL, 2262661702UL,   65478801UL, 2527208841UL,
       1960622036UL,  315685891UL, 1196037864UL,  804614524UL, 1421733266UL,
       2017105031UL, 3882325900UL,  810735053UL,  384606609UL, 2393861397UL
};

unsigned long y[55] = {};
short         jjj   = 0;
short         kkk   = 0;



/*===========================================================================*/
/* 32 bit random number generator                                            */
/*===========================================================================*/
STATIC_FUNC __attribute__((__noinline__)) unsigned long Random32(void) {
    unsigned long  ul;
    short kk = kkk,jj = jjj;

    if (init_random) {
       short i;

       register unsigned long *ptr1 asm("%a0");
       register unsigned long *ptr2 asm("%a1");

       init_random = 0;
       ptr1 = &y[0];
       ptr2 = &x[0];
       for (i = 0; i < 55; i++) *ptr1++ = *ptr2++;

       jj = 24 - 1;
       kk = 55 - 1;
    }

    ul = (y[kk] += y[jj]);
    if (--jj < 0) jj = 55 - 1;
    if (--kk < 0) kk = 55 - 1;

    jjj = jj;
    kkk = kk;
    return(ul);
}



/*===========================================================================*/
/* setup the hashcode table by assigning each square/piece/side combination  */
/* an own 64bit hashcode                                                     */
/*===========================================================================*/
inline void InitHashCode(void) {
    if (default_hashmode == OPTION_OFF) {
        hashmode  = FALSE;
        hashprint = FALSE;
    }
    else {
       ResetHashCounters();
       hashmode  = TRUE;
       hashprint = FALSE;
       memset(hashtable_w,0,sizeof(hentry_t)*HASHSIZE);
       memset(hashtable_b,0,sizeof(hentry_t)*HASHSIZE);
    }
    init_random = 1;


    short sq;
    unsigned long *ptr;

    ptr = ((unsigned long *)&hashcodes[0][0]);
    for (sq = 0; sq < 12*64; sq++) {
        *ptr++ = Random32();
        *ptr++ = Random32();
    }
}



/*===========================================================================*/
/* setup the hashcode table by assigning each square/piece/side combination  */
/* an own 64bit hashcode                                                     */
/*===========================================================================*/
STATIC_FUNC inline void XorHKey(char fig,short square) {
    if (fig==EMPTY || fig==OUTSIDE) return;

    if (fig < 0) fig = -fig + 6;
    fig--;

    act_hashkey ^= hashcodes[(unsigned char)fig][(square/10 - 2) * 8 + (square%10 - 1)];
}



/*===========================================================================*/
/* the hashcode is generated by looping through all squares and XORing all   */
/* hashcodes of the square/piece/color combinations found                    */
/*===========================================================================*/
void CalcHashKey(void) {
    short  sq;

    act_hashkey = 0;
    for (sq=A1; sq<=H8; sq++) XorHKey(board[sq],sq);
}



//#############################################################################
//###################### NO MORE FAKES BEYOND THIS LINE #######################
//#############################################################################
//
//=============================================================================
// Revision History
//=============================================================================
//
// $Log: hash.c,v $
// Revision 1.6  2004/08/06 13:52:16  DEBROUX Lionel
// optimizations
//
// Revision 1.5  2002/02/11 16:38:11  tnussb
// many changes due to "separate file compiling" restructuring
//
// Revision 1.4  2001/02/17 15:00:11  Thomas Nussbaumer
// changes due to new TIGCC version
//
// Revision 1.3  2000/12/19 13:55:29  Thomas Nussbaumer
// warnings stated by compiling with option -Wall fixed
//
// Revision 1.2  2000/08/12 15:31:12  Thomas Nussbaumer
// substitution keywords added
//
//
