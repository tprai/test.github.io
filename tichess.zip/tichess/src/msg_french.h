/******************************************************************************
*
* project name:    TI-Chess
* file name:       msg_french.h
* initial date:    28/02/2002
* authors:         thomas.nussbaumer@gmx.net
*                  Fran�ois Leiber
* description:     french messages
*
* $Id: msg_french.h,v 1.8 2004/08/06 13:56:53 DEBROUX Lionel Exp $
*
******************************************************************************/

#ifndef MSG_FRENCH_H
#define MSG_FRENCH_H

//-----------------------------------------------------------------------------
// strings and constants for main menu (file: menu.c)
//-----------------------------------------------------------------------------
//#define MAIN_MENU_TI89  "New  Load/Save  Train  Options  Help About Exit"
#define MAIN_MENU_TI89    "Nouveau  E/S  Probl. Options  Aide  Infos  Sortie"
//#define MAIN_MENU_TI92P " New       Load/Save        Train        Options        Help        About        Exit"
#define MAIN_MENU_TI92P   " Nouveau      E/S      Probl�mes      Options      Aide      A propos     Sortie"

//-----------------------------------------------------------------------------
// The following number pairs are used for highlighting the entries of the main
// menu. Make sure to adapt them correctly (file: menu.c)
//-----------------------------------------------------------------------------
//#define MAIN_MENU_COORDS_TI89   0,15, 19,55,  59,77,  81,105, 109,124, 126,145, 147,159
#define MAIN_MENU_COORDS_TI89     0,29, 33,45,  49,70,  72,96, 100,114, 118,134, 138,159
//#define MAIN_MENU_COORDS_TI92P  2,17, 31,67, 83,101, 117,141, 157,172, 188,207, 223,236
#define MAIN_MENU_COORDS_TI92P    2,31, 43,55, 67,103, 115,139, 151,165, 177,206, 216,237

//-----------------------------------------------------------------------------
// strings and constants for load/save menu (file: menu.c)
//-----------------------------------------------------------------------------
//#define LS_MENU_LOAD         "LOAD ticsave0"
#define LS_MENU_LOAD           "CHARGER ticsave0"
//#define LS_MENU_LOAD_IDX     12               // index of 0 in above string
#define LS_MENU_LOAD_IDX       15               // index of 0 in above string
//#define LS_MENU_SAVE         "SAVE ticsave1"
#define LS_MENU_SAVE           "SAUVER ticsave1"
//#define LS_MENU_SAVE_IDX     12               // index of 1 in above string
#define LS_MENU_SAVE_IDX       14               // index of 1 in above string
//#define LS_MENU_EXPORT       "EXPORT Game"
#define LS_MENU_EXPORT         "EXPORTER Partie"
//#define LS_MENU_DIALOGWIDTH  52               // width of load/save menu
#define LS_MENU_DIALOGWIDTH    65               // width of load/save menu

//-----------------------------------------------------------------------------
// strings and constants for option menu (file: menu.c)
//-----------------------------------------------------------------------------
//#define OPTION_MENU_STRENGTH "Strength"
#define OPTION_MENU_STRENGTH   "Niveau"
//#define OPTION_MENU_AUTOLOAD "AutoLoad"
#define OPTION_MENU_AUTOLOAD   "Charg. auto"
//#define OPTION_MENU_AUTOSAVE "AutoSave"
#define OPTION_MENU_AUTOSAVE   "Sauv. auto"
//#define OPTION_MENU_HASING   "Hashing"
#define OPTION_MENU_HASING     "Hashage"
//#define OPTION_MENU_REQUESTS "Requests"
#define OPTION_MENU_REQUESTS   "Confirmations"
//#define OPTION_MENU_SAVEMVS  "Save Mvs"
#define OPTION_MENU_SAVEMVS    "Sauver coups"
//#define OPTION_MENU_PIECESET "PieceSet"
#define OPTION_MENU_PIECESET   "Pieces"
//#define OPTION_MENU_USEBOOK  "Use Books"
#define OPTION_MENU_USEBOOK    "Usage livres"
//#define OPTION_MENU_ON       "ON"
#define OPTION_MENU_ON         "ON"
//#define OPTION_MENU_OFF      "OFF"
#define OPTION_MENU_OFF        "OFF"

//#define OPTION_MENU_TEXTSTART2   37
#define OPTION_MENU_TEXTSTART2     52
//#define OPTION_MENU_DIALOGWIDTH  52
#define OPTION_MENU_DIALOGWIDTH    67

//-----------------------------------------------------------------------------
// help page definition for both calculator types (file: menu.c)
//-----------------------------------------------------------------------------
//#define HELP_PAGE_TI89  "[STO]",     "Load/Save Game",
//                        "[CATALOG]", "Change Sides",
//                        "[(][)]",    "Level Down/Up",
//                        "[0]",       "Automatic Play",
//                        "[BACK]",    "Take Back a Move",
//                        "[CLEAR]",   "Undo Take Back",
//                        "[HOME]",    "Rotate Board",
//                        "[2]",       "2-Player Mode",
//                        "[ENTER]",   "==[2ND]==[Y]",
//                        "[ESC]",     "==[N] or Main Menu",
//                        "[.]",       "Show Moves so Far",
//                        "[x]",       "Show Opening Moves",
//                        "[F5]",      "Boss Key (EXIT)",
//                        0
#define HELP_PAGE_TI89  "[STO]",     "Charge/Sauve Jeu",\
                        "[CATALOG]", "Change de c�t�",\
                        "[(][)]",    "Niveau -/+",\
                        "[0]",       "Jeu automatique",\
                        "[BACK]",    "Revenir d'un coup",\
                        "[CLEAR]",   "Annuler Revenir",\
                        "[HOME]",    "Tourne le plateau",\
                        "[2]",       "Mode 2 joueurs",\
                        "[ENTER]",   "==[2ND]==[Y]",\
                        "[ESC]",     "==[N] ou Menu",\
                        "[.]",       "Affiche coups jou�s",\
                        "[x]",       "Afficher coups livres",\
                        "[F5]",      "Quitte imm�diatement",\
                        0

//#define HELP_PAGE_TI92P "[STO]",       "Load/Save Game",
//                        "[C]",         "Change Sides",
//                        "[(][)]",      "Level Down/Up",
//                        "[A]",         "Toggle Automatic Play",
//                        "[BACK][B]",   "Take Back a Move",
//                        "[F]",         "Undo Take Back",
//                        "[R]",         "Rotate Board",
//                        "[2]",         "Toggle 2-Player Mode",
//                        "[F1]",        "==[ENTER]==[Y]",
//                        "[ESC]",       "==[N] or Main Menu",
//                        "[S]",         "Show Moves so Far",
//                        "[O]",         "Show Opening Moves",
//                        "[F5]",        "Boss Key (EXIT)",
//                        0
#define HELP_PAGE_TI92P "[STO]",       "Charge/Sauve Jeu",\
                        "[C]",         "Change de c�t�",\
                        "[(][)]",      "Niveau -/+",\
                        "[A]",         "Jeu automatique",\
                        "[BACK][B]",   "Revenir d'un coup",\
                        "[F]",         "Annuler Revenir",\
                        "[R]",         "Tourne le plateau",\
                        "[2]",         "Mode 2 joueurs",\
                        "[F1]",        "==[ENTER]==[Y]",\
                        "[ESC]",       "==[N] ou Menu",\
                        "[S]",         "Affiche coups jou�s",\
                        "[O]",         "Afficher coups livres",\
                        "[F5]",        "Quitte imm�diatement",\
                        0

//-----------------------------------------------------------------------------
// additionally help string displayed on TI-92p calculators (on main screen)
// (file: bg_ti92.c)
//-----------------------------------------------------------------------------
//#define ADDITIONAL_HELP    "[Press H for Help, ESC for Menu]"
#define ADDITIONAL_HELP      "[H pour l'Aide, ESC pour le Menu]"
//#define ADDITIONAL_HELP_X  125
#define ADDITIONAL_HELP_X    125
//#define ADDITIONAL_HELP_Y  120
#define ADDITIONAL_HELP_Y    120

//-----------------------------------------------------------------------------
// letters used for figures (don't replace the '.')
// (file: engine.c)
//-----------------------------------------------------------------------------
//#define FIGURE_SYMBOLS 'K','Q','N','B','R','P','.','P','R','B','N','Q','K'
#define FIGURE_SYMBOLS   'R','D','C','F','T','P','.','P','T','F','C','D','R'

//-----------------------------------------------------------------------------
// translations for move list (file: menu.c)
//-----------------------------------------------------------------------------
//#define MOVELIST_NOMOVES    "No moves stored. Sorry."
#define MOVELIST_NOMOVES    "Aucun coup enregistr�. D�sol�."
//#define MOVELIST_CONTINUE   "--- Continue with Listing ? ---"
#define MOVELIST_CONTINUE   "--- Continuer d'afficher ? ---"
//#define MOVELIST_ENDOFLIST  "--- End Of List ---"
#define MOVELIST_ENDOFLIST  "--- Fin de la Liste ---"

//-----------------------------------------------------------------------------
// translations for training menu (file: menu.c)
//-----------------------------------------------------------------------------
//#define TRAIN_MENU_NOPUZZLES   "No TICPUZ-File found."
#define TRAIN_MENU_NOPUZZLES     "Aucun fichier TICPUZ trouv�."
//#define TRAIN_MENU_TURNWHITE   "Turn: WHITE"
#define TRAIN_MENU_TURNWHITE     "Tour: BLANC"
//#define TRAIN_MENU_TURNBLACK   "Turn: BLACK"
#define TRAIN_MENU_TURNBLACK     "Tour: NOIR"

//-----------------------------------------------------------------------------
// translations for infoboards (file: infoboards.c)
//-----------------------------------------------------------------------------
//#define INFOBOARD_PLAYER "Player:"
#define INFOBOARD_PLAYER   "Joueur:"
//#define INFOBOARD_HUMAN  "Human"
#define INFOBOARD_HUMAN    "Humain"
//#define INFOBOARD_LAST   "Last:"
#define INFOBOARD_LAST     "Der:"
//#define INFOBOARD_BEST   "Best:"
#define INFOBOARD_BEST     "Meil:"
//#define INFOBOARD_NODES  "Nodes:"
#define INFOBOARD_NODES    "Nds:"
//#define INFOBOARD_BOOK   "Book: %d/%d"
#define INFOBOARD_BOOK     "Livre: %d/%d"

//-----------------------------------------------------------------------------
// translations for misc. messages
//-----------------------------------------------------------------------------
//#define MSG_DRAWREPEAT1      "Draw due to"
#define MSG_DRAWREPEAT1        "Nul � cause de"
//#define MSG_DRAWREPEAT2      "Repetition!"
#define MSG_DRAWREPEAT2        "r�p�tition !"
//#define MSG_DRAW50PLY1       "Draw due to"
#define MSG_DRAW50PLY1         "Nul car r�gle"
//#define MSG_DRAW50PLY2       "50 Ply Rule!"
#define MSG_DRAW50PLY2         "des 50 coups !"
//#define MSG_CHECKMATEIWIN1   "Checkmate!"
#define MSG_CHECKMATEIWIN1     "Echec et Mat !"
//#define MSG_CHECKMATEIWIN2   "I win!"
#define MSG_CHECKMATEIWIN2     "J'ai gagn� !"
//#define MSG_CHECKMATEYOUWIN1 "Checkmate!"
#define MSG_CHECKMATEYOUWIN1   "Echec et Mat !"
//#define MSG_CHECKMATEYOUWIN2 "You win!"
#define MSG_CHECKMATEYOUWIN2   "Tu as gagn� !"
//#define MSG_YOUWILLLOSE1     "You will loose"
#define MSG_YOUWILLLOSE1       "Tu vas perdre"
//#define MSG_YOUWILLLOSE2     "in %d mvs"
#define MSG_YOUWILLLOSE2       "dans %d coups"
//#define MSG_IWILLLOSE1       "I will loose"
#define MSG_IWILLLOSE1         "Je vais perdre"
//#define MSG_IWILLLOSE2       "in %d mvs"
#define MSG_IWILLLOSE2         "dans %d coups"
//#define MSG_STALEMATE1       "Draw due to"
#define MSG_STALEMATE1         "Nul � cause de"
//#define MSG_STALEMATE2       "Stalemate!"
#define MSG_STALEMATE2         "Pat !!!"
//#define MSG_CHECK            "CHECK !!!"
#define MSG_CHECK              "ECHEC !!!"
//#define MSG_ABORT            "Abort (Y/N)?"
#define MSG_ABORT              "Annuler (O/N)?"
//#define MSG_STARTAUTOMATIC   "Start Automatic (Y/N)?"
#define MSG_STARTAUTOMATIC     "Jeu automatique (O/N)?"
//#define MSG_CHANGESIDES      "Change Sides (Y/N)?"
#define MSG_CHANGESIDES        "Changer de c�t� (O/N)?"
//#define MSG_ONEPLAYER        "ONE Player (Y/N)?"
#define MSG_ONEPLAYER          "UN Joueur (O/N)?"
//#define MSG_TWOPLAYER        "TWO player (Y/N)?"
#define MSG_TWOPLAYER          "DEUX Joueurs (O/N)?"
//#define MSG_PROMOTETO        "Promote to:"
#define MSG_PROMOTETO          "Promouvoir en:"
//#define PROMOTE_CORRECTX     0
#define PROMOTE_CORRECTX       -7

//-----------------------------------------------------------------------------
// translations for string used in exported textfile (file: loadsave.c)
//-----------------------------------------------------------------------------
//#define EXPORTED_GAME       "Game"
#define EXPORTED_GAME         "Jeu"


//-----------------------------------------------------------------------------
// about menu translations (file: menu.c)
//-----------------------------------------------------------------------------
//#define ABOUT_STR1  "A TI-Chess Team Production"
#define ABOUT_STR1  "Une Production TI-Chess Team"
//#define ABOUT_STR2  "Programming and Artwork By"
#define ABOUT_STR2  "Programmation et Graphismes Par"
#define ABOUT_STR3  "Thomas Nussbaumer"
#define ABOUT_STR4  "(thomas.nussbaumer@gmx.net)"
//#define ABOUT_STR5  "And"
#define ABOUT_STR5  "Et"
#define ABOUT_STR6  "Marcos Lopez"
#define ABOUT_STR7  "(marcos.lopez@gmx.net)"

//#define MSG_INVALIDMOVE "!! Invalid Move !!"
#define MSG_INVALIDMOVE "D�placement incorrect !"
//#define MSG_INVALIDBOOKMOVE "!! Invalid Book Entry !!"
#define MSG_INVALIDBOOKMOVE "!! Entr�e livre invalide !!"

#endif

//#############################################################################
//###################### NO MORE FAKES BEYOND THIS LINE #######################
//#############################################################################
//
//=============================================================================
// Revision History
//=============================================================================
//
// $Log: msg_french.h,v $
// Revision 1.8  2004/08/06 13:56:53  DEBROUX Lionel
// generic commit
//
// Revision 1.7  2002/10/28 09:11:25  tnussb
// unnecessary comments removed
//
// Revision 1.6  2002/10/17 09:56:42  tnussb
// generic commit for v3.97
//
// Revision 1.5  2002/10/16 18:28:51  tnussb
// changes related to the complete new puzzle file support (see history.txt)
//
// Revision 1.4  2002/10/14 12:09:18  tnussb
// help text extended by "opening moves" key
//
// Revision 1.3  2002/10/08 17:44:30  tnussb
// changes related to v3.90/v3.91
//
// Revision 1.2  2002/08/01 12:46:39  tnussb
// generic commit (I don't know anymore what I have changed ..)
//
// Revision 1.1  2002/03/01 17:28:41  tnussb
// initial check-in
//
//
