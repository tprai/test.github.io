/******************************************************************************
*
* project name:    TI-Chess
* file name:       logout.h
* initial date:    16/03/2000
* authors:         thomas.nussbaumer@gmx.net (coding)
*                  marcos.lopez@gmx.net      (design/graphics/beta testing)
* description:     header file for using logwriting to link port
*                  (only used during engine debugging stage)
*
* $Id: logout.h,v 1.4 2004/08/06 13:55:52 DEBROUX Lionel Exp $
*
******************************************************************************/

#ifndef LOGOUT_H
#define LOGOUT_H

#if ENABLE_LOGGING

void _Log2Link(const char* msg);
void _Bin2Link(unsigned long l,const char* msg);
void _Hex2Link(unsigned long l,const char* msg);


#define LOG2LINK(format,args...) \
{char lob[200]; sprintf(lob,format,##args);_Log2Link((const char*)lob);}

#define BIN2LINK(nr,str) _Bin2Link(nr,(const char*)str)
#define HEX2LINK(nr,str) _Hex2Link(nr,(const char*)str)

#else

#define LOG2LINK()
#define BIN2LINK()
#define HEX2LINK()

#endif

#endif


//#############################################################################
//###################### NO MORE FAKES BEYOND THIS LINE #######################
//#############################################################################
//
//=============================================================================
// Revision History
//=============================================================================
//
// $Log: logout.h,v $
// Revision 1.4  2004/08/06 13:55:52  DEBROUX Lionel
// generic commit
//
// Revision 1.3  2001/02/17 15:00:11  Thomas Nussbaumer
// changes due to new TIGCC version
//
// Revision 1.2  2000/08/12 15:31:13  Thomas Nussbaumer
// substitution keywords added
//
//
