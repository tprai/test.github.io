*******************************************************************************
*                                                                             *
* TTTTTTTTTTT  III         CCCCC   HH    HH   EEEEEEEE     SSSS       SSSS    *
* TTTTTTTTTTT  III        CCCCCCC  HH    HH   EEEEEEEE   SSSSSSSS   SSSSSSSS  *
*     TTT      III       CCC   CC  HH    HH   EE        SSS        SSS        *
*     TTT      III  XXX  CC        HHHHHHHH   EEEEEEEE   SSSSSS     SSSSSS    *
*     TTT      III  XXX  CC        HHHHHHHH   EEEEEEEE     SSSSSS     SSSSSS  *
*     TTT      III       CCC   CC  HH    HH   EE               SSS        SSS *
*     TTT      III        CCCCCCC  HH    HH   EEEEEEEE   SSSSSSSS   SSSSSSSS  *
*     TTT      III         CCCCC   HH    HH   EEEEEEEE     SSSS       SSSS    *
*                                                                             *
*                                                                             *
*                        TI-Chess for TI89/TI89T/TI92+/V200                   *
*                                                                             *
*                                    - v4.10 -                                *
*                                                                             *
*                                                                             *
*                                    by                                       *
*                                                                             *
*                                  T I C T                                    *
*                                                                             *
*                             The TI-Chess Team                               *
*                                                                             *
*                               (06/08/2004)                                  *
*                                                                             *
*                                                                             *
*                                                                             *
* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ *
* +                                                                         + *
* +              VISIT The TICT-HQ at:  http://tict.ticalc.org              + *
* +                                                                         + *
* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ *
*                                                                             *
*******************************************************************************
$Id: readme.txt,v 1.22 2004/08/06 14:11:00 DEBROUX Lionel Exp $

[COMPATIBLE with all AMS versions up to 3.00, HW1/HW2/HW3]
[NOTE: although there are two different kinds of executables, .9xy/.9xz and 
.v2y/.v2z, they are on-calc compatible]


-------------------------------------------------------------------------------
What is TI-Chess? (unsorted list)
-------------------------------------------------------------------------------

 (1) a full featured chess playing game for the TI89/TI89T/TI92+/V200 compatible
     with ALL AMS versions up to AMS 3.00 (AMS native - no kernel required)
 (2) implements all chess rules including en passant capturing, 3-repetition
     and 50-ply rule
 (3) supports grayscale GFX, a graphical menu system and chess clocks
 (4) comes with 2 different piecesets
 (5) should be competitive for beginners and intermediate chess players
     (5 levels -> level 1 to level 5)
     NOTE: On level 5 the calculation of a move may take more than 45 minutes!
 (6) the program is written in C (with a little bit inline 68kASM) using the
     phantastic GNU C port of the TIGCC team (http://tigcc.ticalc.org) and
     its sourcecode is available (it's opensource).
 (7) multiple save slots and export-to-textvariable feature
 (8) comes exepacked to reduce memory footprint (all files should be archived!)
 (9) multiple language support (english/german/french/spanish)
(10) opening book support using up to 20 external opening book files
(11) chess puzzles support using up to 10 external puzzle files
(12) a chess puzzle file containing 75 chess puzzles (with solutions) is part
     of this distribution



-------------------------------------------------------------------------------
CONTENTS of DISTRIBUTION
-------------------------------------------------------------------------------

directory src    ... the source - only available in sourcecode distribution
                     (examine src\readme.txt for details)
directory tools  ... chess puzzle compiler / opening book compiler
directory bin89  ... TI89/TI89T binaries (language-dependent files in subfolders)
directory bin92p ... TI92+/V200 binaries (language-dependent files in subfolders)
                     TI92+ and V200 versions are on-calc-compatible.



-------------------------------------------------------------------------------
!!!!!!!!! IMPORTANT NOTICE !!!!!!!!!!
-------------------------------------------------------------------------------

Always start TI-Chess from the commandline and not from any explorer-like
program to prevent crashes. Most of the available explorer-like programs cannot
handle large nostub programs correctly, even if they may start them your
calculator may crash some time later.

UPDATE:

TICT-Explorer handles TI-Chess correctly. With TICT-Explorer you don't even 
need the launcher program, you can start file tichess.ppg directly.



-------------------------------------------------------------------------------
STARTING TI-CHESS
-------------------------------------------------------------------------------

IMPORTANT: Since TI-Chess 3.98b all TI-Chess related files are stored in
           folder TICT. The graphlink software should store them automatically
           there. If not, please move them to this folder.

The necessary files for the TI89/TI89T can be found in directory bin89 and for 
the TI92+/V200 in directory bin92p.

Steps:

(1) if you have a previous version of TI-Chess on your calculator, please
    delete all TI-Chess related files first!!

(2) upload ticstart.9xz and tichess.9xy (or ticstart.v2z and tichess.v2z) to 
           your TI92+/V200 (those versions are on-calc-compatible)
    or     ticstart.89z (TI89) or ticstart-titanium.89z (TI89T) and tichess.89y 
           to your TI89/TI89T

(3) archive file tichess.ppg for better memory usage

(4) type: ticstart() and press [ENTER]

NOTE1: If you want to solve the chess puzzle which comes with TI-Chess
       upload file puzzles0.9xy to your TI92+/V200 or puzzles0.89y to your 
       TI89/TI89T. To save RAM, please archive the puzzle file (after uploading 
       it should be located in folder TICT).

NOTE2: If you want to use the standard opening book which comes with TI-Chess
       upload file bkwhite0.9xy and bkblack0.9xy to your TI92+/V200 or
       bkwhite0.89y and bkblack0.89y to your TI89/TI89T.
       To save RAM, please archive the opening book files (after uploading they
       should be located in folder TICT).

       BTW: file bkwhite0 is a book for WHITE and bkblack0 is a book for BLACK.
       If you always play the, say WHITE pieces, it is not necessary to upload
       bkwhite0, because TI-Chess will not use it.



-------------------------------------------------------------------------------
THE MENU SYSTEM
-------------------------------------------------------------------------------

The main menu can be reached from the game window by pressing [ESC] if it's
your turn. Press [ESC] again to go back to the game window.

To select a menu entry just locate the cursor on it by using the cursor keys
([LEFT] and [RIGHT]) and press [ENTER] or [DOWN].

(1) NEW GAME:   Starts a new game

(2) LOAD/SAVE:  Loads, saves or exports a game. The used slot may be selected by
                using [UP] and [DOWN].
                Press [ENTER] to load or save or [ESC] to cancel.
                Note: game slot ticsave0 cannot be used for saving, because
                it is used by the automatic load/save mechanism.

                EXPORT Game will write the moves so far to a textvariable called
                ticexpt in folder TICT.
                This variable can be directly viewed on the calculator with
                its text editor or you can download it to your computer for
                further processing.

(3) TRAIN (Train your Brain):
                Loads chess puzzles. The chess puzzle may be selected by
                using [LEFT] and [RIGHT]. To browse faster through the
                puzzles you can use also [UP] and [DOWN] to make steps of
                25 puzzles.
                Press [ENTER] to load the selected puzzle or [ESC] to cancel.
                Chess puzzles may come with an embedded solution. To view
                the solution press [F1] on TI89 or [F2] on the TI92p/V200
                while the train menu is open.
                If the screen doesn't change, then there is NO solution for
                this puzzle available.

                NOTE: "Mate in 2" puzzles may be solved by TI-Chess.
                      Load a chess puzzle, set the level 3 and change the
                      side so that the program calculates the next move.
                      "Mate in 3" puzzles may be solved at level 5.
                      "Mate in 4" puzzles cannot be solved by TI-Chess
                      correctly until now, because level 7 would be
                      necessary for it.

(4) OPTIONS:    To change any of the settings locate the cursor on it
                and press [LEFT] or [RIGHT]. Pressing [ESC] will leave
                the settings menu and stores the new settings.

                entry STRENGTH  ... Strength of calculator's AI
                entry AUTOLOAD  ... Enables/disables automatically loading
                                    from game slot ticsave0 at program start
                entry AUTOSAVE  ... Enables/disables automatically saving
                                    to game slot ticsave0  at program exit
                entry HASHING   ... If hashing is ON the program will allocate
                                    additionally memory (+20kB) during runtime
                                    to speedup its calculations. The program
                                    must be restarted if you change this
                                    parameter !!!
                entry REQUESTS  ... Enables/disables YES/NO requests.
                entry SAVE MVS  ... Enables/disables storing of moves in save
                                    slot. If disabled just the position is saved.
                entry PIECESET  ... sets the active pieceset (1 or 2)
                entry USE BOOKS ... Enables/disables usage of opening books

(5) HELP:       Displays help page

(6) ABOUT:      Displays credits page

(7) EXIT:       Leaves program  (key F5 as shortcut for exit everywhere !)



-------------------------------------------------------------------------------
NOTE ABOUT TAKE BACK AND MOVE STORING FEATURE
-------------------------------------------------------------------------------
Only the last 300 moves can be taken back. The same holds true for the number
of moves stored in the save files.



-------------------------------------------------------------------------------
KEY LIST FOR TI89/TI89T
-------------------------------------------------------------------------------

[F1]              Shows Help Page
[UP]              Move Cursor Up
[DOWN]            Move Cursor Down
[LEFT]            Move Cursor Left
[RIGHT]           Move Cursor Right
[ENTER],[2ND],[Y] YES on Dialogs/Select Figure/Make Move/Open Menu Entry
[ESC],[N]         NO  on Dialogs/Enter or Leave MainMenu/Unselect Figure
[(]               Level Down
[)]               Level Up
[STO]             Load/Save Game
[0]               Toggle Automatic Play
[CATALOG]         Change Sides
[BACK]            Take back a Move
[CLEAR]           Undo take back
[HOME]            Rotate board by 180 degree
[2]               Toggle 2-Player Mode
[ON]              Turn calculator OFF
[+]               Contrast Up
[-]               Contrast Down
[.]               Show Moves So Far
[x]               Show Continuation Moves for actual Position which are stored
                  in the installed Opening Books (up to 12 continuation moves
                  are displayed)
[F5]              Boss Key (exit program immediately without any further
                  requests)

[=]               access to internal debug menu



-------------------------------------------------------------------------------
KEY LIST FOR TI92+/V200
-------------------------------------------------------------------------------

[H]              Shows Help Page
[UP]             Move Cursor Up
[DOWN]           Move Cursor Down
[LEFT]           Move Cursor Left
[RIGHT]          Move Cursor Right
[F1],[ENTER],[Y] YES on Dialogs/Select Figure/Make Move
[ESC],[N]        NO on Dialogs/Enter or Leave Main-Menu/Unselect Figure
[(]              Level Down
[)]              Level Up
[STO]            Load/Save Game
[A]              Toggle Automatic Play
[C]              Change Sides
[BACK] or [B]    Take Back a Move
[F]              Undo take Back Move
[R]              Rotate board by 180 degree
[2]              Toggle 2-Player Mode
[ON]             Turn calculator OFF
[+]              Contrast Up
[-]              Contrast Down
[S]              Show Moves So Far
[o]              Show Continuation Moves for actual Position which are stored
                 in the installed Opening Books (up to 12 continuation moves
                 are displayed)
[F5]             Boss Key (exit program immediately without any further
                 requests)

[=]              access to internal debug menu



-------------------------------------------------------------------------------
OPENING BOOKS - How to use?
-------------------------------------------------------------------------------

If you want to use the opening book which comes with TI-Chess please upload
file bkwhite0.89y and bkblack0.89y from directory bin89 to your TI89/TI89T or
bkwhite0.9xy and bkblack0.9xy from directory bin92p to your TI92+/V200.
File bkwhite0 is used by the engine when it plays with the WHITE pieces.
File bkblack0 is used by the engine when it plays with the BLACK pieces.

Make sure that the "Use Books" entry in the option menu is set to ON, otherwise
the engine will not use the opening books at all.

Whenever the engine will select now an move from the opening book it will output
"Book: X/Y" instead of "Nodes: xxx". Y is the number of continuation moves
it has found for the current position and X is the number of the move it has
selected. For example "Book: 3/7" means that the engine found 7 continuation
moves in the used book and it had chosen move 3 to play.



-------------------------------------------------------------------------------
OPENING BOOKS - How does this feature work?
-------------------------------------------------------------------------------

An (opening) book is a kind of dictionary where the program will look up the
current position to find pre-calculated continuation moves. If it finds the
current position in the book it play one of the stored moves for this positions.

The benefits of using opening books are:

(1) speedup: its much faster to retrieve the next move from the book than
calculating it (of course only if there is a move stored)

(2) "randomness": without using the book the engine will always calculate one
continuation move (the best one). It's not quite entertaining when the program
always "answers" your moves in the same way. By using books more than one
continuation move can be stored for a position. The engine will select
"randomly" which one it will play.

(3) Play strength: moves stored in the book are (normally) the best moves taken
from the chess theory. This moves are quite hard to find for the engine running
on such a slow processor. If the engine plays a move from the book you can be
sure its one of the best moves which are available.

For players with none or little chess experience the book usage should be turned
off. Otherwise they get frustrated quite soon, because even on Level 1 the
engine will play very tough moves in the beginning of a match (in the opening).

BUT: it is also possible that someone writes a stupid book containing only weak
continuation moves. This way the engine can be forced to play weaker than it
would normally play on Level 1.



-------------------------------------------------------------------------------
OPENING BOOKS - How to make an own opening book?
-------------------------------------------------------------------------------

TI-Chess comes with an own opening book compiler (tools\bkc.exe). If you want
to make your own opening book I suggest reading file tools\readme.txt first
which explains the inputfile format of the book compiler. Starting with a
complete new book may be a little bit too complicated for your first steps.
Therefore start with modifying the TI-Chess standard book.

Here are the necessary steps to modify the standard book:

(1) Edit file openings.txt in directory tools and extend the book's content
    as you want.
(2) Then start batchfile build.bat which generates the books and copies them
    into directory bin89 and bin92p.



-------------------------------------------------------------------------------
PUZZLES FILES - How to make an own puzzle file?
-------------------------------------------------------------------------------

TI-Chess comes with an own puzzle compiler (tools\cpc.exe). If you want
to make your own puzzle files I suggest reading file tools\readme.txt first
which explains the inputfile format of the puzzle compiler and afterwards start
to modify the standard puzzle file.

Here are the necessary steps to modify the standard puzzle file:

(1) Edit file puzzles.txt in directory tools and extend its content as you want.
(2) Then start batchfile build.bat which generates the puzzles files and copies
    them into directory bin89 and bin92p.



-------------------------------------------------------------------------------
future extensions (unsorted list)
-------------------------------------------------------------------------------

(1) Improve endgame strategy
(2) LinkPlay option
(3) Support for grandmaster games databases
(4) Maybe animations ...
(5) "Real" beginner levels where the program will make minor mistakes
(6) Feature to setup position on the calculator



-------------------------------------------------------------------------------
... and the credits go to ...
-------------------------------------------------------------------------------

(1) Ch.Donninger and D.Steinwender for their MINIMAX chess engine which was the
    base code I started from (yet there is not left much of it)

(2) The TIGCC team especially Sebastian Reichelt (Sebastian@tigcc.ticalc.org)
    and Kevin Kofler (kevin.kofler@chello.at) for the GNU C port and its
    extensions.

(3) Zeljko Juric for his great library coming with TIGCC.

(4) Rusty Wagner (rusty@acz.org) for his incredible Virtual TI. Without this
    wonderful TI calc simulator my real calc wouldn't have survived all the
    crashes (nor my nerves ;-)

(5) Marcos Lopez (marcos.lopez@gmx.net) for his excellent graphics and his
    "never-ending" criticism. Sorrily he retired from our coorperation
    somewhere around v3.00.

(6) Beta Testers who sent me suggestions or bug reports:
    [sorted by their join time]

    Marcos Lopez        (marcos.lopez@gmx.net)
    Ralf Fichtner       (R.Fichtner@t-online.de)
    James J. Marshall   (marshall@astro.umd.edu)
    Noah Taber          (tabern@purdue.edu)
    Colin Squier        (cwsquier@mediaone.net)
    David Hatch         (Hatch99@email.msn.com)
    Case Cantrell       (slowwarp@hotmail.com)
    A.J. Franks         (kaizer_911@yahoo.com)
    Mikael P. Johansson (mpjohans@cc.helsinki.fi)
    Beno�t Charpentier  (Bencharp@ifrance.com)
    James Griffith      (JamesGriffith@aol.com)
    Flament Olivier     (bilbot.hobbit@ifrance.com)
    Kevin Ka            (badpeon@jps.net)
    Kai Brinker         (kai@newkai.com)
    taytrefenwyd@yahoo.com (for testing v3.05 RC)

(7) Ernst B�ck (etb-soft@aon.at) for contributing the fix for the
    takeback/forward-again problems

(8) Kevin Kofler (kevin.kofler@chello.at) for reporting the corruption of the
    supervisor stack in versions below 3.40b2

(9) Francesco Orabona (bremen79@infinito.it) for reporting the critical bugs
    under low-memory conditions

(10) Fran�ois Leiber (francois.leiber@laposte.net) for help with the french
     translation and for the the first implementation of the opening book feature

(11) Ladislav Cisar (cisar1@volny.cz) for sending me a large opening book which
     is used since v3.90/v3.91.

(12) Greg Dietsche for his HomeScreenRestore routine (taken from HSR 3.0)

(13) Andy Hou for reporting various bugs in v3.97b and v3.98b.

(14) Lionel Debroux for the TI-Chess 4.00+ coding

(15) Myself (thomas.nussbaumer@gmx.net) for the coding and the coordination

(16) ... and last but not least everyone who helped me with suggestions to make
     TI-Chess better



-------------------------------------------------------------------------------
Copyright (read: "Copyleft")
-------------------------------------------------------------------------------

This program may be distributed by any other website except tict.ticalc.org for
non-commercial use only.
DISTRIBUTIONS ON ANY OTHER MEDIUM (Disc,CD-ROM,DVD etc.) except for personal
use are PROHIBITED without separate allowance of the author.

The author makes no representations or warranties about the suitability
of the software and/or the data files, either expressed or implied.
The author shall not be liable for any damages suffered as a result of using
or distributing this software and/or data files.

You are free to re-use any part of the sourcecode in your products as long as
you give credits including a reference to the TICT-HQ (http://tict.ticalc.org).


-------------------------------------------------------------------------------
Contact TiCT members
-------------------------------------------------------------------------------

Thomas Nussbaumer: thomas.nussbaumer@gmx.net
Lionel Debroux:    lionel_debroux@yahoo.fr

Marcos Lopez:      marcos.lopez@gmx.net  (-- retired --)


!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
Use our messageboard (http://pub26.ezboard.com/btichessteamhq) to post
suggestions, bug reports and similar
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
